#!/bin/bash

# 색상 정의
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${YELLOW}========================================${NC}"
echo -e "${YELLOW}SHVB Task Manager Frontend 롤백${NC}"
echo -e "${YELLOW}========================================${NC}"

cd /Users/emitt0/100_Dev/shvb-tm-fe

# 현재 커밋 확인
CURRENT_COMMIT=$(git rev-parse HEAD)
echo -e "현재 커밋: ${CURRENT_COMMIT}"

# 이전 커밋으로 롤백
echo -e "\n${YELLOW}이전 커밋으로 롤백 중...${NC}"
git reset --hard HEAD~1

# 빌드
echo -e "\n${YELLOW}프로젝트 빌드 중...${NC}"
npm run build

# PM2 재시작
echo -e "\n${YELLOW}PM2 재시작 중...${NC}"
pm2 restart shvb-tm-fe

echo -e "\n${GREEN}롤백 완료!${NC}"