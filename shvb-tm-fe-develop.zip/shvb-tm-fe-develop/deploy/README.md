# SHVB Task Manager Frontend 배포 가이드

## 사전 요구사항

### 1. PM2 설치
```bash
npm install -g pm2
```

### 2. serve 설치 (정적 파일 서빙용)
```bash
npm install -g serve
```

## 배포 방법

### 초기 배포
```bash
cd /Users/emitt0/100_Dev/shvb-tm-fe/deploy
chmod +x deploy.sh
./deploy.sh
```

### 재배포
```bash
cd /Users/emitt0/100_Dev/shvb-tm-fe/deploy
./deploy.sh
```

### 롤백
```bash
cd /Users/emitt0/100_Dev/shvb-tm-fe/deploy
chmod +x rollback.sh
./rollback.sh
```

## PM2 명령어

### 상태 확인
```bash
pm2 status
pm2 list
```

### 로그 확인
```bash
pm2 logs shvb-tm-fe          # 실시간 로그
pm2 logs shvb-tm-fe --lines 100  # 최근 100줄
```

### 애플리케이션 제어
```bash
pm2 restart shvb-tm-fe   # 재시작
pm2 stop shvb-tm-fe      # 중지
pm2 start shvb-tm-fe     # 시작
pm2 delete shvb-tm-fe    # 삭제
```

### 모니터링
```bash
pm2 monit                 # 실시간 모니터링
pm2 describe shvb-tm-fe  # 상세 정보
```

### 부팅 시 자동 시작
```bash
pm2 startup              # 시스템 부팅 시 자동 시작 설정
pm2 save                 # 현재 프로세스 목록 저장
```

## 로그 관리

로그 파일 위치:
- Error 로그: `./logs/err.log`
- Output 로그: `./logs/out.log`
- Combined 로그: `./logs/combined.log`

로그 정리:
```bash
pm2 flush shvb-tm-fe     # 로그 파일 비우기
```

## 트러블슈팅

### 포트가 이미 사용 중인 경우
```bash
lsof -i :3000
kill -9 [PID]
```

### PM2 프로세스 초기화
```bash
pm2 kill
pm2 start deploy/ecosystem.config.js
```

## 프로덕션 체크리스트

- [ ] 환경변수 설정 확인
- [ ] API 엔드포인트 설정 확인
- [ ] 빌드 성공 확인
- [ ] PM2 프로세스 정상 동작 확인
- [ ] 로그 파일 정상 생성 확인
- [ ] 브라우저에서 접속 테스트
- [ ] 주요 기능 동작 확인