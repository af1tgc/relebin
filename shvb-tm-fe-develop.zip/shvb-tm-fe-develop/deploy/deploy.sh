#!/bin/bash

# 색상 정의
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}SHVB Task Manager Frontend 배포 시작${NC}"
echo -e "${GREEN}========================================${NC}"

# 프로젝트 루트로 이동
cd ../

# 1. Git Pull
echo -e "\n${YELLOW}[1/5] Git 최신 코드 가져오기...${NC}"
git pull origin develop
if [ $? -ne 0 ]; then
    echo -e "${RED}Git pull 실패${NC}"
    exit 1
fi

# 2. 의존성 설치
echo -e "\n${YELLOW}[2/5] 의존성 설치 중...${NC}"
npm install
if [ $? -ne 0 ]; then
    echo -e "${RED}npm install 실패${NC}"
    exit 1
fi

# 3. 빌드
echo -e "\n${YELLOW}[3/5] 프로젝트 빌드 중...${NC}"
npm run build
if [ $? -ne 0 ]; then
    echo -e "${RED}빌드 실패${NC}"
    exit 1
fi

# 4. PM2로 재시작
echo -e "\n${YELLOW}[4/5] PM2로 애플리케이션 재시작 중...${NC}"

# PM2 프로세스 존재 여부 확인
pm2 describe shvb-tm-fe > /dev/null 2>&1
if [ $? -eq 0 ]; then
    echo "기존 프로세스 재시작..."
    pm2 restart shvb-tm-fe
else
    echo "새로운 프로세스 시작..."
    pm2 start /home/yosub/shvb-tm-fe/deploy/ecosystem.config.cjs
fi

# 5. PM2 설정 저장
echo -e "\n${YELLOW}[5/5] PM2 설정 저장 중...${NC}"
pm2 save

echo -e "\n${GREEN}========================================${NC}"
echo -e "${GREEN}배포 완료!${NC}"
echo -e "${GREEN}========================================${NC}"
echo -e "애플리케이션이 http://localhost:3000 에서 실행 중입니다."
echo -e "\n유용한 명령어:"
echo -e "  - 상태 확인: ${YELLOW}pm2 status${NC}"
echo -e "  - 로그 확인: ${YELLOW}pm2 logs shvb-tm-fe${NC}"
echo -e "  - 재시작: ${YELLOW}pm2 restart shvb-tm-fe${NC}"
echo -e "  - 중지: ${YELLOW}pm2 stop shvb-tm-fe${NC}"
echo -e "  - 삭제: ${YELLOW}pm2 delete shvb-tm-fe${NC}"