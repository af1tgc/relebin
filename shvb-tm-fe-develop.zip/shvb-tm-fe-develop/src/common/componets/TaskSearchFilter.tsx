import { Box, Button, Grid, Input } from "@chakra-ui/react";
import { TextFilter } from "@/page/admin-task/components/filter/TextFilter";
import { SelectFilter } from "@/page/admin-task/components/filter/SelectFilter";
import { TASK_STATUS_OPTIONS } from "@/constants/status-colorset";

export interface TaskSearchFilters {
  taskTypeName: string;
  taskCategory: string;
  taskName: string;
  taskStatus: string;
  departmentName: string;
  employeeName: string;
  workDate: string;
  startMonth?: string; // 대시보드용 시작월
  endMonth?: string;   // 대시보드용 끝월
}

interface CategoryOption {
  value: string;
  label: string;
}

interface TaskSearchFilterProps {
  filters: TaskSearchFilters;
  onFilterChange: (key: keyof TaskSearchFilters, value: string) => void;
  onSearch: () => void;
  onClear: () => void;
  categoryOptions?: CategoryOption[];
  mode?: 'dashboard' | 'search'; // 대시보드는 월 범위, 현황검색은 단일 날짜
}

export function TaskSearchFilter({ filters, onFilterChange, onSearch, onClear, categoryOptions = [], mode = 'search' }: TaskSearchFilterProps) {
  const handleEnter = () => {
    onSearch();
  };

  return (
    <Box borderWidth="1px" borderRadius="md" p={4} mb={4}>
      {/* 첫 번째 줄 - 4개 */}
      <Grid templateColumns="1fr 1fr 1fr 1fr" gap={3} mb={3}>
        <TextFilter
          value={filters.taskTypeName}
          onChange={(value) => onFilterChange("taskTypeName", value)}
          placeholder="업무유형명"
          onEnter={handleEnter}
        />
        <SelectFilter
          value={filters.taskCategory}
          onChange={(value) => onFilterChange("taskCategory", value)}
          placeholder="업무구분"
          options={categoryOptions}
        />
        <TextFilter
          value={filters.taskName}
          onChange={(value) => onFilterChange("taskName", value)}
          placeholder="업무명"
          onEnter={handleEnter}
        />
        <SelectFilter
          value={filters.taskStatus}
          onChange={(value) => onFilterChange("taskStatus", value)}
          placeholder="업무현황"
          options={TASK_STATUS_OPTIONS}
          showColors={true}
        />
      </Grid>
      
      {/* 두 번째 줄 - 부서/임직원 + 날짜 필터 + 버튼 */}
      {mode === 'dashboard' ? (
        // 대시보드: 시작월/끝월
        <Grid templateColumns="1fr 1fr 1fr 1fr auto auto" gap={3} alignItems="end">
          <TextFilter
            value={filters.departmentName}
            onChange={(value) => onFilterChange("departmentName", value)}
            placeholder="부서명"
            onEnter={handleEnter}
          />
          <TextFilter
            value={filters.employeeName}
            onChange={(value) => onFilterChange("employeeName", value)}
            placeholder="임직원 이름"
            onEnter={handleEnter}
          />
          <Input
            type="month"
            value={filters.startMonth || ''}
            onChange={(e) => onFilterChange("startMonth", e.target.value)}
            placeholder="시작월"
            size="sm"
          />
          <Input
            type="month"
            value={filters.endMonth || ''}
            onChange={(e) => onFilterChange("endMonth", e.target.value)}
            placeholder="끝월"
            size="sm"
          />
          <Button size="sm" variant="outline" onClick={onClear}>
            Clear
          </Button>
          <Button size="sm" colorScheme="blue" onClick={onSearch}>
            검색
          </Button>
        </Grid>
      ) : (
        // 현황검색: 단일 날짜
        <Grid templateColumns="1fr 1fr 1fr auto auto" gap={3} alignItems="end">
          <TextFilter
            value={filters.departmentName}
            onChange={(value) => onFilterChange("departmentName", value)}
            placeholder="부서명"
            onEnter={handleEnter}
          />
          <TextFilter
            value={filters.employeeName}
            onChange={(value) => onFilterChange("employeeName", value)}
            placeholder="임직원 이름"
            onEnter={handleEnter}
          />
          <Input
            type="date"
            value={filters.workDate}
            onChange={(e) => onFilterChange("workDate", e.target.value)}
            placeholder="작업일"
            size="sm"
          />
          <Button size="sm" variant="outline" onClick={onClear}>
            Clear
          </Button>
          <Button size="sm" colorScheme="blue" onClick={onSearch}>
            검색
          </Button>
        </Grid>
      )}
    </Box>
  );
}
