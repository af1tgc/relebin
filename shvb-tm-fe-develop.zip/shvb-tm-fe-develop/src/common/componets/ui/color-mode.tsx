import { useTheme } from "next-themes";
import { useEffect, useState } from "react";
import type { ReactNode } from "react";
import { IconButton } from "@chakra-ui/react";
import { LuMoon, LuSun } from "react-icons/lu"; // <- 여기만 교체

type Mode = "light" | "dark";

export function useColorMode() {
  const { resolvedTheme, setTheme } = useTheme();
  const colorMode = (resolvedTheme === "dark" ? "dark" : "light") as Mode;
  const toggleColorMode = () => setTheme(colorMode === "light" ? "dark" : "light");
  const setColorMode = (mode: Mode) => setTheme(mode);
  return { colorMode, toggleColorMode, setColorMode };
}

export function ColorModeButton() {
  const { colorMode, toggleColorMode } = useColorMode();
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  if (!mounted) return null;

  return (
    <IconButton aria-label="Toggle color mode" variant="ghost" onClick={toggleColorMode} size="sm">
      {colorMode === "light" ? <LuMoon size="1.2em" /> : <LuSun size="1.2em" />}
    </IconButton>
  );
}

export function LightMode({ children }: { children: ReactNode }) {
  return <div className="light">{children}</div>;
}
export function DarkMode({ children }: { children: ReactNode }) {
  return <div className="dark">{children}</div>;
}
