import { Box, Drawer, Portal, VStack, Text, CloseButton } from "@chakra-ui/react";
import { useNavigate } from "react-router-dom";
import { useApp } from "../../../context/AppContext";
import { useAuth } from "../../../context/AuthContext";

export function Menubar() {
  const { isMenuOpen, setIsMenuOpen } = useApp();
  const { hasRole, user } = useAuth();
  const navigate = useNavigate();

  const handleMenuClick = (path: string) => {
    navigate(path);
    setIsMenuOpen(false); // 메뉴 닫기
  };

  return (
    <>
      {/* 왼쪽 메뉴바 (Drawer로 토글) */}
      <Drawer.Root
        open={isMenuOpen}
        onOpenChange={(e) => setIsMenuOpen(e.open)}
        placement="start"
      >
        <Portal>
          <Drawer.Backdrop />
          <Drawer.Positioner>
            <Drawer.Content>
              <Drawer.Header
                display="flex"
                justifyContent="space-between"
                alignItems="center"
              >
                <Box>
                  <Text fontWeight="bold">메뉴</Text>
                  {user && (
                    <Text fontSize="sm" color="gray.600">
                      {user.name} ({user.role})
                    </Text>
                  )}
                </Box>
                <CloseButton
                  aria-label="메뉴 닫기"
                  onClick={() => setIsMenuOpen(false)}
                  variant="ghost"
                  size="sm"
                >
                </CloseButton>
              </Drawer.Header>

              <Drawer.Body p="0">
                <VStack align="stretch">

                  {/* 모든 사용자가 볼 수 있는 메뉴 */}
                  <Box
                    px="6"
                    py="3"
                    _hover={{ bg: "gray.50", _dark: { bg: "gray.700" } }}
                    cursor="pointer"
                    onClick={() => handleMenuClick("/")}
                  >
                    대시보드
                  </Box>

                  {/* MANAGER 이상만 보이는 메뉴 */}
                  {hasRole("MANAGER") && (
                    <>
                      <Box
                        px="6"
                        py="3"
                        _hover={{ bg: "gray.50", _dark: { bg: "gray.700" } }}
                        cursor="pointer"
                        onClick={() => handleMenuClick("/admin")}
                      >
                        업무등록
                      </Box>
                      <Box
                        px="6"
                        py="3"
                        _hover={{ bg: "gray.50", _dark: { bg: "gray.700" } }}
                        cursor="pointer"
                        onClick={() => handleMenuClick("/admin/type")}
                      >
                        업무유형관리
                      </Box>
                      <Box
                        px="6"
                        py="3"
                        _hover={{ bg: "gray.50", _dark: { bg: "gray.700" } }}
                        cursor="pointer"
                        onClick={() => handleMenuClick("/admin/manager")}
                      >
                        업무현황 대시보드
                      </Box>
                    </>
                  )}
                  
                </VStack>
              </Drawer.Body>
            </Drawer.Content>
          </Drawer.Positioner>
        </Portal>
      </Drawer.Root>
    </>
  );
}
