export function getStatusColor(status: string) {
  switch (status) {
    case "PLANNED": return "gray";
    case "ACTIVE": return "green";
    case "ON_HOLD": return "yellow";
    case "DELAYED": return "red";
    case "DONE": return "cyan";
    default: return "gray";
  }
}

//'gray' | 'red' | 'orange' | 'yellow' | 'green' | 'teal' | 'blue' | 'cyan' | 'purple' | 'pink'