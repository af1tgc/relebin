import { createContext, useContext, useState, useEffect } from "react";
import type { ReactNode } from "react";
import type { User, UserRole, AuthState, LoginRequest, LoginResponse, ApiResult } from "../types/auth";
import { api, API_ENDPOINTS } from "../config/api";
import { jwtDecode } from "jwt-decode";

interface JwtPayload {
  employeeId: number;
  username: string;
  role?: string;
  sub: string;
  iat: number;
  exp: number;
}

interface AuthContextType extends AuthState {
  login: (username: string, password: string) => Promise<void>;
  logout: () => void;
  hasRole: (role: UserRole) => boolean;
  hasPermission: (permission: string) => boolean;
  checkSession: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  // 로그인
  const login = async (username: string, password: string) => {
    setIsLoading(true);
    try {
      const loginData: LoginRequest = { username, password };
      const response = await api.post<ApiResult<LoginResponse>>(API_ENDPOINTS.AUTH_LOGIN, loginData);
      
      const { data } = response;
      
      if (data.code === 0 && data.result) {
        const { token, employeeId, username, employeeName } = data.result;
        
        // JWT 토큰에서 role 정보 추출
        let userRole: UserRole = 'USER'; // 기본값
        try {
          const decoded = jwtDecode<JwtPayload>(token);
          if (decoded.role) {
            userRole = decoded.role.toUpperCase() as UserRole;
          }
        } catch (error) {
          console.error('JWT 토큰 디코딩 실패:', error);
        }
        
        // localStorage에 토큰 및 사용자 정보 저장
        localStorage.setItem('token', token);
        localStorage.setItem('employeeId', employeeId.toString());
        localStorage.setItem('username', username);
        localStorage.setItem('employeeName', employeeName);
        localStorage.setItem('role', userRole);
        
        // 사용자 상태 업데이트
        const newUser: User = {
          id: employeeId,
          name: employeeName,
          email: username,
          role: userRole,
          permissions: ['TASK_MANAGE']
        };
        
        setUser(newUser);
        setIsAuthenticated(true);
      } else {
        throw new Error(data.message || '로그인에 실패했습니다.');
      }
    } catch (error: any) {
      const errorMessage = error.response?.data?.message || error.message || '로그인에 실패했습니다.';
      throw new Error(errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  // 로그아웃
  const logout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('employeeId');
    localStorage.removeItem('username');
    localStorage.removeItem('employeeName');
    localStorage.removeItem('role');
    setUser(null);
    setIsAuthenticated(false);
    window.location.href = '/login';
  };

  // 세션 체크 (localStorage에서 토큰 확인)
  const checkSession = async () => {
    setIsLoading(true);
    try {
      const token = localStorage.getItem('token');
      const employeeId = localStorage.getItem('employeeId');
      const username = localStorage.getItem('username');
      const employeeName = localStorage.getItem('employeeName');
      const savedRole = localStorage.getItem('role');
      
      if (token && employeeId && username && employeeName) {
        // 토큰이 있으면 사용자 인증 상태로 설정
        const existingUser: User = {
          id: parseInt(employeeId),
          name: employeeName,
          email: username,
          role: (savedRole as UserRole) || 'USER',
          permissions: ['TASK_MANAGE']
        };
        
        setUser(existingUser);
        setIsAuthenticated(true);
      } else {
        setUser(null);
        setIsAuthenticated(false);
      }
    } catch (error) {
      setUser(null);
      setIsAuthenticated(false);
    } finally {
      setIsLoading(false);
    }
  };

  // 역할 체크
  const hasRole = (role: UserRole): boolean => {
    if (!user) return false;
    
    const roleHierarchy: Record<UserRole, number> = {
      'GUEST': 0,
      'USER': 1,
      'MANAGER': 2,
      'BOD': 3,
      'ADMIN': 9
    };
    
    return roleHierarchy[user.role] >= roleHierarchy[role];
  };
  

  // 권한 체크
  const hasPermission = (permission: string): boolean => {
    if (!user) return false;
    return user.permissions.includes(permission);
  };

  // 컴포넌트 마운트 시 세션 체크
  useEffect(() => {
    checkSession();
  }, []);

  return (
    <AuthContext.Provider value={{
      user,
      isAuthenticated,
      isLoading,
      login,
      logout,
      hasRole,
      hasPermission,
      checkSession
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
