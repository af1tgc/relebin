import { Box, Container, HStack, Heading, IconButton, Text, Button } from "@chakra-ui/react";
import { BrowserRouter, useLocation, Navigate } from "react-router-dom";
import AppRoutes from "./routes/AppRoutes";
import { ColorModeButton } from "./common/componets/ui/color-mode";
import { AppProvider, useApp } from "./context/AppContext";
import { AuthProvider, useAuth } from "./context/AuthContext";
import { LuMenu } from "react-icons/lu";

function AppContent() {
  const { isMenuOpen, setIsMenuOpen } = useApp();
  const { user, isAuthenticated, isLoading, logout } = useAuth();
  const location = useLocation();

  // 로딩 중이면 로딩 표시
  if (isLoading) {
    return (
      <Box minH="100vh" display="flex" alignItems="center" justifyContent="center">
        <Text>로딩 중...</Text>
      </Box>
    );
  }

  // 로그인하지 않은 경우 로그인 페이지로 리다이렉트
  if (!isAuthenticated && location.pathname !== "/login") {
    return <Navigate to="/login" replace />;
  }

  // 로그인 페이지에서는 헤더를 숨김
  if (location.pathname === "/login") {
    return <AppRoutes />;
  }

  return (
    <Box minH="100dvh">
      {/* 헤더 */}
      <Box borderBottomWidth="1px" py={3} position="sticky" top={0} bg="white" zIndex={100} _dark={{ bg: "gray.900" }}>
        <Container maxW="container.xl">
          <HStack justify="space-between">
            <HStack gap={2}>
              {/* 햄버거 버튼을 헤더 안으로 이동 */}
              <IconButton
                aria-label="메뉴 열기"
                onClick={() => setIsMenuOpen(true)}
                size="sm"
                variant="ghost"
                display={isMenuOpen ? "none" : "flex"}
              >
                <LuMenu />
              </IconButton>
              <Heading size="md">SHVB · Task Manager</Heading>
            </HStack>
            <HStack gap={3}>
              {user && (
                <>
                  <Text fontSize="sm" color="gray.600" _dark={{ color: "gray.400" }}>
                    {user.name}님, 안녕하세요!
                  </Text>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={logout}
                    color="gray.600"
                    _dark={{ color: "gray.400" }}
                    _hover={{ color: "gray.900", _dark: { color: "gray.100" } }}
                  >
                    로그아웃
                  </Button>
                </>
              )}
              <ColorModeButton />
            </HStack>
          </HStack>
        </Container>
      </Box>

      {/* 본문 */}
      <Container maxW="container.xl" py={8}>
        <AppRoutes />
      </Container>
    </Box>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <AppProvider>
          <AppContent />
        </AppProvider>
      </AuthProvider>
    </BrowserRouter>
  );
}
