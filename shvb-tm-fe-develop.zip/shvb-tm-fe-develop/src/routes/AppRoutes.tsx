import { Routes, Route } from "react-router-dom";
import Dashboard from "@/page/task-manager/Dashboard";
import AdminMain from "@/page/admin-task/AdminMain";
import AdminType from "@/page/admin-type/AdminTypeMain";
import AdminManagerMain from "@/page/admin-manager/AdminManagerMain";
import Login from "@/page/auth/Login";

export default function AppRoutes() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/" element={<Dashboard />} />
      <Route path="/admin" element={<AdminMain />} />
      <Route path="/admin/type" element={<AdminType />} />
      <Route path="/admin/manager" element={<AdminManagerMain />} />
      {/* 필요하면 추가
      <Route path="/tasks" element={<TasksPage />} />
      */}
    </Routes>
  );
}
