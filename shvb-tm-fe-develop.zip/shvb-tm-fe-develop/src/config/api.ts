import axios from 'axios';
import { toaster } from '@/components/ui/toaster';

export const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8080'

// axios 인스턴스 생성
export const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// 요청 인터셉터: 모든 요청에 토큰 자동 추가
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// 응답 인터셉터: 401 에러 시 로그인 페이지로 리다이렉트, 기타 에러는 토스트 표시
api.interceptors.response.use(
  (response) => {
    // 응답 코드가 0이 아니면 에러로 처리
    if (response.data?.code && response.data.code !== 0) {
      const errorMessage = response.data.result || response.data.message || '요청 처리 중 오류가 발생했습니다.';
      toaster.create({
        title: "오류",
        description: errorMessage,
        type: "error",
      });
      return Promise.reject(new Error(errorMessage));
    }
    return response;
  },
  (error) => {
    // 401 (Unauthorized) 또는 403 (Forbidden) 에러 시 로그아웃 처리
    if (error.response?.status === 401 || error.response?.status === 403) {
      // 이미 로그인 페이지에 있으면 리다이렉트 하지 않음
      if (window.location.pathname !== '/login') {
        localStorage.clear();
        toaster.create({
          title: "세션 만료",
          description: "로그인 세션이 만료되었습니다. 다시 로그인해주세요.",
          type: "error",
        });
        window.location.href = '/login';
      }
    } else {
      // 401, 403 이외의 에러는 토스트로 표시
      const errorMessage = error.response?.data?.result || error.response?.data?.message || error.message || '요청 처리 중 오류가 발생했습니다.';
      toaster.create({
        title: "오류",
        description: errorMessage,
        type: "error",
      });
    }
    return Promise.reject(error);
  }
);

export const API_ENDPOINTS = {
  // Auth
  AUTH_LOGIN: `${API_BASE_URL}/auth/login`,
  
  // Admin Task
  ADMIN_TASK_LIST: `${API_BASE_URL}/admin/task/list`,
  ADMIN_TASK: `${API_BASE_URL}/admin/task`,
  ADMIN_TASK_BY_ID: (id: number) => `${API_BASE_URL}/admin/task/${id}`,
  ADMIN_TASK_SEARCH: `${API_BASE_URL}/admin/task/search`,
  ADMIN_TASK_COMPLETION_STATS: (year: number) => `${API_BASE_URL}/admin/task/completion-stats/${year}`,
  ADMIN_TASK_UNWRITTEN_USERS: (date: string) => `${API_BASE_URL}/admin/task/unwritten-users/${date}`,
  
  // Admin Task Type
  ADMIN_TASK_TYPE_LIST: `${API_BASE_URL}/admin/task/type/list`,
  ADMIN_TASK_TYPE: `${API_BASE_URL}/admin/task/type`,
  ADMIN_TASK_TYPE_BY_ID: (id: number) => `${API_BASE_URL}/admin/task/type/${id}`,
  ADMIN_TASK_TYPE_GROUPED: `${API_BASE_URL}/admin/task/type/grouped`,
  
  // Admin Category
  ADMIN_CATEGORY_LEVEL1: `${API_BASE_URL}/admin/category`,
  
  // Task Manager
  TASK_DETAILS: `${API_BASE_URL}/api/task-details`,
  TASK_DETAILS_BY_ID: (id: number) => `${API_BASE_URL}/api/task-details/${id}`,
  TASK_LIST: `${API_BASE_URL}/api/task`,
  TASK_DETAIL: `${API_BASE_URL}/api/task/detail`,
  TASK_TYPE: `${API_BASE_URL}/api/task/type`,
  
  // Employee
  EMPLOYEE: `${API_BASE_URL}/api/employee`,
  EMPLOYEE_MANAGER: (employeeId: number) => `${API_BASE_URL}/api/employee/${employeeId}/manager`,
  
  // Department
  DEPARTMENT: `${API_BASE_URL}/api/department`,
  
  // Category
  CATEGORY: `${API_BASE_URL}/api/category`,
  CATEGORY_LEVEL2: (id: string) => `${API_BASE_URL}/api/category/level2/${id}`,
};