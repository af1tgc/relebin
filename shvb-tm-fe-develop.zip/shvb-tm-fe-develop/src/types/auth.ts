export type UserRole = 'ADMIN' | 'BOD' | 'MANAGER' | 'USER' | 'GUEST';

export interface User {
  id: number;
  name: string;
  email: string;
  role: UserRole;
  permissions: string[];
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
}

// API 타입 정의
export interface LoginRequest {
  username: string;
  password: string;
}

export interface LoginResponse {
  token: string;
  type: string;
  employeeId: number;
  username: string;
  employeeName: string;
}

export interface ApiResult<T> {
  code: number;
  message: string;
  result?: T;
}
