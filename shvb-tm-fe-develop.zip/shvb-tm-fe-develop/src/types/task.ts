export type TaskApiItem = {
  taskDetailId: number;
  content: string;
  remark: string;
  durationMinutes: number;
  isLate: boolean;
  taskId: number;
  taskTitle: string;
  taskStatus: string;
  departmentName: string;
  ownerEmployeeName: string;
  startDate: string;
  dueDate: string;
  taskTypeId: number;
  taskTypeName: string;
  taskCategoryId: number;
  taskCategoryName: string;
  employeeId: number;
  employeeName: string;
  workDate: string;
  linkUrl: string;
  assignerEmployeeId: number;
  assignerEmployeeName: string;
};

export type TaskItem = {
  taskId: number;
  title: string;
  taskTypeId: number;
  taskTypeName: string;
  taskCategoryName?: string;
};

export type EmployeeItem = {
  employeeId: number;
  employeeName: string;
  departmentName: string;
};