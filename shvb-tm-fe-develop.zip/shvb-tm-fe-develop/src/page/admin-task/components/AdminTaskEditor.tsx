import {
  Button, CloseButton, Drawer, Portal, Stack, Input,
  HStack, Text, Box, Spinner
} from "@chakra-ui/react";
import { useState, useEffect, useRef } from "react";
import { TASK_STATUS_OPTIONS } from "@/constants/status-colorset";
import { SelectFilter } from "@/page/admin-task/components/filter/SelectFilter";
import type { TaskItem } from "./AdminTaskTable";
import { api, API_ENDPOINTS } from "@/config/api";

interface TaskType {
  taskTypeId: number;
  taskTypeName: string;
}

export function AdminTaskEditor({
  open,
  onClose,
  onSaved,
  initialData,
  setRefreshing,
  managerEmployeeId,
}: {
  open: boolean;
  onClose: () => void;
  onSaved: () => void;
  initialData: TaskItem | null;
  setRefreshing: (val: boolean | ((prev: boolean) => boolean)) => void;
  managerEmployeeId?: number | null;
}) {
  const isEdit = !!initialData;

  // 폼 상태
  const [title, setTitle] = useState("");
  const [taskTypeId, setTaskTypeId] = useState(0);
  const [status, setStatus] = useState("");
  const [startDate, setStartDate] = useState("");
  const [dueDate, setDueDate] = useState("");
  const [saving, setSaving] = useState(false);

  // TaskType 검색 상태
  const [taskTypeQuery, setTaskTypeQuery] = useState("");
  const [taskTypeSuggestions, setTaskTypeSuggestions] = useState<TaskType[]>([]);
  const [taskTypeSearching, setTaskTypeSearching] = useState(false);
  const [selectedTaskType, setSelectedTaskType] = useState<TaskType | null>(null);
  const taskTypeAbortRef = useRef<AbortController | null>(null);

  // 초기값 로드
  useEffect(() => {
    if (initialData) {
      setTitle(initialData.title || "");
      setTaskTypeId(initialData.taskTypeId || 0);
      setStatus(initialData.status || "");
      setStartDate(initialData.startDate || "");
      setDueDate(initialData.dueDate || "");
      setTaskTypeQuery(initialData.taskTypeName || "");
      
      if (initialData.taskTypeId) {
        setSelectedTaskType({
          taskTypeId: initialData.taskTypeId,
          taskTypeName: initialData.taskTypeName
        });
      }
    } else {
      setTitle("");
      setTaskTypeId(0);
      setStatus("");
      setStartDate("");
      setDueDate("");
      setTaskTypeQuery("");
      setSelectedTaskType(null);
    }
  }, [initialData, open, managerEmployeeId]);

  // TaskType 검색
  useEffect(() => {
    if (!open) return;
    if (taskTypeQuery.trim().length < 2) {
      setTaskTypeSuggestions([]);
      return;
    }

    setTaskTypeSearching(true);
    taskTypeAbortRef.current?.abort();
    const ac = new AbortController();
    taskTypeAbortRef.current = ac;

    const timer = setTimeout(async () => {
      try {
        const res = await api.get(API_ENDPOINTS.TASK_TYPE, {
          params: { q: taskTypeQuery.trim() },
          signal: ac.signal,
        });
        setTaskTypeSuggestions(res.data.result ?? []);
      } catch (e) {
        if ((e as any)?.name !== "AbortError") {
          setTaskTypeSuggestions([]);
        }
      } finally {
        setTaskTypeSearching(false);
      }
    }, 250);

    return () => {
      clearTimeout(timer);
      ac.abort();
    };
  }, [taskTypeQuery, open]);

  const selectTaskType = (taskType: TaskType) => {
    setSelectedTaskType(taskType);
    setTaskTypeId(taskType.taskTypeId);
    setTaskTypeQuery(taskType.taskTypeName);
    setTaskTypeSuggestions([]);
  };

  const clearTaskType = () => {
    setSelectedTaskType(null);
    setTaskTypeId(0);
    setTaskTypeQuery("");
    setTaskTypeSuggestions([]);
  };

  const submit = async () => {
    setSaving(true);
    try {
      if (!title.trim()) throw new Error("업무명을 입력하세요.");
      if (!taskTypeId) throw new Error("업무유형을 선택하세요.");
      if (!status) throw new Error("상태를 선택하세요.");

      const payload = {
        title: title.trim(),
        taskTypeId,
        status,
        //ownerEmployeeId,
        startDate: startDate || null,
        dueDate: dueDate || null,
      };

      let result;
      if (isEdit) {
        const response = await api.post(API_ENDPOINTS.ADMIN_TASK_BY_ID(initialData!.taskId), payload);
        result = response.data;
      } else {
        const response = await api.post(API_ENDPOINTS.ADMIN_TASK, payload);
        result = response.data;
      }
      
      if (result.code !== 0) {
        throw new Error(result.result || "저장에 실패했습니다.");
      }

      onSaved();
    } catch (e: any) {
      alert(e.message ?? "오류가 발생했습니다.");
    } finally {
      setSaving(false);
      setRefreshing(prev => !prev);
    }
  };

  return (
    <Drawer.Root
      open={open}
      onOpenChange={(e) => { if (!e.open) onClose(); }}
      placement="end"
      size="xl"
    >
      <Portal>
        <Drawer.Backdrop />
        <Drawer.Positioner>
          <Drawer.Content>
            <Drawer.Header>
              <Drawer.Title>{isEdit ? "업무 수정" : "새 업무 등록"}</Drawer.Title>
              <Drawer.CloseTrigger asChild>
                <CloseButton />
              </Drawer.CloseTrigger>
            </Drawer.Header>

            <Drawer.Body>
              <Stack gap="4">
                {/* 업무명 */}
                <HStack align="start">
                  <Text w="140px" textAlign="left" mt="2">업무명</Text>
                  <Box flex="1">
                    <Input
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      placeholder="업무명을 입력하세요"
                    />
                  </Box>
                </HStack>

                {/* 업무유형 검색 */}
                <HStack align="start">
                  <Text w="140px" textAlign="left" mt="2">업무유형</Text>
                  <Box flex="1" position="relative">
                    <Input
                      placeholder="업무유형 검색 (2자 이상)"
                      value={taskTypeQuery}
                      onChange={(e) => {
                        setTaskTypeQuery(e.target.value);
                        if (!e.target.value) setSelectedTaskType(null);
                      }}
                    />
                    {selectedTaskType && (
                      <Text mt="2" color="gray.600">
                        <b>{selectedTaskType.taskTypeName}</b>
                        <CloseButton size="sm" aria-label="Clear" onClick={clearTaskType} />
                      </Text>
                    )}
                    {(taskTypeQuery.trim().length >= 2 && !selectedTaskType) && (
                      <Box
                        position="absolute"
                        top="calc(100% + 6px)"
                        left={0}
                        right={0}
                        borderWidth="1px"
                        borderRadius="md"
                        bg="white"
                        zIndex={10}
                        maxH="200px"
                        overflowY="auto"
                        p="2"
                      >
                        {taskTypeSearching && (
                          <HStack p="2" color="gray.500">
                            <Spinner size="sm" />
                            <Text>검색 중…</Text>
                          </HStack>
                        )}
                        {!taskTypeSearching && taskTypeSuggestions.length === 0 && (
                          <Text p="2" color="gray.500">검색 결과가 없습니다.</Text>
                        )}
                        {!taskTypeSearching && taskTypeSuggestions.map((taskType) => (
                          <Box
                            key={taskType.taskTypeId}
                            p="2"
                            borderRadius="sm"
                            _hover={{ bg: "gray.50", cursor: "pointer", _dark: { bg: "gray.700" } }}
                            onClick={() => selectTaskType(taskType)}
                          >
                            <Text><b>{taskType.taskTypeName}</b></Text>
                          </Box>
                        ))}
                      </Box>
                    )}
                  </Box>
                </HStack>

                {/* 업무담당자 검색 */}
                {/* <HStack align="start">
                  <Text w="140px" textAlign="left" mt="2">업무담당자</Text>
                  <Box flex="1" position="relative">
                    <Input
                      placeholder="업무담당자 검색 (2자 이상)"
                      value={employeeQuery}
                      onChange={(e) => {
                        setEmployeeQuery(e.target.value);
                        if (!e.target.value) setSelectedEmployee(null);
                      }}
                    />
                    {selectedEmployee && (
                      <Text mt="2" color="gray.600">
                        <b>{selectedEmployee.employeeName}</b>
                        <CloseButton size="sm" aria-label="Clear" onClick={clearEmployee} />
                      </Text>
                    )}
                    {(employeeQuery.trim().length >= 2 && !selectedEmployee) && (
                      <Box
                        position="absolute"
                        top="calc(100% + 6px)"
                        left={0}
                        right={0}
                        borderWidth="1px"
                        borderRadius="md"
                        bg="white"
                        zIndex={10}
                        maxH="200px"
                        overflowY="auto"
                        p="2"
                      >
                        {employeeSearching && (
                          <HStack p="2" color="gray.500">
                            <Spinner size="sm" />
                            <Text>검색 중…</Text>
                          </HStack>
                        )}
                        {!employeeSearching && employeeSuggestions.length === 0 && (
                          <Text p="2" color="gray.500">검색 결과가 없습니다.</Text>
                        )}
                        {!employeeSearching && employeeSuggestions.map((employee) => (
                          <Box
                            key={employee.employeeId}
                            p="2"
                            borderRadius="sm"
                            _hover={{ bg: "gray.50", cursor: "pointer", _dark: { bg: "gray.700" } }}
                            onClick={() => selectEmployee(employee)}
                          >
                            <Text><b>{employee.employeeName}</b></Text>
                          </Box>
                        ))}
                      </Box>
                    )}
                  </Box>
                </HStack> */}

                {/* 시작일 */}
                <HStack align="start">
                  <Text w="140px" textAlign="left" mt="2">시작일</Text>
                  <Box flex="1">
                    <Input
                      type="date"
                      value={startDate}
                      onChange={(e) => setStartDate(e.target.value)}
                      placeholder="YYYY.MM.DD"
                    />
                  </Box>
                </HStack>

                {/* 마감일 */}
                <HStack align="start">
                  <Text w="140px" textAlign="left" mt="2">마감일</Text>
                  <Box flex="1">
                    <Input
                      type="date"
                      value={dueDate}
                      onChange={(e) => setDueDate(e.target.value)}
                      placeholder="YYYY.MM.DD"
                    />
                  </Box>
                </HStack>

                {/* 상태 선택 */}
                <HStack align="start">
                  <Text w="140px" textAlign="left" mt="2">상태</Text>
                  <Box flex="1">
                    <SelectFilter
                      value={status}
                      onChange={setStatus}
                      placeholder="상태를 선택하세요"
                      options={TASK_STATUS_OPTIONS}
                      showColors={true}
                    />
                  </Box>
                </HStack>
              </Stack>
            </Drawer.Body>

            <Drawer.Footer>
              <Button variant="outline" mr="2" onClick={onClose}>취소</Button>
              <Button loading={saving} onClick={submit} colorScheme="blue">
                {isEdit ? "수정" : "등록"}
              </Button>
            </Drawer.Footer>
          </Drawer.Content>
        </Drawer.Positioner>
      </Portal>
    </Drawer.Root>
  );
}