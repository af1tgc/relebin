import { Select, createListCollection, Badge, Portal } from "@chakra-ui/react";

interface SelectOption {
  value: string;
  label: string;
  colorScheme?: string;
}

interface SelectFilterProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  options: SelectOption[];
  showColors?: boolean;
}

export function SelectFilter({ value, onChange, placeholder, options, showColors = false }: SelectFilterProps) {
  const collection = createListCollection({
    items: options,
  });

  return (
    <Select.Root
      collection={collection}
      value={value ? [value] : []}
      onValueChange={(e) => onChange(e.value[0] || "")}
      size="sm"
    >
      <Select.Trigger>
        <Select.ValueText placeholder={placeholder} />
      </Select.Trigger>
      <Portal>
        <Select.Positioner style={{ zIndex: 2000 }}>
          <Select.Content>
            {options.map((option) => (
              <Select.Item key={option.value} item={option.value}>
                <Select.ItemText>
                  {showColors && option.colorScheme ? (
                    <Badge colorPalette={option.colorScheme}>{option.label}</Badge>
                  ) : (
                    option.label
                  )}
                </Select.ItemText>
              </Select.Item>
            ))}
          </Select.Content>
        </Select.Positioner>
      </Portal>
    </Select.Root>
  );
}