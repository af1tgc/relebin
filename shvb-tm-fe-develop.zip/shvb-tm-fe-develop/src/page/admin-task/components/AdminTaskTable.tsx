import { Table, Skeleton, Text, Button, HStack, Box, Select, createListCollection, Portal, Badge } from "@chakra-ui/react";
import { LuChevronUp, LuChevronDown, LuChevronsUpDown } from "react-icons/lu";
import { getStatusColor, getStatusLabel } from "@/constants/status-colorset";

export interface TaskItem {
  taskId: number;
  title: string;
  taskTypeId: number;
  taskTypeName: string;
  taskCategoryId: number;
  taskCategoryName: string;
  departmentId: number;
  departmentName: string;
  status: string;
  ownerEmployeeId: number;
  ownerEmployeeName: string;
  startDate: string;
  dueDate: string;
}

export interface PageInfo {
  currentPage: number;
  size: number;
  totalElements: number;
  totalPages: number;
  first: boolean;
  last: boolean;
}

export interface SortOption {
  field: string;
  direction: 'asc' | 'desc';
}

interface AdminTaskTableProps {
  data: TaskItem[];
  pageInfo: PageInfo;
  loading: boolean;
  onPageChange: (page: number) => void;
  onSizeChange: (size: number) => void;
  onSortChange: (sort: SortOption) => void;
  currentSort: SortOption;
  onRowClick?: (task: TaskItem) => void;
}

export function AdminTaskTable({ 
  data, 
  pageInfo, 
  loading, 
  onPageChange,
  onSizeChange,
  onSortChange,
  currentSort,
  onRowClick,
}: AdminTaskTableProps) {
  const skeletonRows = 10;
  const colCount = 7;

  const sortableFields = [
    { field: 'taskId', label: '업무 ID' },
    { field: 'title', label: '업무명' },
    { field: 'taskTypeName', label: '업무유형' },
    { field: 'taskCategoryName', label: '업무구분' },
    { field: 'startDate', label: '시작일' },
    { field: 'dueDate', label: '종료일' },
    { field: 'status', label: '업무상태' },
  ];

  const pageSizeOptions = [5, 10, 20, 50];
  const sizeCollection = createListCollection({
    items: pageSizeOptions.map(size => ({ value: size.toString(), label: size.toString() }))
  });

  const handlePageClick = (page: number) => {
    if (page >= 0 && page < pageInfo.totalPages) {
      onPageChange(page);
    }
  };

  const renderPageNumbers = () => {
    const pages = [];
    const maxVisible = 5;
    const current = pageInfo.currentPage;
    const total = pageInfo.totalPages;

    let start = Math.max(0, current - Math.floor(maxVisible / 2));
    let end = Math.min(total - 1, start + maxVisible - 1);

    if (end - start + 1 < maxVisible) {
      start = Math.max(0, end - maxVisible + 1);
    }

    for (let i = start; i <= end; i++) {
      pages.push(
        <Button
          key={i}
          size="sm"
          variant={i === current ? "solid" : "outline"}
          colorScheme={i === current ? "blue" : "gray"}
          onClick={() => handlePageClick(i)}
        >
          {i + 1}
        </Button>
      );
    }

    return pages;
  };

  const handleHeaderClick = (field: string) => {
    if (currentSort.field === field) {
      // 같은 필드면 방향 토글
      onSortChange({
        field,
        direction: currentSort.direction === 'asc' ? 'desc' : 'asc'
      });
    } else {
      // 다른 필드면 asc로 시작
      onSortChange({ field, direction: 'asc' });
    }
  };

  const getSortIcon = (field: string) => {
    if (currentSort.field !== field) {
      return <LuChevronsUpDown size={14} color="gray" />;
    }
    return currentSort.direction === 'asc' ? 
      <LuChevronUp size={14} color="blue" /> : 
      <LuChevronDown size={14} color="blue" />;
  };

  const handleRowClickInternal = (task: TaskItem) => {
    if (onRowClick) onRowClick(task);
  };

  return (
    <Box>
      <Table.ScrollArea borderWidth="1px" borderRadius="lg">
        <Table.Root size="sm">
          <Table.Header>
            <Table.Row>
              {sortableFields.map((sortField) => (
                <Table.ColumnHeader 
                  key={sortField.field}
                  cursor="pointer"
                  onClick={() => handleHeaderClick(sortField.field)}
                  _hover={{ bg: "gray.50", _dark: { bg: "gray.700" } }}
                >
                  <HStack>
                    <Text>{sortField.label}</Text>
                    {getSortIcon(sortField.field)}
                  </HStack>
                </Table.ColumnHeader>
              ))}
            </Table.Row>
          </Table.Header>

          <Table.Body aria-busy={loading}>
            {loading ? (
              Array.from({ length: skeletonRows }).map((_, rIdx) => (
                <Table.Row key={`sk-${rIdx}`}>
                  {Array.from({ length: colCount }).map((_, cIdx) => (
                    <Table.Cell key={`skc-${rIdx}-${cIdx}`}>
                      <Skeleton height="1em" />
                    </Table.Cell>
                  ))}
                </Table.Row>
              ))
            ) : data.length === 0 ? (
              <Table.Row>
                <Table.Cell colSpan={colCount}>
                  <Text color="gray.500">표시할 데이터가 없습니다.</Text>
                </Table.Cell>
              </Table.Row>
            ) : (
              data.map((task) => (
                <Table.Row
                  key={task.taskId}
                  onClick={() => handleRowClickInternal(task)}
                  style={{ cursor: "pointer" }}
                  _hover={{ bg: "gray.50", _dark: { bg: "gray.700" } }}
                >
                  <Table.Cell>{task.taskId}</Table.Cell>
                  <Table.Cell>{task.title}</Table.Cell>
                  <Table.Cell>{task.taskTypeName}</Table.Cell>
                  <Table.Cell>{task.taskCategoryName}</Table.Cell>
                  <Table.Cell>{task.startDate}</Table.Cell>
                  <Table.Cell>{task.dueDate}</Table.Cell>
                  <Table.Cell>
                    <Badge colorPalette={getStatusColor(task.status)}>
                      {getStatusLabel(task.status)}
                    </Badge>
                  </Table.Cell>
                </Table.Row>
              ))
            )}
          </Table.Body>
        </Table.Root>
      </Table.ScrollArea>

      {/* 페이지네이션 - 테이블 하단 고정 */}
      {!loading && data.length > 0 && (
        <HStack justify="space-between" align="center" mt={4} p={3} borderWidth="1px" borderRadius="lg" bg="gray.50" _dark={{ bg: "gray.800", borderColor: "gray.700" }}>
          <HStack>
            <Text fontSize="sm" color="gray.600" _dark={{ color: "gray.300" }}>
              총 {pageInfo.totalElements}개 중 {pageInfo.currentPage * pageInfo.size + 1}-
              {Math.min((pageInfo.currentPage + 1) * pageInfo.size, pageInfo.totalElements)}개 표시
            </Text>
            <HStack ml={4}>
              <Text fontSize="sm">페이지당</Text>
              <Select.Root
                collection={sizeCollection}
                value={[pageInfo.size.toString()]}
                onValueChange={(e) => onSizeChange(Number(e.value[0]))}
                size="sm"
                width="auto"
                positioning={{ strategy: "absolute" }}
              >
                <Select.Trigger width="70px">
                  <Select.ValueText />
                </Select.Trigger>
                <Portal>
                  <Select.Positioner>
                    <Select.Content>
                      {pageSizeOptions.map((size) => (
                        <Select.Item key={size} item={size.toString()}>
                          <Select.ItemText>{size}</Select.ItemText>
                        </Select.Item>
                      ))}
                    </Select.Content>
                  </Select.Positioner>
                </Portal>
              </Select.Root>
            </HStack>
          </HStack>
          
          <HStack gap={1}>
            <Button
              size="sm"
              variant="outline"
              onClick={() => handlePageClick(0)}
              disabled={pageInfo.first}
            >
              처음
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={() => handlePageClick(pageInfo.currentPage - 1)}
              disabled={pageInfo.first}
            >
              이전
            </Button>
            
            {renderPageNumbers()}
            
            <Button
              size="sm"
              variant="outline"
              onClick={() => handlePageClick(pageInfo.currentPage + 1)}
              disabled={pageInfo.last}
            >
              다음
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={() => handlePageClick(pageInfo.totalPages - 1)}
              disabled={pageInfo.last}
            >
              마지막
            </Button>
          </HStack>
        </HStack>
      )}
    </Box>
  );
}
