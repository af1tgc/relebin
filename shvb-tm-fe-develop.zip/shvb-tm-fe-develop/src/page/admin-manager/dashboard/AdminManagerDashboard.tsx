import { Grid } from "@chakra-ui/react";
import { useState, useEffect } from "react";
import { TaskCompletionChart } from "./components/TaskCompletionChart";
import { UnwrittenUsersList } from "./components/UnwrittenUsersList";
import ProjectTimelineChart from "./components/ProjectTimelineChart";
import { TaskSearchFilter, type TaskSearchFilters } from "@/common/componets/TaskSearchFilter";
import { api, API_ENDPOINTS } from "@/config/api";

function isoDate(d: Date) { return d.toISOString().slice(0, 10); }
function isoMonth(d: Date) { return d.toISOString().slice(0, 7); } // YYYY-MM 형식

interface CategoryOption {
  value: string;
  label: string;
}

export default function AdminManagerDashboard() {
  // 필터 상태 관리
  const now = new Date();
  const threeMonthsAgo = new Date(now.getFullYear(), now.getMonth() - 3, 1);
  
  const [filters, setFilters] = useState<TaskSearchFilters>({
    taskTypeName: "",
    taskCategory: "",
    taskName: "",
    taskStatus: "",
    departmentName: "",
    employeeName: "",
    workDate: isoDate(new Date()),
    startMonth: isoMonth(threeMonthsAgo), // 현재 월 -3개월
    endMonth: isoMonth(now), // 현재월
  });

  // 검색 트리거 - 이 값이 변경될 때만 API 호출
  const [searchTrigger, setSearchTrigger] = useState(0);
  const [categoryOptions, setCategoryOptions] = useState<CategoryOption[]>([{ value: "", label: "전체" }]);

  // 카테고리 목록 가져오기
  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const response = await api.get(API_ENDPOINTS.ADMIN_CATEGORY_LEVEL1);
        if (response.data.code === 0 && response.data.result) {
          const options = [
            { value: "", label: "전체" },
            ...response.data.result.map((cat: any) => ({
              value: cat.categoryName,
              label: cat.categoryName
            }))
          ];
          setCategoryOptions(options);
        }
      } catch (error) {
        console.error('카테고리 조회 실패:', error);
      }
    };
    fetchCategories();
  }, []);

  const updateFilter = (key: keyof TaskSearchFilters, value: string) => {
    setFilters((prev) => ({ ...prev, [key]: value }));
  };

  const handleSearch = () => {
    setSearchTrigger(prev => prev + 1); // 검색 트리거 발동
  };

  const clearFilters = () => {
    const now = new Date();
    setFilters({
      taskTypeName: "",
      taskCategory: "",
      taskName: "",
      taskStatus: "",
      departmentName: "",
      employeeName: "",
      workDate: isoDate(now),
      startMonth: isoMonth(new Date(now.getFullYear(), 0, 1)),
      endMonth: isoMonth(now),
    });
    setSearchTrigger(prev => prev + 1); // Clear 후 재검색
  };

  return (
    <>
      {/* 필터 섹션 */}
      <TaskSearchFilter
        filters={filters}
        onFilterChange={updateFilter}
        onSearch={handleSearch}
        onClear={clearFilters}
        categoryOptions={categoryOptions}
        mode="dashboard"
      />

      {/* 상단 영역: 도넛차트 + 미작성자 테이블 */}
      <Grid templateColumns="2fr 1fr" gap={6} mb={8}>
        <TaskCompletionChart filters={filters} searchTrigger={searchTrigger} />
        <UnwrittenUsersList filters={filters} searchTrigger={searchTrigger} />
      </Grid>
      
      {/* 하단 영역: 프로젝트 타임라인 차트 */}
      <ProjectTimelineChart filters={filters} searchTrigger={searchTrigger} />
    </>
  );
}
