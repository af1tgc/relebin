// src/page/admin-manager/components/ProjectYearTimeline.tsx
import { Box, Heading } from "@chakra-ui/react";
import { useColorMode } from "@/common/componets/ui/color-mode";
import {
  ResponsiveContainer, BarChart, Bar, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, LabelList, ReferenceArea,
} from "recharts";
import { useState, useEffect, useMemo } from "react";
import { api, API_ENDPOINTS } from "@/config/api";
import type { TaskSearchFilters } from "@/common/componets/TaskSearchFilter";

// ===== 설정/상수 =====
const EPS = 1e-3;
const BAR_SIZE = 26;      // 바 두께
const GAP = 12;           // 행 간격
const MONTH_ABBR = ["JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEC"];

const dayOfYear = (d: Date) => {
  const start = new Date(d.getFullYear(), 0, 1);
  return Math.floor((+new Date(d.getFullYear(), d.getMonth(), d.getDate()) - +start) / 86400000);
};

function buildMonthTicks(startMonth: string, endMonth: string) {
  // startMonth: "YYYY-MM", endMonth: "YYYY-MM"
  const [startYear, startM] = startMonth.split('-').map(Number);
  const [endYear, endM] = endMonth.split('-').map(Number);
  
  const ticks: number[] = [];
  const labels: string[] = [];
  
  let monthCount = 0;
  let currentYear = startYear;
  let currentMonth = startM - 1; // 0-based
  
  // 각 월을 균등하게 분할 (월 인덱스 기반)
  while (currentYear < endYear || (currentYear === endYear && currentMonth <= endM - 1)) {
    ticks.push(monthCount); // 0, 1, 2, ...
    labels.push(`${currentMonth + 1}월`);
    
    monthCount++;
    currentMonth++;
    if (currentMonth > 11) {
      currentMonth = 0;
      currentYear++;
    }
  }
  
  const totalMonths = monthCount;
  
  return { 
    ticks, 
    labels, 
    domainStart: 0, 
    domainEnd: totalMonths,
    totalMonths,
    startYear,
    startMonth: startM - 1, // 0-based
  };
}

// 날짜를 월 인덱스로 변환 (기준 월 대비)
function dateToMonthIndex(date: Date, baseYear: number, baseMonth: number): number {
  const yearDiff = date.getFullYear() - baseYear;
  const monthDiff = date.getMonth() - baseMonth;
  const totalMonthDiff = yearDiff * 12 + monthDiff;
  
  // 해당 월의 일자 비율 추가 (월 내 위치)
  const daysInMonth = new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
  const dayRatio = (date.getDate() - 1) / daysInMonth; // 0~1 범위
  
  return totalMonthDiff + dayRatio;
}

// ===== 타입 =====
type TaskItem = {
  taskId: number;
  title: string;
  startDate: string; // YYYY-MM-DD
  dueDate: string;   // YYYY-MM-DD
};
type TaskTypeGroup = {
  taskTypeId: number;
  taskTypeName: string;
  tasks: TaskItem[];
};

// (API 실패시) 샘플
const sampleGroups: TaskTypeGroup[] = [];

// ===== 타입별 컬러(수백개도 안전하게 분산) =====
const typeColor = new Map<number,string>();
function colorOf(typeId: number): string {
  if (typeColor.has(typeId)) return typeColor.get(typeId)!;
  const hue = (typeId * 137.508) % 360;
  const sat = 60 + ((typeId * 7) % 30);     // 60~89
  const light = 45 + ((typeId * 11) % 20);  // 45~64
  const c = `hsl(${hue}deg ${sat}% ${light}%)`;
  typeColor.set(typeId, c);
  return c;
}

// ===== 행 변환 =====
type Row = {
  key: string;
  yKey: string;
  tickLabel: string;
  typeId: number;
  color: string;
  startDate: string;
  dueDate: string;
  rangeLabel: string; // "DD. MON ~ DD. MON"
  offset: number;
  span: number;
  tail: number;
  sep?: number;
  title: string;
};

const fmtDM = (iso: string) => {
  const d = new Date(iso + "T00:00:00");
  return `${d.getDate()}. ${MONTH_ABBR[d.getMonth()]}`;
};

function clampRowToMonth(
  group: TaskTypeGroup, 
  task: TaskItem, 
  baseYear: number, 
  baseMonth: number,
  totalMonths: number
): Omit<Row, "yKey"|"tickLabel"> {
  const s = new Date(task.startDate + "T00:00:00");
  const e = new Date(task.dueDate + "T00:00:00");

  // 월 인덱스로 변환
  const startIdx = dateToMonthIndex(s, baseYear, baseMonth);
  const endIdx = dateToMonthIndex(e, baseYear, baseMonth);

  // 범위를 0 ~ totalMonths로 제한
  const clampedStart = Math.max(0, Math.min(totalMonths, startIdx));
  const clampedEnd = Math.max(0, Math.min(totalMonths, endIdx));

  if (clampedEnd < clampedStart) {
    return {
      key: `${group.taskTypeId}-${task.taskId}`,
      typeId: group.taskTypeId,
      color: colorOf(group.taskTypeId),
      startDate: task.startDate,
      dueDate: task.dueDate,
      rangeLabel: `${fmtDM(task.startDate)} ~ ${fmtDM(task.dueDate)}`,
      offset: 0, 
      span: 0, 
      tail: totalMonths,
      title: task.title,
    };
  }

  const offset = clampedStart;
  const span = clampedEnd - clampedStart;
  const tail = totalMonths - (offset + span);

  return {
    key: `${group.taskTypeId}-${task.taskId}`,
    typeId: group.taskTypeId,
    color: colorOf(group.taskTypeId),
    startDate: task.startDate,
    dueDate: task.dueDate,
    rangeLabel: `${fmtDM(task.startDate)} ~ ${fmtDM(task.dueDate)}`,
    offset, 
    span, 
    tail,
    title: task.title,
  };
}

// 그룹 → rows (그룹 경계마다 sep row 삽입, 그룹 첫 작업만 tickLabel=타입명)
function flatRows(
  groups: TaskTypeGroup[], 
  baseYear: number, 
  baseMonth: number, 
  totalMonths: number
): Row[] {
  const rows: Row[] = [];

  groups.forEach((g) => {
    g.tasks.forEach((t, ti) => {
      const base = clampRowToMonth(g, t, baseYear, baseMonth, totalMonths);
      rows.push({
        ...base,
        yKey: `${g.taskTypeId}-${t.taskId}`,
        tickLabel: ti === 0 ? g.taskTypeName : "", // 그룹 첫 행만 타입명 노출
      });
    });
  });

  return rows;
}

// ===== Y축 커스텀 틱(그룹 첫 행만 타입명, 나머진 빈칸 + 툴팁) =====
function YAxisTick(props: any) {
  const { x, y, payload, tickMap, colorMode } = props;
  const full: string = tickMap.get(payload?.value) ?? "";
  const maxChars = 18;
  const short = full.length > maxChars ? `${full.slice(0, maxChars - 1)}…` : full;
  const fill = colorMode === "dark" ? "#fff" : "#111";

  if (!full) return null; // 텍스트 없는 행은 숨김(작업 라벨은 바 안쪽 rangeLabel로만 표기)

  return (
    <text
      x={x}
      y={y}
      textAnchor="end"
      dominantBaseline="central"
      fontSize={12}
      fill={fill}
      style={{ pointerEvents: "auto", cursor: full.length > maxChars ? "help" : "default" }}
    >
      {short}
      <title>{full}</title>
    </text>
  );
}

// ===== 바 내부/외부 단일 라벨(항상 한 줄, 바 밖으로 넘쳐도 노출) =====
function SpanLabel({ x, y, width, height, value, colorMode }: any) {
  const text = String(value ?? "");
  const minInside = 72;
  const insideFill = "#fff";
  const outsideFill = colorMode === "dark" ? "#fff" : "#111";

  const cy = y + (height ?? BAR_SIZE) / 2;
  const inside = (width ?? 0) >= minInside;

  return (
    <text
      x={(x ?? 0) + (inside ? 10 : (width ?? 0) + 6)}
      y={cy}
      textAnchor="start"
      dominantBaseline="central"
      fontSize={12}
      fill={inside ? insideFill : outsideFill}
      style={{ whiteSpace: "pre", pointerEvents: "none" }}
    >
      {text}
    </text>
  );
}

// ===== 툴팁 =====
function Tip({ active, payload }: { active?: boolean; payload?: any[] }) {
  if (!active || !payload?.length) return null;
  const r = payload[0].payload as Row;
  if (!r.startDate) return null; // sep 행은 툴팁 X

  return (
    <Box bg="white" p={3} borderWidth="1px" borderRadius="md" boxShadow="lg" _dark={{ bg: "gray.800", borderColor: "gray.700" }}>
      <Heading size="sm" mb={1}>{r.title}</Heading>            {/* ← 제목 */}
      <Box fontSize="sm">
        <div><b>기간:</b> {r.startDate} ~ {r.dueDate}</div>     {/* ← 기간 */}
      </Box>
    </Box>
  );
}


// ===== 메인 =====
export default function ProjectYearTimeline({ filters, searchTrigger }: { filters: TaskSearchFilters; searchTrigger: number }) {
  const year = filters.workDate ? new Date(filters.workDate).getFullYear() : new Date().getFullYear();
  const { colorMode } = useColorMode();

  const [groups, setGroups] = useState<TaskTypeGroup[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const fetchGroups = async () => {
      setLoading(true);
      try {
        const params = new URLSearchParams();
        Object.entries(filters).forEach(([key, value]) => {
          if (value) params.append(key, value);
        });
        
        const response = await api.get(`${API_ENDPOINTS.ADMIN_TASK_TYPE_GROUPED}?${params.toString()}`);
        const result = response.data;
        if (result.code === 0 && result.result) {
          setGroups(result.result as TaskTypeGroup[]);
        } else {
          setGroups(sampleGroups);
        }
      } catch (e) {
      console.error(e);
        setGroups(sampleGroups);
      } finally {
        setLoading(false);
      }
    };
    fetchGroups();
  }, [searchTrigger]); // filters 대신 searchTrigger로 변경

  const { ticks: monthTicks, domainStart, domainEnd, totalMonths, startYear, startMonth } = buildMonthTicks(
    filters.startMonth || `${year}-01`,
    filters.endMonth || `${year}-12`
  );
  
  // rows 계산 (월 인덱스 기반)
  const rows = useMemo(() => 
    flatRows(groups, startYear, startMonth, totalMonths)
  , [groups, startYear, startMonth, totalMonths]);

  // yKey -> tickLabel 맵 (그룹 첫 행만 값 있음)
  const tickMap = useMemo(() => new Map(rows.map(r => [r.yKey, r.tickLabel])), [rows]);

  // 현재 달 강조 밴드
  const today = new Date();
  const showCurrentMonthBand = today.getFullYear() === year;
  const currStart = new Date(year, today.getMonth(), 1);
  const currEnd   = new Date(year, today.getMonth() + 1, 0);
  const bandX1 = dayOfYear(currStart);
  const bandX2 = dayOfYear(currEnd) + 1 - EPS;

  // 높이
  const rowHeight = BAR_SIZE + GAP;
  const chartHeight = Math.max(260, rows.length * rowHeight + 60);

  return (
    <Box borderWidth="1px" borderRadius="sm" p={6} bg="white" _dark={{ bg: "gray.800" }}>
      <Heading size="md" mb={4}>
        타임라인
        {loading && <Box as="span" fontSize="sm" color="gray.500" ml={2}>(로딩 중...)</Box>}
      </Heading>

      <Box maxH="560px" overflowY="auto">
        <Box h={`${chartHeight}px`}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={rows}
              layout="vertical"
              margin={{ top: 12, right: 28, bottom: 12, left: 10 }}
              barCategoryGap={GAP}
            >
              {/* 수평 그리드는 끄고(밑줄 제거), 수직(월 경계)만 남김 */}
              <CartesianGrid
                horizontal={false}
                vertical
                strokeDasharray="3 3"
                stroke={colorMode === "dark" ? "#334155" : "#e2e8f0"}
              />

              {/* 현재 달 강조 밴드 */}
              {showCurrentMonthBand && (
                <ReferenceArea
                  x1={bandX1}
                  x2={bandX2}
                  strokeOpacity={0}
                  fill="#0ea5b7"
                  fillOpacity={0.12}
                />
              )}

              {/* X축: 월 라벨 제거 */}
              <XAxis
                type="number"
                domain={[domainStart, domainEnd]}
                ticks={monthTicks}
                allowDecimals={false}
                interval={0}
                tickLine={false}
                axisLine={false}
                tick={false}
              />

              {/* Y축: 그룹 첫 행에만 타입명 출력 */}
              <YAxis
                type="category"
                dataKey="yKey"
                width={170}
                tick={
                  // tick 컴포넌트에 맵/컬러모드 전달
                  (props: any) => <YAxisTick {...props} tickMap={tickMap} colorMode={colorMode} />
                }
              />

              <Tooltip content={<Tip />} />

              {/* 그룹 경계선: 얇은 회색 바 한 줄 (다른 stackId로 별도 그리기) */}
              {//<Bar dataKey="sep" barSize={2} fill={colorMode === "dark" ? "#475569" : "#e5e7eb"} isAnimationActive={false} />
        }
              {/* offset(투명) → span(색) → tail(투명) */}
              <Bar dataKey="offset" stackId="tl" fill="rgba(0,0,0,0)" barSize={BAR_SIZE} isAnimationActive={false} />
              <Bar dataKey="span"   stackId="tl" barSize={BAR_SIZE} radius={[4, 4, 4, 4]} isAnimationActive={false}>
                {rows.map(r => <Cell key={`c-${r.key}`} fill={r.color} />)}
                <LabelList
                  dataKey="rangeLabel"
                  content={(p: any) => <SpanLabel {...p} colorMode={colorMode} />}
                />
              </Bar>
              <Bar dataKey="tail" stackId="tl" fill="rgba(0,0,0,0)" barSize={BAR_SIZE} isAnimationActive={false} />
            </BarChart>
          </ResponsiveContainer>
        </Box>
      </Box>
    </Box>
  );
}
