import { Box, Heading, Text, HStack, VStack } from "@chakra-ui/react";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from "recharts";
import { useState, useEffect } from "react";
import { getStatusColor } from "@/constants/status-colorset";
import { api, API_ENDPOINTS } from "@/config/api";
import type { TaskSearchFilters } from "@/common/componets/TaskSearchFilter";

// 목업 데이터 제거
const mockData: any[] = [];

// 한글 라벨을 영어 status value로 매핑
const labelToStatusMap: { [key: string]: string } = {
  "완료": "DONE",
  "진행중": "ACTIVE", 
  "지연": "DELAYED",
  "계획됨": "PLANNED",
  "보류": "ON_HOLD",
};

// Chakra colorScheme을 실제 색상으로 가져오기
const colorOf = (koreanLabel: string): string => {
  const statusValue = labelToStatusMap[koreanLabel];
  if (!statusValue) return "#6B7280";
  
  const colorScheme = getStatusColor(statusValue);
  
  // Chakra UI의 colorScheme을 실제 색상으로 매핑
  const colorMap: { [key: string]: string } = {
    gray: "#6B7280",
    blue: "#3B82F6", 
    yellow: "#F59E0B",
    red: "#EF4444",
    cyan: "#06B6D4",
  };
  
  return colorMap[colorScheme] || "#6B7280";
};

// 커스텀 라벨 함수
const renderLabel = ({ cx, cy, midAngle, innerRadius, outerRadius, percent }: any) => {
  const RADIAN = Math.PI / 180;
  const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
  const x = cx + radius * Math.cos(-midAngle * RADIAN);
  const y = cy + radius * Math.sin(-midAngle * RADIAN);

  return (
    <text 
      x={x} 
      y={y} 
      fill="white" 
      textAnchor={x > cx ? 'start' : 'end'} 
      dominantBaseline="central"
      fontSize={12}
      fontWeight="bold"
    >
      {`${(percent * 100).toFixed(0)}%`}
    </text>
  );
};

// 커스텀 툴팁
const CustomTooltip = ({ active, payload }: any) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    return (
      <Box bg="white" p={3} borderWidth="1px" borderRadius="md" boxShadow="lg" _dark={{ bg: "gray.800", borderColor: "gray.700" }}>
        <Text fontSize="sm" fontWeight="bold">{data.displayName}</Text>
        <Text fontSize="sm">{data.value}건</Text>
      </Box>
    );
  }
  return null;
};

export function TaskCompletionChart({ 
  filters,
  searchTrigger
}: { 
  filters: TaskSearchFilters;
  searchTrigger: number;
}) {
  const [data, setData] = useState(mockData);
  const [loading, setLoading] = useState(false);

  // API에서 업무 현황 데이터 가져오기
  useEffect(() => {
    const fetchTaskCompletion = async () => {
      setLoading(true);
      try {
        const year = new Date(filters.workDate).getFullYear();
        const params = new URLSearchParams();
        Object.entries(filters).forEach(([key, value]) => {
          if (value) params.append(key, value);
        });
        
        const response = await api.get(`${API_ENDPOINTS.ADMIN_TASK_COMPLETION_STATS(year)}?${params.toString()}`);
        const result = response.data;
        
        if (result.code === 0 && result.result) {
          // API 데이터에 color 속성 추가 (name이 한글 라벨)
          const dataWithColors = result.result.map((item: any) => ({
            ...item,
            color: colorOf(item.name), // name이 한글 라벨 ("완료", "진행중" 등)
            displayName: item.name // 한글 라벨을 그대로 사용
          }));
          setData(dataWithColors);
        } else {
          setData([]);
        }
      } catch (error) {
        console.error('업무 현황 조회 실패:', error);
        setData([]);
      } finally {
        setLoading(false);
      }
    };

    fetchTaskCompletion();
  }, [searchTrigger]); // filters 대신 searchTrigger로 변경

  const year = filters.workDate ? new Date(filters.workDate).getFullYear() : new Date().getFullYear();
  const total = data.reduce((sum, item) => sum + item.value, 0);

  return (
    <Box borderWidth="1px" borderRadius="sm" p={6} bg="white" _dark={{ bg: "gray.800", borderColor: "gray.700" }}>
      <Heading size="md" mb={4}>
        {year}년 업무 현황
        {loading && <Box as="span" fontSize="sm" color="gray.500" ml={2}>(로딩 중...)</Box>}
      </Heading>
      
      {data.length === 0 && !loading ? (
        <Box textAlign="center" py={8}>
          <Text color="gray.500">업무 현황 데이터가 없습니다.</Text>
        </Box>
      ) : (
        <HStack align="start" gap={6}>
          <Box flex="1" h="300px">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={data}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={renderLabel}
                  innerRadius={60}
                  outerRadius={120}
                  paddingAngle={2}
                  dataKey="value"
                >
                  {data.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip content={<CustomTooltip />} />
              </PieChart>
            </ResponsiveContainer>
          </Box>
          
          <VStack align="start" flex="0.5">
            <Text fontSize="lg" fontWeight="bold">전체 {total}건</Text>
            {data.map((item) => (
              <HStack key={item.name} >
                <Box w="3" h="3" borderRadius="full" bg={item.color} />
                <Text fontSize="sm" color="gray.600">{item.displayName}</Text>
                <Text fontSize="sm" fontWeight="medium">{item.value}건</Text>
                <Text fontSize="xs" color="gray.500">
                  ({Math.round((item.value / total) * 100)}%)
                </Text>
              </HStack>
            ))}
          </VStack>
        </HStack>
      )}
    </Box>
  );
}
