import { Box, Heading, Table, Text, Input, HStack } from "@chakra-ui/react";
import { useState, useEffect } from "react";
import { api, API_ENDPOINTS } from "@/config/api";
import type { TaskSearchFilters } from "@/common/componets/TaskSearchFilter";

const mockUnwrittenUsers: any[] = [];

export function UnwrittenUsersList({ filters, searchTrigger }: { filters: TaskSearchFilters; searchTrigger: number }) {
  const [selectedDate, setSelectedDate] = useState(filters.workDate);
  const [users, setUsers] = useState(mockUnwrittenUsers);
  const [loading, setLoading] = useState(false);

  // 필터 변경 시 selectedDate 동기화
  useEffect(() => {
    setSelectedDate(filters.workDate);
  }, [filters.workDate]);

  // 검색 트리거 또는 날짜 변경 시 API 호출
  useEffect(() => {
    const fetchUnwrittenUsers = async () => {
      setLoading(true);
      try {
        const params = new URLSearchParams();
        Object.entries(filters).forEach(([key, value]) => {
          if (value) params.append(key, value);
        });
        params.set('workDate', selectedDate); // selectedDate로 덮어쓰기
        
        const response = await api.get(`${API_ENDPOINTS.ADMIN_TASK_UNWRITTEN_USERS(selectedDate)}?${params.toString()}`);
        const result = response.data;
        if (result.code === 0 && result.result) {
          setUsers(result.result);
        }
      } catch (error) {
        console.error('미작성자 조회 실패:', error);
        // 실패 시 목업 데이터 사용
        setUsers(mockUnwrittenUsers);
      } finally {
        setLoading(false);
      }
    };

    fetchUnwrittenUsers();
  }, [selectedDate, searchTrigger]); // filters 대신 searchTrigger 사용

  return (
    <Box borderWidth="1px" borderRadius="sm" p={6} bg="white" _dark={{ bg: "gray.800", borderColor: "gray.700" }}>
      {/* 헤딩과 날짜 필터를 좌우 배치 */}
      <HStack justify="space-between" align="center" mb={4}>
        <Heading size="md">미작성자 명단</Heading>
        <HStack>
          <Input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            size="sm"
            maxW="150px"
          />
          {loading && <Text fontSize="sm" color="gray.500">로딩중...</Text>}
        </HStack>
      </HStack>

      {/* 스크롤 영역 */}
      <Box 
        maxH="390px" 
        overflowY="auto"
        borderWidth="1px"
        borderRadius="md"
      >
        <Table.Root size="sm" variant="line">
          <Table.Header position="sticky" top={0} bg="white" zIndex={1} _dark={{ bg: "gray.800" }}>
            <Table.Row>
              <Table.ColumnHeader>이름</Table.ColumnHeader>
              <Table.ColumnHeader>부서</Table.ColumnHeader>
            </Table.Row>
          </Table.Header>
          <Table.Body>
            {users.length === 0 ? (
              <Table.Row>
                <Table.Cell colSpan={2}>
                  <Text color="gray.500" textAlign="center" py={4}>
                    {loading ? "데이터를 불러오는 중..." : "미작성자가 없습니다."}
                  </Text>
                </Table.Cell>
              </Table.Row>
            ) : (
              users.map((user) => (
                <Table.Row key={user.employeeId}>
                  <Table.Cell>{user.employeeName}</Table.Cell>
                  <Table.Cell>
                    <Text fontSize="sm" color="gray.600">{user.departmentName}</Text>
                  </Table.Cell>
                </Table.Row>
              ))
            )}
          </Table.Body>
        </Table.Root>
      </Box>
    </Box>
  );
}