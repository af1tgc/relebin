import { Table, Skeleton, Text, Button, HStack, Box, Select, createListCollection, Portal, Badge } from "@chakra-ui/react";
import { LuChevronUp, LuChevronDown, LuChevronsUpDown } from "react-icons/lu";
import { getStatusColor, getStatusLabel } from "@/constants/status-colorset";

export interface SearchItem {
  taskDetailId: number;
  departmentName: string;
  taskCategoryName: string;
  taskTypeName: string;
  taskTitle: string;
  taskStatus: string;
  workContent: string;
  workHours: number;
  workerEmployeeName: string;
  assignerEmployeeName: string;
  // 툴팁용 추가 필드들
  taskStartDate: string;
  taskDueDate: string;
  ownerEmployeeName: string;
  ownerDepartmentName: string;
  workerDepartmentName: string;
  assignerDepartmentName: string;
}

export interface PageInfo {
  currentPage: number;
  size: number;
  totalElements: number;
  totalPages: number;
  first: boolean;
  last: boolean;
}

export interface SortOption {
  field: string;
  direction: 'asc' | 'desc';
}

interface AdminSearchTableProps {
  data: SearchItem[];
  pageInfo: PageInfo;
  loading: boolean;
  onPageChange: (page: number) => void;
  onSizeChange: (size: number) => void;
  onSortChange: (sort: SortOption) => void;
  currentSort: SortOption;
}

export function AdminSearchTable({ 
  data, 
  pageInfo, 
  loading, 
  onPageChange,
  onSizeChange,
  onSortChange,
  currentSort
}: AdminSearchTableProps) {
  const skeletonRows = 10;
  const colCount = 8;

  const sortableFields = [
    { field: 'departmentName', label: '부서명' },
    { field: 'taskCategoryName', label: '업무구분' },
    { field: 'taskTypeName', label: '업무유형' },
    { field: 'taskTitle', label: '업무명' },
    { field: 'workContent', label: '업무내용' },
    { field: 'taskStatus', label: '상태' },
    { field: 'workHours', label: '작업시간(분)' },
    { field: 'workerEmployeeName', label: '업무담당자' },
  ];

  const pageSizeOptions = [5, 10, 20, 50];
  const sizeCollection = createListCollection({
    items: pageSizeOptions.map(size => ({ value: size.toString(), label: size.toString() }))
  });

  const handlePageClick = (page: number) => {
    if (page >= 0 && page < pageInfo.totalPages) {
      onPageChange(page);
    }
  };

  const renderPageNumbers = () => {
    const pages = [];
    const maxVisible = 5;
    const current = pageInfo.currentPage;
    const total = pageInfo.totalPages;

    let start = Math.max(0, current - Math.floor(maxVisible / 2));
    let end = Math.min(total - 1, start + maxVisible - 1);

    if (end - start + 1 < maxVisible) {
      start = Math.max(0, end - maxVisible + 1);
    }

    for (let i = start; i <= end; i++) {
      pages.push(
        <Button
          key={i}
          size="sm"
          variant={i === current ? "solid" : "outline"}
          colorScheme={i === current ? "blue" : "gray"}
          onClick={() => handlePageClick(i)}
        >
          {i + 1}
        </Button>
      );
    }

    return pages;
  };

  const handleHeaderClick = (field: string) => {
    if (currentSort.field === field) {
      onSortChange({
        field,
        direction: currentSort.direction === 'asc' ? 'desc' : 'asc'
      });
    } else {
      onSortChange({ field, direction: 'asc' });
    }
  };

  const getSortIcon = (field: string) => {
    if (currentSort.field !== field) {
      return <LuChevronsUpDown size={14} color="gray" />;
    }
    return currentSort.direction === 'asc' ? 
      <LuChevronUp size={14} color="blue" /> : 
      <LuChevronDown size={14} color="blue" />;
  };

  return (
    <Box>
      <Table.ScrollArea borderWidth="1px" borderRadius="lg">
        <Table.Root size="sm">
          <Table.Header>
            <Table.Row>
              {sortableFields.map((sortField) => (
                <Table.ColumnHeader 
                  key={sortField.field}
                  cursor="pointer"
                  onClick={() => handleHeaderClick(sortField.field)}
                  _hover={{ bg: "gray.50", _dark: { bg: "gray.700" } }}
                >
                  <HStack>
                    <Text>{sortField.label}</Text>
                    {getSortIcon(sortField.field)}
                  </HStack>
                </Table.ColumnHeader>
              ))}
            </Table.Row>
          </Table.Header>

          <Table.Body aria-busy={loading}>
            {loading ? (
              Array.from({ length: skeletonRows }).map((_, rIdx) => (
                <Table.Row key={`sk-${rIdx}`}>
                  {Array.from({ length: colCount }).map((_, cIdx) => (
                    <Table.Cell key={`skc-${rIdx}-${cIdx}`}>
                      <Skeleton height="1em" />
                    </Table.Cell>
                  ))}
                </Table.Row>
              ))
            ) : data.length === 0 ? (
              <Table.Row>
                <Table.Cell colSpan={colCount}>
                  <Text color="gray.500">검색 결과가 없습니다.</Text>
                </Table.Cell>
              </Table.Row>
            ) : (
              data.map((item) => (
                <Table.Row key={item.taskDetailId}>
                  <Table.Cell>{item.departmentName}</Table.Cell>
                  <Table.Cell>{item.taskCategoryName}</Table.Cell>
                  <Table.Cell>{item.taskTypeName}</Table.Cell>
                  <Table.Cell>
                    <Box 
                      as="div"
                      title={`기간: ${item.taskStartDate} ~ ${item.taskDueDate}\n부서: ${item.ownerDepartmentName}`}
                    >
                      <Text cursor="help">{item.taskTitle}</Text>
                    </Box>
                  </Table.Cell>
                  <Table.Cell>
                    <Text 
                      maxW="200px" 
                      overflow="hidden"
                      textOverflow="ellipsis"
                      whiteSpace="nowrap"
                    >
                      {item.workContent}
                    </Text>
                  </Table.Cell>
                  <Table.Cell>
                    <Badge colorPalette={getStatusColor(item.taskStatus)}>
                      {getStatusLabel(item.taskStatus)}
                    </Badge>
                  </Table.Cell>
                  <Table.Cell>{item.workHours}분</Table.Cell>
                  <Table.Cell>
                    <Box as="div" title={item.workerDepartmentName}>
                      <Text cursor="help">{item.workerEmployeeName}</Text>
                    </Box>
                  </Table.Cell>
                </Table.Row>
              ))
            )}
          </Table.Body>
        </Table.Root>
      </Table.ScrollArea>

      {/* 페이지네이션 */}
      {!loading && data.length > 0 && (
        <HStack justify="space-between" align="center" mt={4} p={3} borderWidth="1px" borderRadius="lg" bg="gray.50" _dark={{ bg: "gray.800", borderColor: "gray.700" }}>
          <HStack>
            <Text fontSize="sm" color="gray.600">
              총 {pageInfo.totalElements}개 중 {pageInfo.currentPage * pageInfo.size + 1}-
              {Math.min((pageInfo.currentPage + 1) * pageInfo.size, pageInfo.totalElements)}개 표시
            </Text>
            <HStack ml={4}>
              <Text fontSize="sm">페이지당</Text>
              <Select.Root
                collection={sizeCollection}
                value={[pageInfo.size.toString()]}
                onValueChange={(e) => onSizeChange(Number(e.value[0]))}
                size="sm"
                width="auto"
                positioning={{ strategy: "absolute" }}
              >
                <Select.Trigger width="70px">
                  <Select.ValueText />
                </Select.Trigger>
                <Portal>
                  <Select.Positioner>
                    <Select.Content>
                      {pageSizeOptions.map((size) => (
                        <Select.Item key={size} item={size.toString()}>
                          <Select.ItemText>{size}</Select.ItemText>
                        </Select.Item>
                      ))}
                    </Select.Content>
                  </Select.Positioner>
                </Portal>
              </Select.Root>
            </HStack>
          </HStack>
          
          <HStack gap={1}>
            <Button
              size="sm"
              variant="outline"
              onClick={() => handlePageClick(0)}
              disabled={pageInfo.first}
            >
              처음
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={() => handlePageClick(pageInfo.currentPage - 1)}
              disabled={pageInfo.first}
            >
              이전
            </Button>
            
            {renderPageNumbers()}
            
            <Button
              size="sm"
              variant="outline"
              onClick={() => handlePageClick(pageInfo.currentPage + 1)}
              disabled={pageInfo.last}
            >
              다음
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={() => handlePageClick(pageInfo.totalPages - 1)}
              disabled={pageInfo.last}
            >
              마지막
            </Button>
          </HStack>
        </HStack>
      )}
    </Box>
  );
}
