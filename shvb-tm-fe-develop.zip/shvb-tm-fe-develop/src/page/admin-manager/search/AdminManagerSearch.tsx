import { Box } from "@chakra-ui/react";
import { useState, useEffect } from "react";
import { AdminSearchTable } from "./components/AdminSearchTable";
import type { SearchItem, PageInfo, SortOption } from "./components/AdminSearchTable";
import { api, API_ENDPOINTS } from "@/config/api";
import { TaskSearchFilter, type TaskSearchFilters } from "@/common/componets/TaskSearchFilter";

function isoDate(d: Date) { return d.toISOString().slice(0, 10); }

interface CategoryOption {
  value: string;
  label: string;
}

export default function AdminManagerSearch() {
  // 필터 상태 관리
  const [filters, setFilters] = useState<TaskSearchFilters>({
    taskTypeName: "",
    taskCategory: "",
    taskName: "",
    taskStatus: "",
    departmentName: "",
    employeeName: "",
    workDate: isoDate(new Date()),
  });

  const [categoryOptions, setCategoryOptions] = useState<CategoryOption[]>([{ value: "", label: "전체" }]);
  const [searchData, setSearchData] = useState<SearchItem[]>([]);
  const [pageInfo, setPageInfo] = useState<PageInfo>({
    currentPage: 0,
    size: 10,
    totalElements: 0,
    totalPages: 0,
    first: true,
    last: true
  });
  const [loading, setLoading] = useState(false);
  const [currentSort, setCurrentSort] = useState<SortOption>({
    field: 'taskId',
    direction: 'asc'
  });

  const updateFilter = (key: keyof TaskSearchFilters, value: string) => {
    setFilters((prev) => ({ ...prev, [key]: value }));
  };

  // 카테고리 목록 가져오기
  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const response = await api.get(API_ENDPOINTS.ADMIN_CATEGORY_LEVEL1);
        if (response.data.code === 0 && response.data.result) {
          const options = [
            { value: "", label: "전체" },
            ...response.data.result.map((cat: any) => ({
              value: cat.categoryName,
              label: cat.categoryName
            }))
          ];
          setCategoryOptions(options);
        }
      } catch (error) {
        console.error('카테고리 조회 실패:', error);
      }
    };
    fetchCategories();
  }, []);

  const fetchSearchResults = async (page: number = 0, size?: number, sort?: SortOption) => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      Object.entries(filters).forEach(([key, value]) => {
        if (value) params.append(key, value);
      });
      
      params.append('page', page.toString());
      params.append('size', (size || pageInfo.size || 10).toString());
      
      const sortParam = sort || currentSort;
      params.append('sort', `${sortParam.field},${sortParam.direction}`);

      const response = await api.get(`${API_ENDPOINTS.ADMIN_TASK_SEARCH}?${params.toString()}`);
      const result = response.data;
      if (result.code === 0) {
        setSearchData(result.result.content);
        setPageInfo(result.result.pageInfo);
        if (sort) setCurrentSort(sort);
      }
    } catch (error) {
      console.error('검색 실패:', error);
      setSearchData([]);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = () => {
    fetchSearchResults(0);
  };

  const handlePageChange = (page: number) => {
    fetchSearchResults(page);
  };

  const handleSizeChange = (size: number) => {
    fetchSearchResults(0, size);
  };

  const handleSortChange = (sort: SortOption) => {
    fetchSearchResults(pageInfo.currentPage, undefined, sort);
  };

  const clearFilters = () => {
    setFilters({
      taskTypeName: "",
      taskCategory: "",
      taskName: "",
      taskStatus: "",
      departmentName: "",
      employeeName: "",
      workDate: isoDate(new Date()),
    });
  };

  return (
    <Box>
      {/* 필터 섹션 - 항상 노출 */}
      <TaskSearchFilter
        filters={filters}
        onFilterChange={updateFilter}
        onSearch={handleSearch}
        onClear={clearFilters}
        categoryOptions={categoryOptions}
        mode="search"
      />

      {/* 테이블 섹션 */}
      <AdminSearchTable
        data={searchData}
        pageInfo={pageInfo}
        loading={loading}
        onPageChange={handlePageChange}
        onSizeChange={handleSizeChange}
        onSortChange={handleSortChange}
        currentSort={currentSort}
      />
    </Box>
  );
}
