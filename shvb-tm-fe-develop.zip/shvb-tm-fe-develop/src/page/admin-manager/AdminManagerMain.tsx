import { Box, VStack, Tabs } from "@chakra-ui/react";
import { Menubar } from "@/common/componets/ui/Menubar";
import AdminManagerDashboard from "@/page/admin-manager/dashboard/AdminManagerDashboard";
import AdminManagerSearch from "@/page/admin-manager/search/AdminManagerSearch";

export default function AdminManagerMain() {
  return (
    <VStack gap={6} align="stretch">
      <Menubar />
      <Box p={6}>
        <Tabs.Root defaultValue="dashboard" size="lg">
          <Tabs.List>
            <Tabs.Trigger value="dashboard">대시보드</Tabs.Trigger>
            <Tabs.Trigger value="search">현황검색</Tabs.Trigger>
          </Tabs.List>
          
          <Tabs.Content value="dashboard" pt={6}>
            <AdminManagerDashboard />
          </Tabs.Content>
          
          <Tabs.Content value="search" pt={6}>
            <AdminManagerSearch />
          </Tabs.Content>
        </Tabs.Root>
      </Box>
    </VStack>
  );
}
