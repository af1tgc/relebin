import { Box, Heading, Stack, Text, HStack, Input, Button } from "@chakra-ui/react";
import { toaster } from "@/components/ui/toaster"
import TaskTable from "@/page/task-manager/components/TaskTable";
import TaskDetailEditor from "@/page/task-manager/components/TaskDetailEditor";
import { useEffect, useMemo, useState, useCallback } from "react";
import type { TaskApiItem } from "@/types/task";
import { Menubar } from "@/common/componets/ui/Menubar";
import { api, API_ENDPOINTS } from "@/config/api";
import { useAuth } from "@/context/AuthContext";

// 날짜 문자열 유틸: 'YYYY-MM-DD'
function isoDate(d: Date) {
  return d.toISOString().slice(0, 10);
}

export default function Dashboard() {
  // 전역 관리자
  const [refreshing, setRefreshing] = useState(false);
  const [managerEmployeeId, setManagerEmployeeId] = useState<number | null>(null);
  const [managerEmployeeName, setManagerEmployeeName] = useState<string>("");
  const { user } = useAuth();

  // 페이지 로드 시 매니저 정보 가져오기
  useEffect(() => {
    const fetchManagerInfo = async () => {
      try {
        // 로그인한 사용자 ID 사용
        if (!user?.id) {
          return;
        }
        
        const employeeId = user.id;
        
        const response = await api.get(API_ENDPOINTS.EMPLOYEE_MANAGER(employeeId));
        
        if (response.data.code === 0 && response.data.result) {
          setManagerEmployeeId(response.data.result.managerEmployeeId);
          setManagerEmployeeName(response.data.result.managerEmployeeName || "");
        }
      } catch (error: any) {
        console.error('매니저 정보 조회 실패:', error);
        // 403 등의 에러가 발생해도 페이지는 계속 표시
        if (error.response?.status === 403) {
          toaster.create({
            title: "권한 없음",
            description: "매니저 정보를 조회할 권한이 없습니다.",
            type: "warning",
          });
        }
      }
    };
    
    fetchManagerInfo();
  }, [user]);

  // 날짜 필터 기본값: 오늘
  const defaultTo = useMemo(() => isoDate(new Date()), []);
  const defaultFrom = useMemo(() => isoDate(new Date()), []);

  // -- form
  const [fromDate, setFromDate] = useState(defaultFrom);
  const [toDate, setToDate] = useState(defaultTo);

  const [rows, setRows] = useState<TaskApiItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Drawer 상태
  const [editorOpen, setEditorOpen] = useState(false);
  const [editing, setEditing] = useState<TaskApiItem | null>(null);

  const fetchList = useCallback(async () => {
    if (fromDate && toDate && fromDate > toDate) {
      setError("시작일이 종료일보다 클 수 없습니다.");
      setRows([]);
      setLoading(false);
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const response = await api.get(API_ENDPOINTS.TASK_DETAIL, {
        params: {
          from: fromDate,
          to: toDate,
          isDeleted: "0",
          employeeId: user?.id?.toString(),
        },
      });
      
      setRows(response.data?.result ?? []);
      setError(null);
    } catch (err: any) {
      console.error('업무 목록 조회 실패:', err);
      setError(err.message);
      // 에러가 발생해도 페이지는 계속 표시 (빈 목록으로)
      setRows([]);
      
      if (err.response?.status === 403) {
        toaster.create({
          title: "권한 없음",
          description: "업무 목록을 조회할 권한이 없습니다.",
          type: "warning",
        });
      }
    } finally {
      setLoading(false);
    }
  }, [fromDate, toDate]);

  useEffect(() => {
    fetchList();
  }, [fetchList, refreshing]);

  // 신규 등록 버튼
  const onCreate = () => {
    setEditing(null);
    setEditorOpen(true);
  };

  // 행 클릭 → 수정
  const onEdit = (item: TaskApiItem) => {
    setEditing(item);
    setEditorOpen(true);
  };

  // 저장 콜백
  const onSaved = () => {
    setEditorOpen(false);
    fetchList();
    //toast({ status: "success", title: "저장되었습니다." });
    toaster.create({
        title: "success",
        description: "저장되었습니다.",
        })
  };

  return (
    <Stack gap={6}>
      <Menubar />
      <Box>
        <HStack justify="space-between" align="center">
          <Heading size="md">진행/예정 업무</Heading>

          {/* 우측 날짜 필터 + 신규 버튼 */}
          <HStack gap={2}>
            <Input
              type="date"
              size="sm"
              value={fromDate}
              onChange={(e) => setFromDate(e.target.value)}
              aria-label="시작일"
            />
            <Text>~</Text>
            <Input
              type="date"
              size="sm"
              value={toDate}
              onChange={(e) => setToDate(e.target.value)}
              aria-label="종료일"
            />
            <Button size="sm" onClick={onCreate}>신규 등록</Button>
          </HStack>
        </HStack>
      </Box>

      {error ? (
        <Text color="red.500">에러: {error}</Text>
      ) : (
        <TaskTable rows={rows} loading={loading} onRowClick={onEdit} />
      )}

      {/* 생성/수정 Drawer */}
      <TaskDetailEditor
        open={editorOpen}
        onClose={() => setEditorOpen(false)}
        onSaved={onSaved}
        initialData={editing}
        setRefreshing={setRefreshing}
        managerEmployeeId={managerEmployeeId}
        managerEmployeeName={managerEmployeeName}
      />
    </Stack>
  );
}
