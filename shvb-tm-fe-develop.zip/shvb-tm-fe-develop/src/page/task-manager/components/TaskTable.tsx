// src/page/componets/TaskTable.tsx
import { Table, Skeleton, Text, Badge } from "@chakra-ui/react";
import type { TaskApiItem } from "@/types/task";
import { getStatusColor } from "@/constants/status-colorset";

export default function TaskTable({
  rows,
  loading,
  onRowClick,
}: {
  rows: TaskApiItem[];
  loading: boolean;
  onRowClick?: (row: TaskApiItem) => void;
}) {
  const skeletonRows = 6;
  const colCount = 8;

  return (
    <Table.ScrollArea borderWidth="1px" borderRadius="lg">
      <Table.Root size="sm">
        <Table.Header>
          <Table.Row>
            <Table.ColumnHeader>부서명</Table.ColumnHeader>
            <Table.ColumnHeader>업무구분</Table.ColumnHeader>
            <Table.ColumnHeader>업무유형</Table.ColumnHeader>
            <Table.ColumnHeader>업무명</Table.ColumnHeader>
            <Table.ColumnHeader>업무내용</Table.ColumnHeader>
            <Table.ColumnHeader>업무현황</Table.ColumnHeader>
            <Table.ColumnHeader>소요시간</Table.ColumnHeader>
            <Table.ColumnHeader>업무책임자</Table.ColumnHeader>
          </Table.Row>
        </Table.Header>

        <Table.Body aria-busy={loading}>
          {loading ? (
            Array.from({ length: skeletonRows }).map((_, rIdx) => (
              <Table.Row key={`sk-${rIdx}`}>
                {Array.from({ length: colCount }).map((_, cIdx) => (
                  <Table.Cell key={`skc-${rIdx}-${cIdx}`}><Skeleton height="1em" /></Table.Cell>
                ))}
              </Table.Row>
            ))
          ) : rows.length === 0 ? (
            <Table.Row>
              <Table.Cell colSpan={colCount}>
                <Text color="gray.500">표시할 데이터가 없습니다.</Text>
              </Table.Cell>
            </Table.Row>
          ) : (
            rows.map((row) => (
              <Table.Row
                key={row.taskDetailId}
                onClick={onRowClick ? () => onRowClick(row) : undefined}
                style={onRowClick ? { cursor: "pointer" } : undefined}
              >
                <Table.Cell>{row.departmentName}</Table.Cell>
                <Table.Cell>{row.taskCategoryName}</Table.Cell>
                <Table.Cell>{row.taskTypeName}</Table.Cell>
                <Table.Cell>{row.taskTitle}</Table.Cell>
                <Table.Cell>{row.content}</Table.Cell>
                <Table.Cell>
                  <Badge colorPalette={getStatusColor(row.taskStatus)} variant="solid" >
                    {row.taskStatus}
                  </Badge>
                </Table.Cell>
                <Table.Cell>{row.durationMinutes}</Table.Cell>
                <Table.Cell>{row.assignerEmployeeName}</Table.Cell>
              </Table.Row>
            ))
          )}
        </Table.Body>
      </Table.Root>
    </Table.ScrollArea>
  );
}
