import { Box, Button, Card, Heading, Input, Stack, Text, VStack } from "@chakra-ui/react";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";

export default function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const navigate = useNavigate();
  const { login } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      await login(username, password);
      navigate("/");
    } catch (err: any) {
      setError(err.message || "로그인에 실패했습니다.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box
      minH="100vh"
      display="flex"
      alignItems="center"
      justifyContent="center"
      bg="gray.50"
      _dark={{ bg: "gray.900" }}
    >
      <Card.Root maxW="md" w="full" p={8} boxShadow="lg">
        <Card.Header>
          <VStack gap={2}>
            <Heading size="lg">SHVB · Task Manager</Heading>
            <Text color="gray.600" _dark={{ color: "gray.400" }}>
              로그인하여 업무를 관리하세요
            </Text>
          </VStack>
        </Card.Header>

        <Card.Body>
          <form onSubmit={handleSubmit}>
            <Stack gap={4}>
              <Stack gap={2}>
                <Text fontSize="sm" fontWeight="medium">아이디</Text>
                <Input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="아이디를 입력하세요"
                  required
                />
              </Stack>

              <Stack gap={2}>
                <Text fontSize="sm" fontWeight="medium">비밀번호</Text>
                <Input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="비밀번호를 입력하세요"
                  required
                />
              </Stack>

              {error && (
                <Text color="red.500" fontSize="sm">
                  {error}
                </Text>
              )}

              <Button
                type="submit"
                colorScheme="blue"
                width="full"
                loading={loading}
                mt={2}
              >
                로그인
              </Button>
            </Stack>
          </form>
        </Card.Body>

        <Card.Footer>
          <VStack gap={1} w="full">
            <Text fontSize="sm" fontWeight="medium" color="gray.700" _dark={{ color: "gray.300" }}>
              테스트 계정
            </Text>
            <Text fontSize="xs" color="gray.600" _dark={{ color: "gray.400" }}>
              kimhaneul / password123
            </Text>
            <Text fontSize="xs" color="gray.600" _dark={{ color: "gray.400" }}>
              parkseojun / password123
            </Text>
            <Text fontSize="xs" color="gray.600" _dark={{ color: "gray.400" }}>
              janggaeun / password123
            </Text>
          </VStack>
        </Card.Footer>
      </Card.Root>
    </Box>
  );
}
