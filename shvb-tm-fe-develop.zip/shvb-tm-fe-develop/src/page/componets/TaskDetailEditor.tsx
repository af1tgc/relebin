// src/page/componets/TaskDetailEditor.tsx
import {
  Button, CloseButton, Drawer, Portal, Stack, Input, Textarea,
  NumberInput, HStack, Text, Box, Spinner
} from "@chakra-ui/react";
import { useEffect, useRef, useState } from "react";
import type { TaskApiItem, TaskItem, EmployeeItem } from "@/types/task";
import { API_ENDPOINTS, api } from "@/config/api";

function isoDate(d: Date) { return d.toISOString().slice(0, 10); }

export default function TaskDetailEditor({
  open,
  onClose,
  onSaved,
  initialData,
  setRefreshing,
}: {
  open: boolean;
  onClose: () => void;
  onSaved: () => void;
  initialData: TaskApiItem | null;
  setRefreshing: (val: boolean | ((prev: boolean) => boolean)) => void;
}) {
  const isEdit = !!initialData;

  // --- 폼 상태 ---
  const [taskId, setTaskId] = useState(0);
  const [workDate, setWorkDate] = useState(isoDate(new Date()));
  const [content, setContent] = useState("");
  const [duration, setDuration] = useState<string>("60");
  const [assignerEmployeeId, setAssignerEmployeeId] = useState(0);
  const [linkUrl, setLinkUrl] = useState("");
  const [remark, setRemark] = useState("");
  const [saving, setSaving] = useState(false);

  // --- TaskType 검색 상태 ---
  const [searchQuery, setSearchQuery] = useState("");
  const [suggestions, setSuggestions] = useState<TaskItem[]>([]);
  const [searching, setSearching] = useState(false);
  const [selectedTaskType, setSelectedTaskType] = useState<TaskItem | null>(null);
  const abortRef = useRef<AbortController | null>(null);

  // --- 업무책임자 검색 상태 ---
  const [assignerQuery, setAssignerQuery] = useState("");
  const [assignerSuggestions, setAssignerSuggestions] = useState<EmployeeItem[]>([]);
  const [assignerSearching, setAssignerSearching] = useState(false);
  const [selectedAssigner, setSelectedAssigner] = useState<EmployeeItem | null>(null);
  const assignerAbortRef = useRef<AbortController | null>(null);

  // 초기값 로드 (수정 모드면 기존 값 반영)
  useEffect(() => {
    if (initialData) {
      setTaskId(initialData.taskId ?? 0);
      setWorkDate(initialData.workDate ?? isoDate(new Date()));
      setContent(initialData.content ?? "");
      setDuration(String(initialData.durationMinutes ?? 60));
      setAssignerEmployeeId(initialData.assignerEmployeeId ?? 0);
      setAssignerQuery(initialData.assignerEmployeeName ?? "");
      setSelectedAssigner(
        initialData.assignerEmployeeId
          ? {
              employeeId: initialData.assignerEmployeeId,
              employeeName: initialData.assignerEmployeeName,
            } as EmployeeItem
          : null
      );
      setLinkUrl(initialData.linkUrl ?? "");
      setRemark(initialData.remark ?? "");

      if (initialData.taskTypeId) {
        const preset: TaskItem = {
          taskId: initialData.taskId,
          title: initialData.taskTitle,
          taskTypeId: initialData.taskTypeId,
          taskTypeName: initialData.taskTypeName ?? "",
          taskCategoryName: initialData.taskCategoryName ?? "",
        };
        setSelectedTaskType(preset);
        setSearchQuery(preset.title || "");
        setSuggestions([]);
      }
    } else {
      setTaskId(0);
      setWorkDate(isoDate(new Date()));
      setContent("");
      setDuration("60");
      setAssignerEmployeeId(0);
      setAssignerQuery("");
      setSelectedAssigner(null);
      setLinkUrl("");
      setRemark("");
      setSelectedTaskType(null);
      setSearchQuery("");
      setSuggestions([]);
    }
  }, [initialData, open]);

  // TaskType 검색 (디바운스 & 2글자 이상)
  useEffect(() => {
    if (!open) return;
    if (searchQuery.trim().length < 2) {
      setSuggestions([]);
      if (!selectedTaskType) {
      }
      return;
    }

    setSearching(true);
    abortRef.current?.abort();
    const ac = new AbortController();
    abortRef.current = ac;

    const timer = setTimeout(async () => {
      try {
        const res = await api.get(API_ENDPOINTS.TASK_LIST, {
          params: { q: searchQuery.trim() },
          signal: ac.signal,
        });
        setSuggestions(res.data.result ?? []);
      } catch (e) {
        if ((e as any)?.name !== "AbortError") {
          setSuggestions([]);
        }
      } finally {
        setSearching(false);
      }
    }, 250); // 250ms 디바운스

    return () => {
      clearTimeout(timer);
      ac.abort();
    };
  }, [searchQuery, open, selectedTaskType]);

  // 업무책임자 검색 (2글자 이상, 디바운스)
  useEffect(() => {
    if (!open) return;
    if (assignerQuery.trim().length < 2) {
      setAssignerSuggestions([]);
      return;
    }
    setAssignerSearching(true);
    assignerAbortRef.current?.abort();
    const ac = new AbortController();
    assignerAbortRef.current = ac;

    const timer = setTimeout(async () => {
      try {
        // 실제 API 엔드포인트에 맞게 수정 필요
        const res = await api.get(API_ENDPOINTS.EMPLOYEE, {
          params: { q: assignerQuery.trim() },
          signal: ac.signal,
        });
        setAssignerSuggestions(res.data.result ?? []);
      } catch (e) {
        if ((e as any)?.name !== "AbortError") {
          setAssignerSuggestions([]);
        }
      } finally {
        setAssignerSearching(false);
      }
    }, 250);

    return () => {
      clearTimeout(timer);
      ac.abort();
    };
  }, [assignerQuery, open]);

  const selectTaskType = (opt: TaskItem) => {
    setSelectedTaskType(opt);
    setSearchQuery(opt.title || "");
    setTaskId(opt.taskId);
    setSuggestions([]);
  };

  const clearTaskType = () => {
    setSelectedTaskType(null);
    setSearchQuery("");
    setSuggestions([]);
  };

  const selectAssigner = (opt: EmployeeItem) => {
    setSelectedAssigner(opt);
    setAssignerEmployeeId(opt.employeeId);
    setAssignerQuery(opt.employeeName);
    setAssignerSuggestions([]);
  };

  const clearAssigner = () => {
    setSelectedAssigner(null);
    setAssignerEmployeeId(0);
    setAssignerQuery("");
    setAssignerSuggestions([]);
  };

  const submit = async () => {
    setSaving(true);
    try {
        if (!isEdit && !selectedTaskType?.taskTypeId) {
        throw new Error("업무 유형을 선택하세요.");
        }

        const payload: any = {
          taskId,
          employeeId: 6, // 로그인 사용자의 ID로 대체
          workDate,
          content,
          durationMinutes: Number(duration),
          assignerEmployeeId: assignerEmployeeId || null,
          linkUrl: linkUrl || null,
          remark: remark || null,
        };

        if (isEdit && initialData) {
        payload.taskId = initialData.taskId;
        } else if (selectedTaskType) {
        payload.taskTypeId = selectedTaskType.taskTypeId;
        }

        const url = isEdit
        ? API_ENDPOINTS.TASK_DETAILS_BY_ID(initialData!.taskDetailId)
        : API_ENDPOINTS.TASK_DETAILS;

        const response = await api.post(url, payload);
        
        if (response.data.code !== 0) {
          throw new Error(response.data.message || "저장에 실패했습니다.");
        }

        onSaved();
    } catch (e: any) {
        alert(e.message ?? "오류가 발생했습니다.");
    } finally {
        setSaving(false);
        setRefreshing(prev => !prev);
    }
    };

  return (
    <Drawer.Root
      open={open}
      onOpenChange={(e) => { if (!e.open) onClose(); }}
      placement="end"
      size="xl"
    >
      <Portal>
        <Drawer.Backdrop />
        <Drawer.Positioner>
          <Drawer.Content>
            <Drawer.Header>
              <Drawer.Title>{isEdit ? "업무 기록 수정" : "업무 기록 등록"}</Drawer.Title>
              <Drawer.CloseTrigger asChild>
                <CloseButton />
              </Drawer.CloseTrigger>
            </Drawer.Header>

            <Drawer.Body>
              <Stack gap="3">
                {/* 업무유형 검색/선택 */}
                <HStack align="start">
                  <Text w="140px" textAlign="left" mt="2">업무명</Text>
                  <Box flex="1" position="relative" display="flex" flexDirection="column" alignItems="flex-start">
                    <Input
                      placeholder="업무명 검색 (2자 이상)"
                      value={searchQuery}
                      onChange={(e) => {
                        setSearchQuery(e.target.value);
                        if (!e.target.value) setSelectedTaskType(null);
                      }}
                    />
                    {selectedTaskType && (
                      <Text mt="2" color="gray.600">
                        {"["}
                        {selectedTaskType.taskCategoryName ? `${selectedTaskType.taskCategoryName} > ` : ""}
                        {selectedTaskType.taskTypeName}
                        {"] "}
                        <b>{selectedTaskType.title}</b>
                        <CloseButton size="sm" aria-label="Clear" onClick={clearTaskType} />
                      </Text>
                    )}
                    {/* 제안 드롭다운 */}
                    {(searchQuery.trim().length >= 2 && !selectedTaskType) && (
                      <Box
                        position="absolute"
                        top="calc(100% + 6px)"
                        left={0}
                        right={0}
                        borderWidth="1px"
                        borderRadius="md"
                        bg="bg"
                        zIndex={10}
                        maxH="280px"
                        overflowY="auto"
                        p="2"
                      >
                        {searching && (
                          <HStack p="2" color="gray.500">
                            <Spinner size="sm" />
                            <Text>검색 중…</Text>
                          </HStack>
                        )}
                        {!searching && suggestions.length === 0 && (
                          <Text p="2" color="gray.500">검색 결과가 없습니다.</Text>
                        )}
                        {!searching && suggestions.map((opt) => (
                          <Box
                            key={opt.taskId}
                            p="2"
                            borderRadius="sm"
                            _hover={{ bg: "bg.muted", cursor: "pointer" }}
                            onClick={() => selectTaskType(opt)}
                          >
                            <Text>
                              {"["}
                              {opt.taskCategoryName ? `${opt.taskCategoryName} > ` : ""}
                              {opt.taskTypeName}
                              {"] "}
                              <b>{opt.title}</b>
                            </Text>
                          </Box>
                        ))}
                      </Box>
                    )}
                  </Box>
                </HStack>

                <HStack align="start">
                  <Text w="140px" textAlign="left">작업일</Text>
                  <Box flex="1" display="flex" flexDirection="column" alignItems="flex-start">
                    <Input type="date" value={workDate} onChange={(e) => setWorkDate(e.target.value)} />
                  </Box>
                </HStack>

                <HStack align="start">
                  <Text w="140px" textAlign="left">소요시간(분)</Text>
                  <Box flex="1" display="flex" flexDirection="column" alignItems="flex-start">
                    <NumberInput.Root
                      value={duration}
                      onValueChange={(e) => setDuration(e.value)}
                      min={1}
                      step={5}
                    >
                      <NumberInput.Control />
                      <NumberInput.Input />
                    </NumberInput.Root>
                  </Box>
                </HStack>

                <HStack align="start">
                  <Text w="140px" textAlign="left">내용</Text>
                  <Box flex="1" display="flex" flexDirection="column" alignItems="flex-start">
                    <Textarea value={content} onChange={(e) => setContent(e.target.value)} rows={6} />
                  </Box>
                </HStack>

                <HStack align="start">
                  <Text w="140px" textAlign="left">업무책임자</Text>
                  <Box flex="1" position="relative" display="flex" flexDirection="column" alignItems="flex-start">
                    <HStack w="100%">
                      <Input
                        value={assignerQuery}
                        onChange={(e) => {
                          const value = e.target.value;
                          setAssignerQuery(value);
                          if (!value) {
                            setSelectedAssigner(null);
                            setAssignerEmployeeId(0);
                          }
                        }}
                        placeholder="업무책임자 검색 (2자 이상)"
                      />
                      {selectedAssigner && (
                        <CloseButton size="sm" aria-label="Clear" onClick={clearAssigner} />
                      )}
                    </HStack>
                    {(assignerQuery.trim().length >= 2 && !selectedAssigner) && (
                      <Box
                        position="absolute"
                        top="calc(100% + 6px)"
                        left={0}
                        right={0}
                        borderWidth="1px"
                        borderRadius="md"
                        bg="bg"
                        zIndex={10}
                        maxH="280px"
                        overflowY="auto"
                        p="2"
                      >
                        {assignerSearching && (
                          <HStack p="2" color="gray.500">
                            <Spinner size="sm" />
                            <Text>검색 중…</Text>
                          </HStack>
                        )}
                        {!assignerSearching && assignerSuggestions.length === 0 && (
                          <Text p="2" color="gray.500">검색 결과가 없습니다.</Text>
                        )}
                        {!assignerSearching && assignerSuggestions.map((opt) => (
                          <Box
                            key={opt.employeeId}
                            p="2"
                            borderRadius="sm"
                            _hover={{ bg: "bg.muted", cursor: "pointer" }}
                            onClick={() => selectAssigner(opt)}
                          >
                            <Text>
                              <b>{opt.employeeName}</b>
                            </Text>
                          </Box>
                        ))}
                      </Box>
                    )}
                  </Box>
                </HStack>

                <HStack align="start">
                  <Text w="140px" textAlign="left">링크</Text>
                  <Box flex="1" display="flex" flexDirection="column" alignItems="flex-start">
                    <Input value={linkUrl} onChange={(e) => setLinkUrl(e.target.value)} placeholder="http(s)://" />
                  </Box>
                </HStack>

                <HStack align="start">
                  <Text w="140px" textAlign="left">비고</Text>
                  <Box flex="1" display="flex" flexDirection="column" alignItems="flex-start">
                    <Input value={remark} onChange={(e) => setRemark(e.target.value)} />
                  </Box>
                </HStack>
              </Stack>
            </Drawer.Body>

            <Drawer.Footer>
              <Button variant="outline" mr="2" onClick={onClose}>취소</Button>
              <Button loading={saving} onClick={submit} colorPalette="blue">
                {isEdit ? "수정" : "등록"}
              </Button>
            </Drawer.Footer>
          </Drawer.Content>
        </Drawer.Positioner>
      </Portal>
    </Drawer.Root>
  );
}
