import { Box, Button, Heading, HStack, Stack, Grid } from "@chakra-ui/react";
import { Menubar } from "@/common/componets/ui/Menubar";
import { useState, useEffect } from "react";
import { TextFilter } from "./components/filter/TextFilter";
import { CategorySelectFilter } from "./components/filter/CategorySelectFilter";
import { LuFilter, LuFilterX, LuPlus } from "react-icons/lu";
import { AdminTypeTable } from "@/page/admin-type/components/AdminTypeTable";
import type { TaskTypeItem, PageInfo, SortOption } from "@/page/admin-type/components/AdminTypeTable";
import { AdminTypeEditor } from "./components/AdminTypeEditor";
import { api, API_ENDPOINTS } from "@/config/api";

export default function AdminTypeMain() {
  // 필터 상태 관리
  const [filters, setFilters] = useState({
    departmentId: "",
    taskCategoryId: "",
    taskTypeName: "",
  });

  const [showFilters, setShowFilters] = useState(false);
  
  // 부서 및 카테고리 데이터 상태
  const [departments, setDepartments] = useState<Array<{value: string; label: string}>>([]);
  const [departmentsLoading, setDepartmentsLoading] = useState(false);
  
  // 업무구분 데이터 상태
  const [taskCategories, setTaskCategories] = useState<Array<{value: string; label: string}>>([]);
  const [categoriesLoading, setCategoriesLoading] = useState(false);
  
  // 카테고리 데이터 상태
  const [typeData, setTypeData] = useState<TaskTypeItem[]>([]);
  const [pageInfo, setPageInfo] = useState<PageInfo>({
    currentPage: 0,
    size: 10,
    totalElements: 0,
    totalPages: 0,
    first: true,
    last: true
  });
  const [loading, setLoading] = useState(false);
  const [currentSort, setCurrentSort] = useState<SortOption>({
    field: 'taskTypeId',
    direction: 'asc'
  });
  const [editorOpen, setEditorOpen] = useState(false);
  const [editingType, setEditingType] = useState<TaskTypeItem | null>(null);

  // 부서 데이터 로드
  useEffect(() => {
    const fetchDepartments = async () => {
      setDepartmentsLoading(true);
      try {
        const response = await api.get(API_ENDPOINTS.DEPARTMENT);
        if (response.data.code === 0 && response.data.result) {
          const depts = response.data.result.map((dept: any) => ({
            value: dept.departmentId.toString(),
            label: dept.departmentName
          }));
          setDepartments([{ value: "", label: "전체" }, ...depts]);
        }
      } catch (error) {
        console.error('부서 조회 실패:', error);
        setDepartments([]);
      } finally {
        setDepartmentsLoading(false);
      }
    };
    fetchDepartments();
  }, []);

  // 업무구분 데이터 로드
  useEffect(() => {
    const fetchTaskCategories = async () => {
      setCategoriesLoading(true);
      try {
        const response = await api.get(API_ENDPOINTS.ADMIN_CATEGORY_LEVEL1);
        if (response.data.code === 0 && response.data.result) {
          const categories = response.data.result.map((cat: any) => ({
            value: cat.categoryId.toString(),
            label: cat.categoryName
          }));
          setTaskCategories([{ value: "", label: "전체" }, ...categories]);
        }
      } catch (error) {
        console.error('업무구분 조회 실패:', error);
        setTaskCategories([]);
      } finally {
        setCategoriesLoading(false);
      }
    };
    fetchTaskCategories();
  }, []);

  const updateFilter = (key: keyof typeof filters, value: string) => {
    setFilters((prev) => ({ ...prev, [key]: value }));
  };

  const fetchTypeList = async (page: number = 0, size?: number, sort?: SortOption) => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      Object.entries(filters).forEach(([key, value]) => {
        if (value) params.append(key, value);
      });
      
      params.append('page', page.toString());
      params.append('size', (size || pageInfo.size || 10).toString());
      
      const sortParam = sort || currentSort;
      params.append('sort', `${sortParam.field},${sortParam.direction}`);

      const response = await api.get(`${API_ENDPOINTS.ADMIN_TASK_TYPE_LIST}?${params.toString()}`);
      const result = response.data;
      if (result.code === 0) {
        setTypeData(result.result.content);
        setPageInfo(result.result.pageInfo);
        if (sort) setCurrentSort(sort);
      }
    } catch (error) {
      console.error('검색 실패:', error);
      setTypeData([]);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = () => {
    fetchTypeList(0);
  };

  const handlePageChange = (page: number) => {
    fetchTypeList(page);
  };

  const handleSizeChange = (size: number) => {
    fetchTypeList(0, size);
  };

  const handleSortChange = (sort: SortOption) => {
    fetchTypeList(pageInfo.currentPage, undefined, sort);
  };

  const handleRowClick = (taskType: TaskTypeItem) => {
    setEditingType(taskType);
    setEditorOpen(true);
  };

  const clearFilters = () => {
    setFilters({
      departmentId: "",
      taskCategoryId: "",
      taskTypeName: "",
    });
  };

  const handleCreateNew = () => {
    setEditingType(null);
    setEditorOpen(true);
  };

  const handleEditorSaved = () => {
    setEditorOpen(false);
    setEditingType(null);
    // 테이블 리프레시
    fetchTypeList(pageInfo.currentPage);
  };

  return (
    <Stack gap={6}>
      <Menubar />
      <Box>
        <HStack justify="space-between" align="center" mb={4}>
          <Heading size="md">업무유형 관리</Heading>
          <HStack gap={2}>
            <Button size="sm" colorScheme="green" onClick={handleCreateNew}>
              <LuPlus />
              신규 등록
            </Button>
            <Button size="sm" variant="plain" color={"green"} onClick={() => setShowFilters(!showFilters)}>
              {showFilters ? <LuFilterX /> : <LuFilter />}
            </Button>
          </HStack>
        </HStack>

        {/* 필터 섹션 */}
        {showFilters && (
          <Box borderWidth="1px" borderRadius="md" p={4} mb={4}>
            <Grid templateColumns="1fr 1fr 1fr auto auto" gap={3} alignItems="end">
              <CategorySelectFilter
                value={filters.departmentId}
                onChange={(value) => updateFilter("departmentId", value)}
                placeholder="부서명"
                options={departments}
                disabled={departmentsLoading}
              />
              <CategorySelectFilter
                value={filters.taskCategoryId}
                onChange={(value) => updateFilter("taskCategoryId", value)}
                placeholder="업무구분"
                options={taskCategories}
                disabled={categoriesLoading}
              />
              <TextFilter
                value={filters.taskTypeName}
                onChange={(value) => updateFilter("taskTypeName", value)}
                placeholder="업무유형명"
                onEnter={handleSearch}
              />
              <Button size="sm" variant="outline" onClick={clearFilters}>
                Clear
              </Button>
              <Button size="sm" colorScheme="blue" onClick={handleSearch}>
                검색
              </Button>
            </Grid>
          </Box>
        )}

        {/* 테이블 섹션 */}
        <AdminTypeTable
          data={typeData}
          pageInfo={pageInfo}
          loading={loading}
          onPageChange={handlePageChange}
          onSizeChange={handleSizeChange}
          onSortChange={handleSortChange}
          currentSort={currentSort}
          onRowClick={handleRowClick}
        />
      </Box>

      {/* 업무유형 편집 Drawer */}
      <AdminTypeEditor
        open={editorOpen}
        onClose={() => setEditorOpen(false)}
        onSaved={handleEditorSaved}
        initialData={editingType}
      />
    </Stack>
  );
}