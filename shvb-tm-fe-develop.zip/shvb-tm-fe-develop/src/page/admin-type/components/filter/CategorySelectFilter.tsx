import { Select, createListCollection } from "@chakra-ui/react";
import { useMemo } from "react";

interface CategoryOption {
  value: string;
  label: string;
}

interface CategorySelectFilterProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  options: CategoryOption[];
  disabled?: boolean;
}

export function CategorySelectFilter({ 
  value, 
  onChange, 
  placeholder, 
  options, 
  disabled = false 
}: CategorySelectFilterProps) {
  const collection = useMemo(() => 
    createListCollection({
      items: options,
    }), [options]
  );

  return (
    <Select.Root
      collection={collection}
      value={value ? [value] : []}
      onValueChange={(e) => onChange(e.value[0] || "")}
      size="sm"
      disabled={disabled}
    >
      <Select.Trigger>
        <Select.ValueText placeholder={placeholder} />
      </Select.Trigger>
      <Select.Positioner>
        <Select.Content>
          {options.map((option, index) => (
            <Select.Item key={option.value || `option-${index}`} item={option.value}>
              <Select.ItemText>{option.label}</Select.ItemText>
            </Select.Item>
          ))}
        </Select.Content>
      </Select.Positioner>
    </Select.Root>
  );
}
