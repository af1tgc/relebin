import {
  Button, CloseButton, Drawer, Portal, Stack, Input,
  HStack, Text, Box
} from "@chakra-ui/react";
import { useState, useEffect } from "react";
import { CategorySelectFilter } from "./filter/CategorySelectFilter";
import type { TaskTypeItem } from "./AdminTypeTable";
import { api, API_ENDPOINTS } from "@/config/api";

interface CategoryOption {
  value: string;
  label: string;
}

interface AdminTypeEditorProps {
  open: boolean;
  onClose: () => void;
  onSaved: () => void;
  initialData: TaskTypeItem | null;
}

export function AdminTypeEditor({
  open,
  onClose,
  onSaved,
  initialData,
}: AdminTypeEditorProps) {
  const isEdit = !!initialData;

  // 폼 상태
  const [taskTypeId, setTaskTypeId] = useState<number | null>(null);
  const [departmentId, setDepartmentId] = useState("");
  const [taskCategoryId, setTaskCategoryId] = useState("");
  const [taskTypeName, setTaskTypeName] = useState("");
  const [saving, setSaving] = useState(false);

  // 카테고리 데이터 상태
  const [departments, setDepartments] = useState<CategoryOption[]>([]);
  const [taskCategories, setTaskCategories] = useState<CategoryOption[]>([]);
  const [categoriesLoading, setCategoriesLoading] = useState(false);

  // 초기값 로드
  useEffect(() => {
    if (initialData) {
      setTaskTypeId(initialData.taskTypeId || null);
      setDepartmentId(initialData.departmentId?.toString() || "");
      setTaskCategoryId(initialData.taskCategoryId?.toString() || "");
      setTaskTypeName(initialData.taskTypeName || "");
    } else {
      setTaskTypeId(null);
      setDepartmentId("");
      setTaskCategoryId("");
      setTaskTypeName("");
    }
  }, [initialData, open]);

  // 부서 데이터 로드
  useEffect(() => {
    if (!open) return;
    
    const fetchDepartments = async () => {
      setCategoriesLoading(true);
      try {
        const response = await api.get(API_ENDPOINTS.DEPARTMENT);
        if (response.data.code === 0 && response.data.result) {
          const depts = response.data.result.map((dept: any) => ({
            value: dept.departmentId.toString(),
            label: dept.departmentName
          }));
          setDepartments(depts);
        }
      } catch (error) {
        console.error('부서 조회 실패:', error);
        setDepartments([]);
      } finally {
        setCategoriesLoading(false);
      }
    };
    fetchDepartments();
  }, [open]);

  // 업무구분 데이터 로드
  useEffect(() => {
    if (!open) return;
    
    const fetchTaskCategories = async () => {
      setCategoriesLoading(true);
      try {
        const response = await api.get(API_ENDPOINTS.ADMIN_CATEGORY_LEVEL1);
        const result = response.data;
        
        if (result.code === 0 && result.result) {
          const categories = result.result.map((cat: any) => ({
            value: String(cat.categoryId),
            label: cat.categoryName
          }));
          setTaskCategories(categories);
        }
      } catch (error) {
        console.error('업무구분 조회 실패:', error);
        setTaskCategories([]);
      } finally {
        setCategoriesLoading(false);
      }
    };

    fetchTaskCategories();
  }, [open]);



  const submit = async () => {
    setSaving(true);
    try {
      if (!departmentId) throw new Error("부서명을 선택하세요.");
      if (!taskCategoryId) throw new Error("업무구분을 선택하세요.");
      if (!taskTypeName.trim()) throw new Error("업무유형명을 입력하세요.");

      const payload: any = {
        departmentId: Number(departmentId),
        taskCategoryId: Number(taskCategoryId),
        taskTypeName: taskTypeName.trim(),
      };

      // 수정 시에는 taskTypeId 포함
      if (isEdit && taskTypeId) {
        payload.taskTypeId = taskTypeId;
      }

      const url = isEdit 
        ? API_ENDPOINTS.ADMIN_TASK_TYPE_BY_ID(taskTypeId!)
        : API_ENDPOINTS.ADMIN_TASK_TYPE;
      
      const response = await api.post(url, payload);
      
      if (response.data.code !== 0) {
        throw new Error(response.data.result || "저장에 실패했습니다.");
      }
      
      onSaved();
    } catch (e: any) {
      alert(e.message ?? "오류가 발생했습니다.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Drawer.Root
      open={open}
      onOpenChange={(e) => { if (!e.open) onClose(); }}
      placement="end"
      size="xl"
    >
      <Portal>
        <Drawer.Backdrop />
        <Drawer.Positioner>
          <Drawer.Content>
            <Drawer.Header>
              <Drawer.Title>{isEdit ? "업무유형 수정" : "새 업무유형 등록"}</Drawer.Title>
              <Drawer.CloseTrigger asChild>
                <CloseButton />
              </Drawer.CloseTrigger>
            </Drawer.Header>

            <Drawer.Body>
              <Stack gap="4">
                {/* 부서명 */}
                <HStack align="start">
                  <Text w="140px" textAlign="left">부서명</Text>
                  <Box flex="1">
                    <CategorySelectFilter
                      value={departmentId}
                      onChange={setDepartmentId}
                      placeholder="부서명을 선택하세요"
                      options={departments}
                      disabled={categoriesLoading}
                    />
                  </Box>
                </HStack>

                {/* 업무구분 선택 */}
                <HStack align="start">
                  <Text w="140px" textAlign="left">업무구분</Text>
                  <Box flex="1">
                    <CategorySelectFilter
                      value={taskCategoryId}
                      onChange={setTaskCategoryId}
                      placeholder="업무구분을 선택하세요"
                      options={taskCategories}
                      disabled={categoriesLoading}
                    />
                  </Box>
                </HStack>

                {/* 업무유형명 */}
                <HStack align="start">
                  <Text w="140px" textAlign="left">업무유형명</Text>
                  <Box flex="1">
                    <Input
                      value={taskTypeName}
                      onChange={(e) => setTaskTypeName(e.target.value)}
                      placeholder="업무유형명을 입력하세요"
                    />
                  </Box>
                </HStack>
              </Stack>
            </Drawer.Body>

            <Drawer.Footer>
              <Button variant="outline" mr="2" onClick={onClose}>취소</Button>
              <Button loading={saving} onClick={submit} colorScheme="blue">
                {isEdit ? "수정" : "등록"}
              </Button>
            </Drawer.Footer>
          </Drawer.Content>
        </Drawer.Positioner>
      </Portal>
    </Drawer.Root>
  );
}