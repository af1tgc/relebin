export interface StatusOption {
  value: string;
  label: string;
  colorScheme: string;
}

export const TASK_STATUS_OPTIONS: StatusOption[] = [
  { value: "", label: "전체", colorScheme: "gray" },
  { value: "PLANNED", label: "계획됨", colorScheme: "gray" },
  { value: "ACTIVE", label: "진행중", colorScheme: "blue" },
  { value: "ON_HOLD", label: "보류", colorScheme: "yellow" },
  { value: "DELAYED", label: "지연", colorScheme: "red" },
  { value: "DONE", label: "완료", colorScheme: "cyan" },
];

export function getStatusColor(status: string): string {
  const option = TASK_STATUS_OPTIONS.find(opt => opt.value === status);
  return option?.colorScheme || "gray";
}

export function getStatusLabel(status: string): string {
  const option = TASK_STATUS_OPTIONS.find(opt => opt.value === status);
  return option?.label || status;
}
