# 빠른 시작 가이드 (Quick Start)

## 🚀 5분 안에 배포하기

### Step 1: 프로젝트 Clone

```bash
cd /home/app
git clone <repository-url> shvb-tm
cd shvb-tm
```

### Step 2: 권한 설정

```bash
chmod +x deploy/deploy.sh
chmod +x mvnw
```

### Step 3: 설정 수정 (필요시)

```bash
# 서버 환경에 맞게 경로 수정
vi deploy/deploy.sh

# 수정 항목:
# - APP_HOME (기본값: /home/app/shvb-tm)
# - BRANCH (기본값: main)
```

### Step 4: 배포 실행

```bash
./deploy/deploy.sh
```

### Step 5: 확인

```bash
# 상태 확인
./deploy/deploy.sh status

# 로그 확인
tail -f logs/app.log

# 애플리케이션 접속
curl http://localhost:8080
```

---

## 📝 주요 명령어

```bash
# 배포 (Git Pull + Build + Restart)
./deploy/deploy.sh

# 시작
./deploy/deploy.sh start

# 중지
./deploy/deploy.sh stop

# 재시작
./deploy/deploy.sh restart

# 상태 확인
./deploy/deploy.sh status
```

---

## 🔍 배포 확인 체크리스트

- [ ] Java 11 이상 설치됨
- [ ] Git 설치됨
- [ ] 배포 스크립트 실행 권한 있음
- [ ] 8080 포트 사용 가능함
- [ ] 애플리케이션이 정상 실행됨
- [ ] 로그에 에러 없음

---

## ⚠️ 자주 발생하는 문제

### 포트 이미 사용 중
```bash
lsof -i :8080
kill -9 <PID>
```

### 빌드 실패
```bash
./mvnw clean
./deploy/deploy.sh
```

### 로그 확인
```bash
tail -100 logs/app.log
```

---

더 자세한 내용은 [README.md](./README.md)를 참고하세요.
