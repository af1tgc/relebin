# 배포 가이드

## 📋 사전 준비

### 1. 서버 환경 설정

```bash
# Java 11 이상 설치 확인
java -version

# Git 설치 확인
git --version

# 애플리케이션 디렉토리 생성
sudo mkdir -p /home/app/shvb-tm
sudo chown $USER:$USER /home/app/shvb-tm
```

### 2. 프로젝트 Clone

```bash
cd /home/app
git clone <repository-url> shvb-tm
cd shvb-tm
```

### 3. 배포 스크립트 권한 설정

```bash
chmod +x deploy/deploy.sh
chmod +x mvnw
```

### 4. 설정 파일 수정

배포 스크립트의 설정을 서버 환경에 맞게 수정:

```bash
vi deploy/deploy.sh
```

수정 필요 항목:
- `APP_HOME`: 애플리케이션 홈 디렉토리 경로
- `BRANCH`: 배포할 Git 브랜치 (기본: main)
- `JAR_NAME`: JAR 파일명 (pom.xml의 artifactId와 version 확인)
- `JAVA_OPTS`: JVM 옵션 (메모리 설정 등)

---

## 🚀 배포 방법

### 전체 배포 (Git Pull + Build + Restart)

```bash
cd /home/app/shvb-tm
./deploy/deploy.sh deploy
```

또는 간단하게:

```bash
./deploy/deploy.sh
```

### 배포 프로세스

1. **애플리케이션 중지** (Graceful Shutdown)
2. **Git Pull** (최신 코드 다운로드)
3. **Maven Build** (JAR 생성, 기존 JAR 백업)
4. **애플리케이션 시작**
5. **상태 확인** (Health Check)

---

## 🛠️ 개별 명령어

### 애플리케이션 시작

```bash
./deploy/deploy.sh start
```

### 애플리케이션 중지

```bash
./deploy/deploy.sh stop
```

### 애플리케이션 재시작 (코드 변경 없이)

```bash
./deploy/deploy.sh restart
```

### 상태 확인

```bash
./deploy/deploy.sh status
```

---

## 📊 로그 확인

### 실시간 로그 확인

```bash
tail -f /home/app/shvb-tm/logs/app.log
```

### 에러 로그 확인

```bash
grep -i "error" /home/app/shvb-tm/logs/app.log
```

### 최근 로그 확인

```bash
tail -100 /home/app/shvb-tm/logs/app.log
```

---

## 🔧 트러블슈팅

### 1. 빌드 실패

**문제**: Maven 빌드 실패

**해결**:
```bash
# Maven Wrapper 재다운로드
rm -rf ~/.m2/wrapper
./mvnw clean

# 다시 빌드
./mvnw clean package -DskipTests
```

### 2. 포트 이미 사용 중

**문제**: 8080 포트가 이미 사용 중

**해결**:
```bash
# 포트 사용 프로세스 확인
lsof -i :8080

# 또는
netstat -tuln | grep 8080

# 강제 종료
kill -9 <PID>
```

### 3. 메모리 부족

**문제**: OutOfMemoryError 발생

**해결**: `deploy.sh`의 JAVA_OPTS 수정
```bash
# 메모리 증가
JAVA_OPTS="-Xms1024m -Xmx2048m"
```

### 4. 애플리케이션 시작 실패

**문제**: 시작 후 즉시 종료

**해결**:
```bash
# 상세 로그 확인
cat /home/app/shvb-tm/logs/app.log

# 수동 실행으로 에러 확인
cd /home/app/shvb-tm
java -jar target/SHVBTaskManager-0.0.1-SNAPSHOT.jar
```

---

## 🔄 롤백 (이전 버전으로 복구)

### 1. Git 롤백

```bash
cd /home/app/shvb-tm

# 커밋 히스토리 확인
git log --oneline -10

# 이전 커밋으로 롤백
git reset --hard <commit-hash>

# 다시 배포
./deploy/deploy.sh
```

### 2. 백업 JAR 사용

```bash
cd /home/app/shvb-tm

# 백업 파일 확인
ls -lh backup/

# 백업 파일 복원
cp backup/SHVBTaskManager-0.0.1-SNAPSHOT.jar.20250911_143000 target/SHVBTaskManager-0.0.1-SNAPSHOT.jar

# 재시작
./deploy/deploy.sh restart
```

---

## 📁 디렉토리 구조

```
/home/app/shvb-tm/
├── deploy/
│   └── deploy.sh          # 배포 스크립트
├── logs/
│   └── app.log           # 애플리케이션 로그
├── backup/
│   └── *.jar             # 이전 버전 JAR 백업
├── target/
│   └── *.jar             # 현재 실행 중인 JAR
├── app.pid               # 프로세스 ID 파일
└── src/
    └── ...
```

---

## ⚙️ Crontab 설정 (자동 배포)

매일 새벽 2시 자동 배포 예제:

```bash
# crontab 편집
crontab -e

# 추가
0 2 * * * cd /home/app/shvb-tm && ./deploy/deploy.sh deploy >> /home/app/shvb-tm/logs/deploy.log 2>&1
```

---

## 🔐 보안 권장사항

1. **배포 스크립트 권한**: 실행 권한만 부여
   ```bash
   chmod 750 deploy/deploy.sh
   ```

2. **로그 디렉토리 권한**: 소유자만 쓰기 가능
   ```bash
   chmod 755 logs/
   ```

3. **설정 파일 보호**: application.yml 등 민감 정보 포함 파일
   ```bash
   chmod 600 src/main/resources/application.yml
   ```

---

## 📞 문의

배포 관련 문제 발생 시:
1. 로그 확인: `/home/app/shvb-tm/logs/app.log`
2. 상태 확인: `./deploy/deploy.sh status`
3. 개발팀 문의
