#!/bin/bash

###############################################################################
# SHVB Task Manager 배포 스크립트
# Git Pull 기반 무중단 배포
#
# 사용법:
#   ./deploy.sh          - 전체 배포 (git pull + build + restart)
#   ./deploy.sh start    - 애플리케이션 시작
#   ./deploy.sh stop     - 애플리케이션 중지
#   ./deploy.sh restart  - 애플리케이션 재시작
#   ./deploy.sh status   - 애플리케이션 상태 확인
#
# 설정 확인 사항:
#   - APP_HOME: 애플리케이션 홈 디렉토리
#   - BRANCH: 배포할 Git 브랜치
#   - SPRING_PROFILE: Spring Profile (local/dev/real)
#     * application.yml의 프로파일과 일치해야 함!
###############################################################################

# 색상 정의
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# 설정
APP_NAME="shvb-tm"
APP_HOME="/home/yosub/${APP_NAME}"
BRANCH="develop"  # 배포할 브랜치 (필요시 수정)
SPRING_PROFILE="dev"  # Spring Profile (local/dev/real)
JAR_NAME="shvb-tm-0.0.1-SNAPSHOT.jar"
JAR_PATH="${APP_HOME}/target/${JAR_NAME}"
PID_FILE="${APP_HOME}/app.pid"
LOG_DIR="${APP_HOME}/logs"
BACKUP_DIR="${APP_HOME}/backup"
MAVEN_CMD="./mvnw"

# 로그 디렉토리 생성
mkdir -p ${LOG_DIR}
mkdir -p ${BACKUP_DIR}

###############################################################################
# 함수 정의
###############################################################################

# 로그 출력 함수
log_info() {
    echo -e "${GREEN}[INFO]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1"
}

# 애플리케이션 실행 여부 확인
is_running() {
    if [ -f ${PID_FILE} ]; then
        PID=$(cat ${PID_FILE})
        if ps -p ${PID} > /dev/null 2>&1; then
            return 0
        fi
    fi
    return 1
}

# 애플리케이션 중지
stop_app() {
    log_info "애플리케이션 중지 중..."
    
    if is_running; then
        PID=$(cat ${PID_FILE})
        log_info "PID ${PID} 프로세스 종료 중..."
        
        kill ${PID}
        
        # Graceful shutdown 대기 (최대 30초)
        for i in {1..30}; do
            if ! is_running; then
                log_info "애플리케이션이 정상적으로 종료되었습니다."
                rm -f ${PID_FILE}
                return 0
            fi
            sleep 1
        done
        
        # 강제 종료
        log_warn "Graceful shutdown 실패. 강제 종료합니다."
        kill -9 ${PID}
        rm -f ${PID_FILE}
        sleep 2
    else
        log_info "실행 중인 애플리케이션이 없습니다."
    fi
}

# Git Pull
git_pull() {
    log_info "Git Pull 시작..."
    
    cd ${APP_HOME}
    
    # 현재 브랜치 확인
    CURRENT_BRANCH=$(git branch --show-current)
    log_info "현재 브랜치: ${CURRENT_BRANCH}"
    
    # 변경사항 stash
    if [[ -n $(git status -s) ]]; then
        log_warn "로컬 변경사항이 있습니다. Stash 처리합니다."
        git stash
    fi
    
    # Pull
    log_info "${BRANCH} 브랜치에서 Pull 중..."
    git checkout ${BRANCH}
    git pull origin ${BRANCH}
    
    if [ $? -ne 0 ]; then
        log_error "Git Pull 실패!"
        exit 1
    fi
    
    log_info "Git Pull 완료"
}

# Maven 빌드
build_app() {
    log_info "Maven 빌드 시작..."
    
    cd ${APP_HOME}
    
    # Maven Wrapper가 없으면 생성
    if [ ! -f "${MAVEN_CMD}" ]; then
        log_info "Maven Wrapper가 없습니다. 생성 중..."
        mvn -N org.apache.maven.plugins:maven-wrapper-plugin:3.3.2:wrapper \
            -Dmaven=3.9.9 -DmavenDistributionType=bin
        
        if [ $? -ne 0 ]; then
            log_error "Maven Wrapper 생성 실패!"
            exit 1
        fi
        
        # 실행 권한 부여
        chmod +x mvnw
        log_info "Maven Wrapper 생성 완료"
    fi
    
    # 기존 JAR 백업
    if [ -f ${JAR_PATH} ]; then
        BACKUP_FILE="${BACKUP_DIR}/${JAR_NAME}.$(date '+%Y%m%d_%H%M%S')"
        log_info "기존 JAR 백업: ${BACKUP_FILE}"
        cp ${JAR_PATH} ${BACKUP_FILE}
        
        # 오래된 백업 파일 삭제 (30일 이상)
        find ${BACKUP_DIR} -name "*.jar" -mtime +30 -delete
    fi
    
    # Clean & Package
    log_info "Maven clean package 실행 중..."
    ${MAVEN_CMD} clean package -DskipTests
    
    if [ $? -ne 0 ]; then
        log_error "Maven 빌드 실패!"
        exit 1
    fi
    
    if [ ! -f ${JAR_PATH} ]; then
        log_error "JAR 파일이 생성되지 않았습니다: ${JAR_PATH}"
        exit 1
    fi
    
    log_info "Maven 빌드 완료: ${JAR_PATH}"
}

# 애플리케이션 시작
start_app() {
    log_info "애플리케이션 시작 중..."
    
    cd ${APP_HOME}
    
    # Java 옵션 설정
    JAVA_OPTS="-Xms512m -Xmx1024m"
    JAVA_OPTS="${JAVA_OPTS} -Dspring.profiles.active=${SPRING_PROFILE}"
    JAVA_OPTS="${JAVA_OPTS} -Dfile.encoding=UTF-8"
    
    log_info "Spring Profile: ${SPRING_PROFILE}"
    
    # 애플리케이션 시작
    nohup java ${JAVA_OPTS} -jar ${JAR_PATH} > ${LOG_DIR}/app.log 2>&1 &
    
    # PID 저장
    echo $! > ${PID_FILE}
    PID=$(cat ${PID_FILE})
    
    log_info "애플리케이션 시작됨 (PID: ${PID})"
    
    # 시작 확인 (최대 60초 대기)
    log_info "애플리케이션 시작 확인 중..."
    for i in {1..60}; do
        if is_running; then
            # Health check (포트 8080 확인)
            if netstat -tuln | grep -q ":8080 "; then
                log_info "애플리케이션이 정상적으로 시작되었습니다!"
                return 0
            fi
        else
            log_error "애플리케이션 시작 실패!"
            cat ${LOG_DIR}/app.log | tail -20
            exit 1
        fi
        sleep 1
    done
    
    log_warn "애플리케이션이 시작되었지만 Health Check에 시간이 걸리고 있습니다."
    log_info "로그를 확인하세요: ${LOG_DIR}/app.log"
}

# 상태 확인
check_status() {
    if is_running; then
        PID=$(cat ${PID_FILE})
        log_info "애플리케이션이 실행 중입니다 (PID: ${PID})"
        
        # 메모리 사용량 확인
        MEM_USAGE=$(ps -p ${PID} -o %mem,rss | tail -1)
        log_info "메모리 사용량: ${MEM_USAGE}"
        
        # 포트 확인
        if netstat -tuln | grep -q ":8080 "; then
            log_info "포트 8080: 열림"
        else
            log_warn "포트 8080: 닫힘"
        fi
    else
        log_warn "애플리케이션이 실행 중이지 않습니다."
    fi
}

###############################################################################
# 메인 배포 프로세스
###############################################################################

main() {
    log_info "=========================================="
    log_info "SHVB Task Manager 배포 시작"
    log_info "=========================================="
    
    # 1. 애플리케이션 중지
    stop_app
    
    # 2. Git Pull
    git_pull
    
    # 3. Maven 빌드
    build_app
    
    # 4. 애플리케이션 시작
    start_app
    
    # 5. 상태 확인
    check_status
    
    log_info "=========================================="
    log_info "배포 완료!"
    log_info "=========================================="
    log_info "로그 확인: tail -f ${LOG_DIR}/app.log"
}

###############################################################################
# 스크립트 실행
###############################################################################

# 명령어 파싱
case "$1" in
    start)
        start_app
        ;;
    stop)
        stop_app
        ;;
    restart)
        stop_app
        sleep 2
        start_app
        ;;
    status)
        check_status
        ;;
    deploy|"")
        main
        ;;
    *)
        echo "사용법: $0 {deploy|start|stop|restart|status}"
        echo "  deploy  : 전체 배포 프로세스 실행 (기본값)"
        echo "  start   : 애플리케이션 시작"
        echo "  stop    : 애플리케이션 중지"
        echo "  restart : 애플리케이션 재시작"
        echo "  status  : 애플리케이션 상태 확인"
        exit 1
        ;;
esac

exit 0
