#!/bin/bash

###############################################################################
# 배포 환경 설정 파일
# 서버 환경에 맞게 이 파일을 수정하세요
###############################################################################

# 애플리케이션 기본 설정
export APP_NAME="shvb-tm"
export APP_HOME="/home/app/${APP_NAME}"
export DEPLOY_BRANCH="main"

# JAR 파일 설정
export JAR_NAME="SHVBTaskManager-0.0.1-SNAPSHOT.jar"

# JVM 옵션
export JAVA_OPTS="-Xms512m -Xmx1024m"
export JAVA_OPTS="${JAVA_OPTS} -Dspring.profiles.active=prod"
export JAVA_OPTS="${JAVA_OPTS} -Dfile.encoding=UTF-8"
export JAVA_OPTS="${JAVA_OPTS} -Duser.timezone=Asia/Seoul"

# 로그 설정
export LOG_DIR="${APP_HOME}/logs"
export BACKUP_DIR="${APP_HOME}/backup"

# Health Check 설정
export HEALTH_CHECK_PORT="8080"
export HEALTH_CHECK_TIMEOUT="60"  # 초

# 백업 설정
export BACKUP_RETENTION_DAYS="30"  # 백업 파일 보관 기간

# Git 설정
export GIT_STASH_ON_DEPLOY="true"  # 배포 시 로컬 변경사항 stash 여부

echo "배포 환경 설정이 로드되었습니다."
echo "APP_HOME: ${APP_HOME}"
echo "DEPLOY_BRANCH: ${DEPLOY_BRANCH}"
echo "JAVA_OPTS: ${JAVA_OPTS}"
