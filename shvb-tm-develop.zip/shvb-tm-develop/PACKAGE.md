## java(spring) 패키지 구조

* 키워드
  * Product : 서비스명 (ex: shvb-tm)
  * ServiceDomain : 서비스 단위
    * ex) 공지사항 서비스
    * ex) 사용자 관리 서비스

```
bin
doc
src
   +- main
      +- java
         +- com.nhn.{Product}
            +- Application.java
            |
            +- common
            |  +- domain
            |  |  +- ApiRequest.java
            |  |  +- ApiResponse.java
            |  +- util
            |  |  +- StringUtil.java
            |  |  +- RestUtil.java
            |  +- message
            |  |  +- Message.java
            |
            +- {ServiceDomain}
            |  +- domain
            |  |  +- Domain.java
            |  +- controller
            |  |  +- Controller.java
            |  +- service
            |  |  +- Service.java
            |  +- repository
            |  |  +- Repository.java
            |
            +- {ServiceDomain_2}
            |
      +- resources
         +- config
         |  +- application.yml
         +- locale
         |  +- message_ko.properties
         |  +- message_en.properties
   +- test
      +- com.nhn
         +- {Product}
            +- {ServiceDomain}
            |  +- ControllerTest.java
            |  +- ServiceTest.java
            |  +- RepositoryTest.java
            |
            +- {ServiceDomain_2}
   README.md
   pom.xml
``` 