# Web Template Project
이 프로젝트는 웹 프로젝트 진행 시 Backend 의 초기 구성을 담는데 목적을 두고 있습니다.

## 주요 필요 사항
* Java : 17
* SpringBoot : 3.0.2
* Mysql

## 빌드
이 프로젝트는 maven 을 빌드 도구로 사용 합니다.

* Intellij 기준
  1. 오른쪽 사이드 탭에서 Maven 을 활성화 합니다.
  2. "Execute Maven Goal" 을 클릭 후 다음의 명령어를 입력 합니다.
     1. `mvn clean package`
     2. target 디렉토리를 초기화 한 후 빌드 결과를 생성 합니다.
     3. target 디렉토리를 다른 프로그램이 열고 있는 경우 빌드가 실패할 수 있습니다.

## 배포
이 프로젝트의 빌드 산출물은 단일 JAR 파일 입니다.
Maven 빌드 후 target 디렉토리에 생성 되는 jar 파일을 대상 서버에 배포 합니다.

* 산출물
  * {ProjectName}-0.0.1-SNAPSHOT.jar

## 실행
프로젝트의 디렉토리 중 `bin/` 디렉토리에 있는 스크립트로 프로그램을 실행 합니다.

* 실행
  * `sh bin/start.sh`
  * 실행 전 실행 대상 서버의 JAVA_HOME 설정을 확인 합니다.
  * JAVA_HOME 이 설정된 경우
    * java version 이 17 이상 인지 확인 합니다. java version이 17 미만인 경우 version 17 이상을 설치 후 start.sh 스크립트에 설치된 경로를 입력 후 실행합니다.
  * JAVA_HOME 이 설정 되지 않은 경우
    * java version 17 이상을 설치 후 실행 합니다.
* 종료
  * `sh bin/stop.sh`