package com.shvb.exception;

import com.shvb.common.domain.ApiResult;
import com.shvb.common.domain.ApiResultType;
import jakarta.validation.ConstraintViolationException;
import java.util.Objects;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@Slf4j
@RestControllerAdvice
public class ExceptionController {

    private static final ResponseEntity<ApiResult<?>> UNHANDLED_ERROR_RESPONSE = new ResponseEntity<>(ApiResult.of(
            ApiResultType.failed),
        HttpStatus.INTERNAL_SERVER_ERROR);

    @ExceptionHandler(Throwable.class)
    public ResponseEntity<ApiResult<?>> unhandledException(Throwable throwable) {
        log.error(throwable.getMessage(), throwable);

        return UNHANDLED_ERROR_RESPONSE;
    }

//    @ExceptionHandler(MethodNotSupportedException.class)
//    @ResponseStatus(HttpStatus.BAD_REQUEST)
//    public ResponseEntity<ApiResult> methodNotSupported(MethodNotSupportedException e) {
//        return getApiResultResponseEntity(e.getMessage());
//    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseEntity<ApiResult<?>> invalidRequest(MethodArgumentNotValidException e) {
        return getApiResultResponseEntity(e.getBindingResult());
    }

    @ExceptionHandler(BindException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseEntity<ApiResult<?>> invalidRequest(BindException e) {
        return getApiResultResponseEntity(e.getBindingResult());
    }

    @ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity<ApiResult<?>> validationException(ConstraintViolationException e) {
        log.debug(e.getMessage(), e);

        ApiResultType apiResultType = e.getConstraintViolations().stream()
            .map(constraintViolation -> {
                String message = constraintViolation.getMessage();
                try {
                    return ApiResultType.valueOf(message);
                } catch (IllegalArgumentException e1) {
                    return null;
                }
            })
            .filter(Objects::nonNull)
            .findFirst()
            .orElse(null);
            
        if (apiResultType != null) {
            return new ResponseEntity<>(ApiResult.of(apiResultType), HttpStatus.OK);
        } else {
            log.error(e.getMessage(), e);
            return UNHANDLED_ERROR_RESPONSE;
        }
    }

    @ExceptionHandler(InvalidArgumentException.class)
    public ResponseEntity<ApiResult<?>> invalidArgument(InvalidArgumentException e) {
        return new ResponseEntity<>(ApiResult.of(ApiResultType.invalid_argument, e.getMessage()), HttpStatus.OK);
    }

    @ExceptionHandler(AccessDeniedException.class)
    public ResponseEntity<ApiResult<?>> accessDenied(AccessDeniedException e) {
        log.warn("Access denied: {}", e.getMessage());
        return new ResponseEntity<>(ApiResult.of(ApiResultType.forbidden, "해당 기능에 대한 권한이 없습니다."), HttpStatus.OK);
    }

    private ResponseEntity<ApiResult<?>> getApiResultResponseEntity(BindingResult bindingResult) {

        return new ResponseEntity<>(ApiResult.of(ApiResultType.invalid_argument, bindingResult.getAllErrors()), HttpStatus.BAD_REQUEST);
    }

    private ResponseEntity<ApiResult<?>> getApiResultResponseEntity(String message) {

        return new ResponseEntity<>(ApiResult.of(ApiResultType.bad_request, message), HttpStatus.BAD_REQUEST);
    }
}
