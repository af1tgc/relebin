package com.shvb.sampledomain.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import java.time.LocalDateTime;
import java.util.stream.Collectors;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@JsonInclude
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class NoticeDTO {

    private Long id;
    private String title;
    private String content;
    private String writer;
    private Integer viewCnt;
    private String noticeYn;
    private LocalDateTime writeDate;
    private LocalDateTime updateDate;

    private String userName;
    private String userEmail;
    private String filePath;

    public NoticeDTO(NoticeEntity n) {
        this.id = n.getId();
        this.title = n.getTitle();
        this.content = n.getContent();
        this.writer = n.getWriter();
        this.viewCnt = n.getViewCnt();
        this.noticeYn = n.getNoticeYn();
        this.writeDate = n.getWriteDate();
        this.updateDate = n.getUpdateDate();
        this.userName = n.getWriterInfo().getUserName();
        this.userEmail = n.getWriterInfo().getUserEmail();
        if (n.getFileList() != null) {
            this.filePath = n.getFileList().stream()
                    .map(NoticeFileEntity::getFilePath)
                    .collect(Collectors.joining(","));
        }
    }
}
