package com.shvb.sampledomain.service;

import com.shvb.common.domain.ApiRequest;
import com.shvb.common.search.SearchSpecification;
import com.shvb.sampledomain.domain.NoticeDTO;
import com.shvb.sampledomain.domain.NoticeEntity;
import com.shvb.sampledomain.repository.NoticeRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

/*
참조.
  1. 비즈니스 기능/도메인/사용 사례 중심으로 구성
  2. 예) DatabaseService, ValidationService : bad
        AccountService, UserService : good
 */
@Slf4j
@Service
public class NoticeService {
    @Autowired
    private NoticeRepository repo;

    public NoticeDTO getNotice(Long id) {

        var r = repo.findById(id);
        return r.map(NoticeDTO::new).orElseGet(NoticeDTO::new);
    }

    // Entity 내 Join 필드가 존재하고, Fetch 타입이 Lazy 인 경우 트랜젝션으로 묶어야 한다.
    // 묶지 않는 경우 영속성 검증 오류 발생
//    @Transactional
    public Page<NoticeDTO> getNoticeList(ApiRequest req) {
        // todo ApiRequest field null check
        var s = req.getSort();
        var p = PageRequest.of(req.getPageNumber(), req.getPageSize(), s);

        var r = repo.findAll(new SearchSpecification<>(req.getFilter()), p);

        log.debug("page total pages: {}", r.getTotalPages());
        log.debug("page total count: {}", r.getTotalElements());


        var r2 = r.map(NoticeDTO::new);

        return r2;
    }

    public boolean createNotice(NoticeEntity entity) {
        var ret = repo.save(entity);

        if (ret.getId() != null) {

            log.debug("notice 생성 ID: {}", entity.getId());
            return true;

        } else {

            log.debug("notice 생성 실패: {}", entity);
            return false;

        }
    }

    public boolean updateNotice(NoticeEntity entity) {

        if (repo.existsById(entity.getId())) {

            var ret = repo.save(entity);

            log.debug("notice 수정 ID: {}", entity.getId());
            return true;

        } else {

            log.debug("notice 없는 ID: {}", entity.getId());
            return false;
        }
    }

    public boolean deleteNotice(Long id) {

        if (repo.existsById(id)) {

            repo.deleteById(id);
            log.debug("notice 삭제 ID: {}", id);
            return true;

        } else {

            log.debug("notice 없는 ID: {}", id);
            return false;

        }
    }
}
