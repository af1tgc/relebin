package com.shvb.sampledomain.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.shvb.common.util.DateTimeUtil;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.time.LocalDateTime;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;

@Getter
@Setter
@Entity
@Table(name = "notice")
public class NoticeEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    // @Column Annotation 은 Validation 을 체크 하지 않는다.
    @Size(max = 100)                                        // Validation 체크 대상 O
    @NotNull                                                // Validation 체크 대상 O
    @Column(name = "title", length = 100, nullable = false) // Validation 체크 대상 X
    private String title;

    @NotNull
    @Column(name = "content", columnDefinition = "TEXT")
    private String content;

    @NotNull
    @Column(name = "writer", length = 100)
    private String writer;

    @Column(name = "view_cnt")
    int viewCnt;

    @Size(max = 1)
    @Column(name = "notice_yn", length = 1)
    private String noticeYn;

    @CreationTimestamp
    @JsonFormat(shape = Shape.STRING, pattern = DateTimeUtil.P_1)
    @Column(name = "write_date", columnDefinition = "TIMESTAMP")
    private LocalDateTime writeDate;

    @JsonFormat(shape = Shape.STRING, pattern = DateTimeUtil.P_2)
    @Column(name = "update_date", columnDefinition = "TIMESTAMP")
    private LocalDateTime updateDate;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "writer", insertable = false, updatable = false)
    @JsonManagedReference
    private ComUser writerInfo;

    @OneToMany(fetch = FetchType.EAGER)
    @JoinColumn(name = "notice_id", insertable = false, updatable = false)
    @JsonManagedReference
    private List<NoticeFileEntity> fileList;
}
