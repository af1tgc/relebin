package com.shvb.sampledomain.controller;

import com.shvb.common.domain.ApiRequest;
import com.shvb.common.domain.ApiResult;
import com.shvb.common.domain.ApiResultType;
import com.shvb.sampledomain.domain.NoticeEntity;
import com.shvb.sampledomain.service.NoticeService;
import jakarta.validation.Valid;
import java.util.Locale;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/*
URL 패턴
  1. 클래스에 서비스 도메인을 대표하는 URL을 명시
  2. 각 메소드에 세부 CRUD 요청을 처리하는 URL을 명시
참조.
  1. 상태 비저장
  2. 비즈니스 로직 실행 X. 비즈니스 로직 실행을 @Service 에 위임
  3. HTTP 계층을 처리하며, 이는 서비스에 전달하지 않음
  4. 사용 사례/비즈니스 기능 중심으로 설계
 */
@Slf4j
@RestController
@RequestMapping("/notice")
public class NoticeController {

    @Autowired
    private MessageSource messageSource;
    @Autowired
    private NoticeService serv;

    @GetMapping("/{id}")
    public ResponseEntity<ApiResult<?>> getNotice(@PathVariable("id") Long id) {

        log.debug("Request ID : {}", id);

        var ret = ApiResult.success(serv.getNotice(id));

        return ResponseEntity.ok(ret);
    }

    @GetMapping("/v2/{id}")     //sample
    public ResponseEntity<ApiResult<?>> getNotice2(@PathVariable("id") Long id) {

        log.debug("Request ID : {}", id);

        var ret = ApiResult.success(serv.getNotice(id));

        return ResponseEntity.ok(ret);
    }

    @GetMapping("/list")
    public ResponseEntity<ApiResult<?>> getNoticeList(@ModelAttribute @Validated ApiRequest apiRequest) {

        log.info("request url {}", "v2/list");
        log.info(apiRequest.toString());

        var temp1 = serv.getNoticeList(apiRequest);
        log.info(temp1.toString());
        var ret = ApiResult.success(temp1);
        log.info(ret.toString());

        // todo 페이징 요청 추가
        // todo 필터 기능 추가

        return ResponseEntity.ok(ret);
    }

    @PutMapping
    public ResponseEntity<ApiResult<String>> updateNotice(
            @RequestBody @Validated NoticeEntity entity) {

        String retMsg;

        boolean ret = serv.updateNotice(entity);
        ApiResult<String> res;

        if (ret) {
            retMsg = "정상 처리";
            res = ApiResult.success(retMsg);
        } else {
            retMsg = messageSource.getMessage("common.validate.exists", null, Locale.getDefault());
            res = ApiResult.of(ApiResultType.no_content, retMsg);
        }

        return ResponseEntity.ok(res);

    }

    @PostMapping
    public ResponseEntity<ApiResult<String>> createNotice(
            @RequestBody @Valid NoticeEntity entity) {

        boolean ret = serv.createNotice(entity);

        return ResponseEntity.ok(ApiResult.success(""+ret));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResult<?>> deleteNotice(
            @PathVariable("id") Long id) {

        boolean ret = serv.deleteNotice(id);

        if (ret) {
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.ok(ApiResult.of(ApiResultType.no_content));
        }

    }
}
