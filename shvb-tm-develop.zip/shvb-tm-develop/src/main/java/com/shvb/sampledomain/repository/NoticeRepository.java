package com.shvb.sampledomain.repository;

import com.shvb.sampledomain.domain.NoticeDTO;
import com.shvb.sampledomain.domain.NoticeEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface NoticeRepository extends JpaRepository<NoticeEntity, Long>,
        JpaSpecificationExecutor<NoticeEntity> {

    // sample
    @Query(
            value = "select n, cu.userName, cu.userEmail, nfe.filePath "
                    + "from NoticeEntity n "
                    + "left join ComUser cu on n.writer = cu.userId "
                    + "left join NoticeFileEntity nfe on n.id = nfe.noticeId "
                    + "where n.id = :#{#p.id} "
                    + "and n.title like :#{#p.title}"
            , nativeQuery = false)
    Page<NoticeDTO> findAllByDtoFilter(@Param("p") NoticeDTO param, Pageable pageable);

}
