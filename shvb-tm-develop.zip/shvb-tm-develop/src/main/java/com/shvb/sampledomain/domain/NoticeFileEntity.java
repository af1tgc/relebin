package com.shvb.sampledomain.domain;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "notice_file")
public class NoticeFileEntity implements Serializable {

    @Id
    @Column(name = "notice_id")
    private Long noticeId;

    @Id
    @Column(name = "file_path")
    private String filePath;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "notice_id", referencedColumnName = "id")
    @JsonBackReference
    private NoticeEntity notice;
}
