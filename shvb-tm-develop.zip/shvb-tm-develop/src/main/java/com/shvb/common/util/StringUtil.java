package com.shvb.common.util;

/***
 * 목적 : 보통 apache common.io 패키지를 이용하여 문자열 처리에 필요한 함수를 사용
 * common.io 패키지에 필수적으로 의존하지 하지 않기
 */

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

public class StringUtil {

    public static boolean isEmptyOrNull(String str) {

        if (str == null || str.isEmpty()) {
            return true;
        } else {
            return false;
        }
    }

    public static String removeSpace(String str) {

        if (!isEmptyOrNull(str)) {
            return str.replaceAll("\\s", "");
        } else {
            return str;
        }
    }

    public static Set<String> splitToSet(String listStr, String regex) {

        if (!StringUtil.isEmptyOrNull(listStr)) {
            return Arrays.stream(StringUtil.removeSpace(listStr).split(regex)).collect(Collectors.toSet());
        } else {
            return new HashSet<>();
        }
    }

}
