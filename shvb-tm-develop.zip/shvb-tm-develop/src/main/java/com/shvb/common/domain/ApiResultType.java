package com.shvb.common.domain;

public enum ApiResultType {
    success(0, "success"),
    no_content(204, "no_content"),
    bad_request(400, "bad_request"),
    invalid_authentication(401, "invalid_authentication"),
    forbidden(403, "forbidden"),
    not_found(404, "not_found"),
    invalid_argument(410, "invalid_argument"),
    invalid_request(412, ApiResultType.INVALID_REQUEST_MESSAGE),
    already_rewarded(413, "already_rewarded"),
    not_satisfy_condition(414, "not_satisfy_condition"),
    not_enough_mineral(415, "not_enough_mineral"),
    exceed_maximum_point(416, "exceed_maximum_point"),
    already_applied(417, "already_applied"),
    expired_event(418, "expired_event"),
    not_enough_minimum(418, "not_enough_minimum"),
    not_finished_event(419, "not_finished_event"),
    already_announced(420, "already_announced"),
    exceed_maximum_apply(416, "exceed_maximum_apply"),
    not_apply_time(417, "not_apply_time"),

    failed(500, ApiResultType.FAILED_MESSAGE);


    public static final String INVALID_REQUEST_MESSAGE = "invalid_request";
    public static final String FAILED_MESSAGE = "failed";

    private int code;
    private String message;

    ApiResultType(int code, String message) {
        this.code = code;
        this.message = message;
    }

    public static ApiResultType getTypeByCode(int code) {
        for (ApiResultType e : values()) {
            if (e.getCode() == code) {
                return e;
            }
        }
        return failed;
    }

    public int getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }
}
