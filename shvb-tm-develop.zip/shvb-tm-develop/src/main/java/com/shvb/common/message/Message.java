package com.shvb.common.message;

import org.springframework.context.support.ReloadableResourceBundleMessageSource;

/*
 * 필요 시 Bean 으로 선언 하여 사용.
 */
//@Configuration
public class Message {

//    @Bean
    public ReloadableResourceBundleMessageSource messageSource() {
        ReloadableResourceBundleMessageSource source = new ReloadableResourceBundleMessageSource();

        source.setBasename("classpath:/locale/messages");

        source.setDefaultEncoding("UTF-8");

        source.setCacheSeconds(60);
        //	없는 메세지일 경우 예외를 발생시키는 대신 코드를 기본 메세지로 함.
        source.setUseCodeAsDefaultMessage(true);

        return source;
    }
}
