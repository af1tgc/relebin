package com.shvb.common.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.shvb.common.util.StringUtil;
import jakarta.validation.constraints.NotNull;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;

@Getter
@Setter
@ToString
@JsonInclude
public class ApiRequest {

    @NotNull
    private int pageSize;

    @NotNull
    private int pageNumber;

    private List<String> filter;

    private String orderBy;

    private String direction = "asc";

    public Sort getSort() {
        if (StringUtil.isEmptyOrNull(orderBy)) {
            return Sort.unsorted();
        } else {
            return Sort.by(Direction.fromString(direction), orderBy);
        }
    }
}
