package com.shvb.common.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import org.springframework.data.domain.Page;

import java.util.List;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PageResult<T> {
    private List<T> content;
    private PageInfo pageInfo;

    public PageResult(List<T> content, PageInfo pageInfo) {
        this.content = content;
        this.pageInfo = pageInfo;
    }

    public static <T> PageResult<T> of(Page<T> page) {
        return new PageResult<>(
            page.getContent(),
            new PageInfo(
                page.getNumber(),
                page.getSize(),
                page.getTotalElements(),
                page.getTotalPages(),
                page.isFirst(),
                page.isLast()
            )
        );
    }

    @Data
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class PageInfo {
        private int currentPage;      // 현재 페이지 번호 (0부터 시작)
        private int size;             // 페이지 크기
        private long totalElements;   // 전체 요소 수
        private int totalPages;       // 전체 페이지 수
        private boolean first;        // 첫 페이지 여부
        private boolean last;         // 마지막 페이지 여부

        public PageInfo(int currentPage, int size, long totalElements, int totalPages, boolean first, boolean last) {
            this.currentPage = currentPage;
            this.size = size;
            this.totalElements = totalElements;
            this.totalPages = totalPages;
            this.first = first;
            this.last = last;
        }
    }
}
