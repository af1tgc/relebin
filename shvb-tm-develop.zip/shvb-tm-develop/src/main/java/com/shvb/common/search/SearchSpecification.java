package com.shvb.common.search;

import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Path;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.jpa.domain.Specification;

@Slf4j
@AllArgsConstructor
public class SearchSpecification<T> implements Specification<T> {

    private List<String> filters;

    @Override
    public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
        List<Predicate> list = new ArrayList<>();

        if (filters != null) {
            for (String f : filters) {
                // filterColumn operator filterValue
                // ex) id eq 1 --> where id = 1
                var fl = Arrays.stream(f.split(" ", 3))
                        .map(String::trim)
                        .toList();

                var filterColumn = fl.get(0);
                var filterOperator = fl.get(1);
                var filterValue = fl.get(2);

                // filterColumn이 조인 테이블 내 컬럼 대상인지 체크
                // . 기준 앞은 Entity 내 조인테이블 변수 명, 뒤는 조인테이블 내 변수 명
                if (filterColumn.contains(".")) {
                    var temp = filterColumn.split("\\.", 2);
                    filterColumn = temp[1];

                    var j = root.join(temp[0]);
                    var p = j.get(filterColumn);
                    list.add(getFilterPredicate(cb, p, filterOperator, filterValue));

                } else {

                    var p = root.get(filterColumn);
                    list.add(getFilterPredicate(cb, p, filterOperator, filterValue ));

                }
            }
        }

        return cb.and(list.toArray(new Predicate[0]));
    }

    private Predicate getFilterPredicate(CriteriaBuilder cb, Path p, String op, String value) {
        if ("eq".equals(op)) {

            return cb.equal(p, value);

        } else if ("neq".equals(op)) {

            return cb.notEqual(p, value);

        } else if ("like".equals(op)) {

            return cb.like(p, "%" + value.toUpperCase() + "%");

        } else {

            return cb.like(p, "%" + value.toUpperCase() + "%");

        }
    }
}
