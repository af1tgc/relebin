package com.shvb.common.util;

/***
 * 목적 : 개발자 별로 문자열로 이뤄진 Date, DateTime 값을 파싱할 때
 * java.text.SimpleDateFormat 과 java.time.format.DateTimeFormatter 패키지를 섞어 사용.
 * java.time.format.DateTimeFormatter 로 통일 위함.
 */
public class DateTimeUtil {

    public static final String P_1 = "yyyy-MM-dd HH:mm:ss";
    public static final String P_2 = "yyyyMMdd HHmmss";

}
