package com.shvb.common.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import org.springframework.data.domain.Page;

@Data
public class ApiResult<T> {

    private final int code;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private final String message;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private final T result;

    private ApiResult(ApiResultType apiResultType, String message, T result) {
        this.code = apiResultType.getCode();
        this.message = message;
        this.result = result;
    }

    public static ApiResult<?> of(ApiResultType status) {
        return new ApiResult<>(status, status.getMessage(), null);
    }

    public static <T> ApiResult<T> of(ApiResultType status, T result) {
        return new ApiResult<>(status, status.getMessage(), result);
    }

    public static <T> ApiResult<T> success(T result) {
        return of(ApiResultType.success, result);
    }

    public static <T> ApiResult<PageResult<T>> successPage(Page<T> page) {
        return success(PageResult.of(page));
    }
}
