package com.shvb.common.util;

import com.shvb.exception.InvalidArgumentException;

/**
 * 공통 검증 유틸리티 클래스
 */
public class ValidationUtil {

    /**
     * 문자열이 비어있지 않은지 확인
     */
    public static boolean isNotBlank(String str) {
        return str != null && !str.trim().isEmpty();
    }

    /**
     * 문자열이 비어있는지 확인
     */
    public static boolean isBlank(String str) {
        return str == null || str.trim().isEmpty();
    }

    /**
     * 필수 문자열 검증
     */
    public static void requireNotBlank(String str, String fieldName) {
        if (isBlank(str)) {
            throw new InvalidArgumentException(fieldName + "은(는) 필수 조건입니다.");
        }
    }

    /**
     * 필수 객체 검증
     */
    public static void requireNonNull(Object obj, String fieldName) {
        if (obj == null) {
            throw new InvalidArgumentException(fieldName + "은(는) 필수 조건입니다.");
        }
    }

    /**
     * 최소 하나 이상의 조건이 존재하는지 확인
     */
    public static void requireAtLeastOneCondition(boolean hasCondition, String message) {
        if (!hasCondition) {
            throw new InvalidArgumentException(message);
        }
    }
}
