package com.shvb.config;

import com.shvb.tm.security.JwtAuthenticationFilter;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.List;

@Configuration
@RequiredArgsConstructor
public class SecurityConfig {

    private final JwtAuthenticationFilter jwtAuthenticationFilter;

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration cfg = new CorsConfiguration();
        // 허용할 Origin 목록
        cfg.setAllowedOrigins(List.of(
            "http://localhost:5173",           // 로컬 개발
            "http://167.172.205.76:3000"       // 배포된 프론트엔드
        ));
        cfg.setAllowedMethods(List.of("GET","POST","PUT","PATCH","DELETE","OPTIONS"));
        cfg.setAllowedHeaders(List.of("*"));
        cfg.setAllowCredentials(true);
        cfg.setExposedHeaders(List.of("Authorization","Location","Link","X-Total-Count"));
        cfg.setMaxAge(3600L);

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        // 전역 매핑
        source.registerCorsConfiguration("/**", cfg);
        return source;
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .cors(Customizer.withDefaults())
                .csrf(csrf -> csrf.disable())
                .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .authorizeHttpRequests(auth -> auth
                        // OPTIONS 요청 허용 (CORS preflight)
                        .requestMatchers(HttpMethod.OPTIONS, "/**").permitAll()
                        
                        // 인증 없이 접근 가능
                        .requestMatchers("/auth/**").permitAll()
                        
                        // [대시보드] 진행/예정 업무 - USER 이상 (자기 자신의 업무만)
                        .requestMatchers(HttpMethod.GET, "/api/task").hasAnyRole("USER", "MANAGER", "BOD", "ADMIN")
                        .requestMatchers(HttpMethod.GET, "/api/task/detail").hasAnyRole("USER", "MANAGER", "BOD", "ADMIN")
                        .requestMatchers(HttpMethod.GET, "/api/task/type").hasAnyRole("USER", "MANAGER", "BOD", "ADMIN")
                        .requestMatchers(HttpMethod.GET, "/api/employee").hasAnyRole("USER", "MANAGER", "BOD", "ADMIN")
                        .requestMatchers(HttpMethod.GET, "/api/employee/**").hasAnyRole("USER", "MANAGER", "BOD", "ADMIN")
                        .requestMatchers(HttpMethod.GET, "/api/department").hasAnyRole("USER", "MANAGER", "BOD", "ADMIN")
                        .requestMatchers(HttpMethod.GET, "/api/department/**").hasAnyRole("USER", "MANAGER", "BOD", "ADMIN")
                        .requestMatchers(HttpMethod.POST, "/api/task-details").hasAnyRole("USER", "MANAGER", "BOD", "ADMIN")
                        .requestMatchers(HttpMethod.POST, "/api/task-details/**").hasAnyRole("USER", "MANAGER", "BOD", "ADMIN")
                        
                        // [업무등록] 업무 등록 및 수정 - MANAGER 이상
                        .requestMatchers(HttpMethod.POST, "/admin/task").hasAnyRole("MANAGER", "BOD", "ADMIN")
                        .requestMatchers(HttpMethod.POST, "/admin/task/**").hasAnyRole("MANAGER", "BOD", "ADMIN")
                        .requestMatchers(HttpMethod.GET, "/admin/task/list").hasAnyRole("MANAGER", "BOD", "ADMIN")
                        
                        // [업무유형관리] - MANAGER 이상
                        .requestMatchers("/admin/task/type/**").hasAnyRole("MANAGER", "BOD", "ADMIN")
                        
                        // [업무현황 대시보드] - MANAGER 이상
                        .requestMatchers(HttpMethod.GET, "/admin/task/search").hasAnyRole("MANAGER", "BOD", "ADMIN")
                        .requestMatchers(HttpMethod.GET, "/admin/task/unwritten-users/**").hasAnyRole("MANAGER", "BOD", "ADMIN")
                        .requestMatchers(HttpMethod.GET, "/admin/task/completion-stats/**").hasAnyRole("MANAGER", "BOD", "ADMIN")
                        
                        // 기타 admin API - MANAGER 이상
                        .requestMatchers("/admin/**").hasAnyRole("MANAGER", "BOD", "ADMIN")
                        
                        // 그 외 모든 요청은 인증 필요
                        .anyRequest().authenticated()
                )
                .addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class);
        
        return http.build();
    }
}
