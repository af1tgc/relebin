package com.shvb.tm.domain.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Entity
@Table(name = "department")
public class DepartmentEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @EqualsAndHashCode.Include
    @Column(name = "department_id")
    private Long departmentId;

    @Column(name = "department_name", length = 100, nullable = false)
    private String departmentName;

    @Column(name = "parent_department_id")
    private Long parentDepartmentId;

    @Column(name = "ctime", insertable = false, updatable = false)
    private LocalDateTime ctime;

    @Column(name = "utime", insertable = false, updatable = false)
    private LocalDateTime utime;
}
