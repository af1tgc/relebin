package com.shvb.tm.domain.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Entity
@Table(
        name = "task",
        indexes = {
                @Index(name = "idx_task_status_due", columnList = "status,due_date"),
                @Index(name = "idx_task_type", columnList = "task_type_id"),
                @Index(name = "idx_task_title", columnList = "title")
        }
)
public class TaskEntity {

    public enum TaskStatus {
        PLANNED, ACTIVE, ON_HOLD, DELAYED, DONE
    }

    public enum TaskFrequency {
        NONE, DAILY, WEEKLY, MONTHLY, QUARTERLY, SEMIANNUAL, ANNUAL
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @EqualsAndHashCode.Include
    @Column(name = "task_id")
    private Long taskId;

    @Column(name = "task_type_id")
    private Long taskTypeId;

    @Column(name = "title", length = 200, nullable = false)
    private String title;

    // MySQL ENUM ↔ Java Enum 매핑은 STRING 방식 권장
    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false)
    private TaskStatus status;

    @Column(name = "start_date")
    private LocalDate startDate;

    @Column(name = "due_date")
    private LocalDate dueDate;

    @Enumerated(EnumType.STRING)
    @Column(name = "frequency", nullable = false)
    private TaskFrequency frequency;

    // iCalendar Recurrence Rule (예: FREQ=MONTHLY;BYMONTHDAY=1)
    @Column(name = "rrule", length = 255)
    private String rrule;

    @Column(name = "is_active", nullable = false)
    private Boolean isActive;

    @Column(name = "is_deleted", nullable = false)
    private Boolean isDeleted;

    @Column(name = "ctime", insertable = false, updatable = false)
    private LocalDateTime ctime;

    @Column(name = "utime", insertable = false, updatable = false)
    private LocalDateTime utime;
}