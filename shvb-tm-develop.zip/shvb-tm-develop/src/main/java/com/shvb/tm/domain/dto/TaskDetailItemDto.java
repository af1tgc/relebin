package com.shvb.tm.domain.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.shvb.tm.domain.entity.TaskEntity.TaskStatus;
import lombok.*;

import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaskDetailItemDto {
    private Long taskDetailId;
    private Long taskId;
    private String taskTitle;
    private TaskStatus taskStatus;
    private LocalDate dueDate;
    private String taskTypeName;
    private String taskCategoryName;
    private String departmentName;
    private Long employeeId;
    private String employeeName;
    private LocalDate workDate;
    private Integer durationMinutes;
    private Boolean isLate;
}