package com.shvb.tm.util;

import com.shvb.common.util.ValidationUtil;
import com.shvb.exception.InvalidArgumentException;
import com.shvb.tm.domain.dto.TaskSearchRequestDto;

/**
 * Task 검색 조건 검증 유틸리티
 */
public class TaskSearchValidator {

    /**
     * Task 검색 조건 검증 - 날짜는 필수, 추가로 최소 하나 이상의 검색 조건 필요
     */
    public static void validateSearchConditions(TaskSearchRequestDto searchDto) {
        if (searchDto == null) {
            throw new InvalidArgumentException("검색 조건이 필요합니다.");
        }
        
        // 날짜는 필수 조건
        ValidationUtil.requireNonNull(searchDto.getWorkDate(), "작업일자");
        
        // 날짜 외에 최소 하나 이상의 검색 조건 필요
        boolean hasAdditionalCondition = 
            ValidationUtil.isNotBlank(searchDto.getTaskTypeName()) ||
            ValidationUtil.isNotBlank(searchDto.getTaskCategory()) ||
            ValidationUtil.isNotBlank(searchDto.getTaskName()) ||
            ValidationUtil.isNotBlank(searchDto.getTaskStatus()) ||
            ValidationUtil.isNotBlank(searchDto.getDepartmentName()) ||
            ValidationUtil.isNotBlank(searchDto.getEmployeeName());
            
        ValidationUtil.requireAtLeastOneCondition(
            hasAdditionalCondition, 
            "작업일자 외에 최소 하나 이상의 검색 조건을 입력해주세요."
        );
    }
}
