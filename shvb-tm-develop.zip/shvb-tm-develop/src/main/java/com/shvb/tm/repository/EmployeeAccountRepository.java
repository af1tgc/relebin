package com.shvb.tm.repository;

import com.shvb.tm.domain.entity.EmployeeAccountEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface EmployeeAccountRepository extends JpaRepository<EmployeeAccountEntity, Long> {
    
    Optional<EmployeeAccountEntity> findByUsername(String username);
    
    Optional<EmployeeAccountEntity> findByEmployeeId(Long employeeId);
    
    boolean existsByUsername(String username);
}
