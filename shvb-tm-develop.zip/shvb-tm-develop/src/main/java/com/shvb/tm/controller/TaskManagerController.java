package com.shvb.tm.controller;

import com.shvb.common.domain.ApiResult;
import com.shvb.exception.InvalidArgumentException;
import com.shvb.tm.domain.dto.TaskDetailRequestDto;
import com.shvb.tm.service.AdminService;
import com.shvb.tm.service.TaskManagerService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@RequestMapping("/api")
public class TaskManagerController {
    @Autowired
    TaskManagerService taskManagerService;
    
    @Autowired
    AdminService adminService;

    @GetMapping("/test")
    public ResponseEntity<ApiResult<?>> getTest() {
        return ResponseEntity.ok(ApiResult.success("OKAY"));
    }

    @GetMapping("/task")
    public ResponseEntity<ApiResult<?>> getTask(
            @RequestParam("q") String query
    ) {
        return ResponseEntity.ok(
                ApiResult.success(
                        taskManagerService.getTaskList(query)
                ));
    }

    @GetMapping("/task/type")
    public ResponseEntity<ApiResult<?>> getTaskCategory(
            @RequestParam("q") String query
    ) {
        return ResponseEntity.ok(
                ApiResult.success(
                    taskManagerService.getTaskTypeList(query)
        ));
    }

    @GetMapping("/task/detail")
    public ResponseEntity<ApiResult<?>> getTaskDetail(
            @RequestParam("from") String fromDate,
            @RequestParam("to") String toDate,
            @RequestParam("employeeId") Long employeeId,
            @RequestParam("isDeleted") Boolean isDeleted,
            @org.springframework.security.core.annotation.AuthenticationPrincipal Long authenticatedEmployeeId
    ) {
        // 본인의 업무만 조회 가능 (JWT의 employeeId와 요청 파라미터의 employeeId가 일치해야 함)
        if (!authenticatedEmployeeId.equals(employeeId)) {
            log.warn("Access denied: authenticated employeeId {} tried to access employeeId {}", 
                     authenticatedEmployeeId, employeeId);
            throw new AccessDeniedException("본인의 업무만 조회할 수 있습니다.");
        }
        
        return ResponseEntity.ok(
            ApiResult.success(
                taskManagerService.getTaskDetailList(fromDate, toDate, employeeId, isDeleted)
            )
        );
    }

    @GetMapping("/employee")
    public ResponseEntity<ApiResult<?>> getEmployee(
            @RequestParam("q") String query
    ) {
        return ResponseEntity.ok(
                ApiResult.success(
                        taskManagerService.getEmployeeList(query)
                ));
    }

    @PostMapping("/task-details")
    public ResponseEntity<ApiResult<?>> createTaskDetail(@RequestBody TaskDetailRequestDto taskDetailRequestDto) {
        taskManagerService.createTaskDetail(taskDetailRequestDto);
        return ResponseEntity.status(org.springframework.http.HttpStatus.CREATED)
                .body(ApiResult.success("Task detail created successfully"));
    }
    @PostMapping("/task-details/{taskDetailId}")
    public ResponseEntity<ApiResult<?>> updateTaskDetail(@PathVariable Long taskDetailId, @RequestBody TaskDetailRequestDto taskDetailRequestDto) {
        taskManagerService.updateTaskDetail(taskDetailId, taskDetailRequestDto);
        return ResponseEntity.ok(ApiResult.success("Task detail updated successfully"));
    }

    @GetMapping("/department")
    public ResponseEntity<ApiResult<?>> getDepartments() {
        return ResponseEntity.ok(ApiResult.success(
                adminService.getDepartments()
        ));
    }

    @Deprecated
    @GetMapping("/department/{departmentId}/tree")
    public ResponseEntity<ApiResult<?>> getDepartmentTree(@PathVariable Long departmentId) {
        return ResponseEntity.ok(ApiResult.success(
                adminService.getDepartmentIdsWithChildren(departmentId)
        ));
    }

    @GetMapping("/employee/{employeeId}/manager")
    public ResponseEntity<ApiResult<?>> getEmployeeManager(@PathVariable Long employeeId) {
        return ResponseEntity.ok(ApiResult.success(
                adminService.getEmployeeWithManager(employeeId)
        ));
    }

    @GetMapping("/department/{departmentId}/employees")
    public ResponseEntity<ApiResult<?>> getEmployeesByDepartment(@PathVariable Long departmentId) {
        return ResponseEntity.ok(ApiResult.success(
                adminService.getEmployeesByDepartment(departmentId)
        ));
    }
}
