package com.shvb.tm.repository;

import com.shvb.tm.domain.entity.DepartmentEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface DepartmentRepository extends JpaRepository<DepartmentEntity, Long> {
    
    // 특정 부서의 하위 부서들 조회
    List<DepartmentEntity> findByParentDepartmentId(Long parentDepartmentId);
}
