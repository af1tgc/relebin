package com.shvb.tm.repository;

import com.shvb.tm.domain.dto.TaskDetailDto;
import com.shvb.tm.domain.entity.TaskDetailEntity;
import com.shvb.tm.domain.entity.TaskDetailJoinEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;

public interface TaskDetailRepository extends JpaRepository<TaskDetailEntity, Long> {

    @Query("""
        SELECT new com.shvb.tm.domain.dto.TaskDetailDto(
            td
        )
        FROM TaskDetailJoinEntity td
        WHERE 1=1
          AND td.workDate >= :fromDate
          AND td.workDate <= :toDate
          AND td.employee.employeeId = :employeeId
          AND td.isDeleted = :isDeleted
        """)
    List<TaskDetailDto> findTaskDetailWithJoin(
            @Param("fromDate") LocalDate fromDate,
            @Param("toDate") LocalDate toDate,
            @Param("employeeId") Long employeeId,
            @Param("isDeleted") Boolean isDeleted
    );

    /*
    @Query("""
        select new com.nhn.shvb.tm.domain.dto.TaskDetailItemDto(
          td.taskDetailId,
          t.taskId,
          t.title,
          t.status,
          t.dueDate,
          tt.taskTypeName,
          c.categoryName,
          e.employeeId,
          e.employeeName,
          td.workDate,
          td.durationMinutes,
          td.isLate
        )
        from TaskDetailEntity td
          join td.task t
          join t.taskType tt
          left join tt.taskCategory c
          join td.employee e
        where td.isDeleted = false
          and t.isDeleted  = false
          and (:from is null or td.workDate >= :from)
          and (:to   is null or td.workDate <= :to)
          and (:employeeId is null or e.employeeId = :employeeId)
        order by td.workDate desc
        """)
    List<TaskDetailItemDto> findList(@Param("from") LocalDate from,
                                     @Param("to") LocalDate to,
                                     @Param("employeeId") Long employeeId);

    @Query("""
        select new dto.domain.tm.com.shvb.TaskDetailDto(
          td.taskDetailId,
          t.taskId,
          t.title,
          t.status,
          t.startDate,
          t.dueDate,
          t.frequency,
          t.rrule,
          tt.taskTypeId,
          tt.taskTypeName,
          tt.taskCategoryId,
          c.categoryName,
          e.employeeId,
          e.employeeName,
          td.workDate,
          td.durationMinutes,
          td.content,
          td.linkUrl,
          td.remark,
          td.isLate,
          td.ctime,
          td.utime
        )
        from TaskDetailEntity td
          join td.task t
          join t.taskType tt
          left join tt.taskCategory c
          join td.employee e
        where td.taskDetailId = :id
        """)
    TaskDetailDto findDetail(@Param("id") Long id);

     */
}