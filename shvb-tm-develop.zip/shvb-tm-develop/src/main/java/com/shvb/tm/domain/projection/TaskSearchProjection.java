package com.shvb.tm.domain.projection;

import java.time.LocalDate;

public interface TaskSearchProjection {
    // Task 정보
    Long getTaskId();
    String getTaskTitle();
    String getTaskStatus();
    LocalDate getTaskStartDate();
    LocalDate getTaskDueDate();
    
    // TaskType 정보
    Long getTaskTypeId();
    String getTaskTypeName();
    
    // TaskCategory 정보
    Long getTaskCategoryId();
    String getTaskCategoryName();
    
    // TaskType Department 정보
    Long getDepartmentId();
    String getDepartmentName();
    
    // TaskDetail 정보
    Long getTaskDetailId();
    LocalDate getWorkDate();
    String getWorkContent();
    Integer getWorkHours();
    
    // TaskDetail 작업자 정보
    Long getWorkerEmployeeId();
    String getWorkerEmployeeName();
    Long getWorkerDepartmentId();
    String getWorkerDepartmentName();
}
