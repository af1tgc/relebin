package com.shvb.tm.domain.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
@Entity
@Table(name = "task")
public class TaskJoinEntity {
    @Id
    @Column(name = "task_id")
    private Long taskId;

    // TaskEntity 필드
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "task_type_id", referencedColumnName = "task_type_id")
    private TaskTypeJoinEntity taskType;

    @Column(name = "task_type_id", insertable = false, updatable = false)
    private Long taskTypeId;

    @Column(name = "title", length = 200, nullable = false)
    private String title;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false)
    private TaskEntity.TaskStatus status;

    @Column(name = "start_date")
    private LocalDate startDate;

    @Column(name = "due_date")
    private LocalDate dueDate;

    @Enumerated(EnumType.STRING)
    @Column(name = "frequency", nullable = false)
    private TaskEntity.TaskFrequency frequency;

    @Column(name = "rrule", length = 255)
    private String rrule;

    @Column(name = "is_active", nullable = false)
    private Boolean isActive;

    @Column(name = "is_deleted", nullable = false)
    private Boolean isDeleted;

    @Column(name = "ctime", insertable = false, updatable = false)
    private LocalDateTime ctime;

    @Column(name = "utime", insertable = false, updatable = false)
    private LocalDateTime utime;

    /*
    // TaskCategoryEntity 조인 (레벨1)
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "level1_category_id", referencedColumnName = "task_category_id")
    private TaskCategoryEntity level1Category;

    // TaskCategoryEntity 조인 (레벨2)
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "level2_category_id", referencedColumnName = "task_category_id")
    private TaskCategoryEntity level2Category;
    */

    /*
    @Column(name = "task_type_name")
    private String taskTypeName;
    */
}
