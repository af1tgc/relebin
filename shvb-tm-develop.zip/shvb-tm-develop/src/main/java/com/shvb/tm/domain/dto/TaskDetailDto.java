package com.shvb.tm.domain.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.shvb.tm.domain.entity.TaskDetailJoinEntity;
import com.shvb.tm.domain.entity.TaskEntity.TaskStatus;
import lombok.*;

import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaskDetailDto {

    /*
     * select 조건
     *
     * Task Detail	: work_date & employee_id & is_deleted
     *
     * Task Detail	:	task_detail_id, content, link_url, remark, duration_minutes, is_late
     * Task			:	task_id, title, status
     * Task Type	:	task_type_id(Task랑 조인 필요), task_category_id(TaskCategory랑 조인 후 결과)
     * Task Category:	category_name
     * Employee		:	employee_name, manager_employee_id(is_team_leader일 경우, 자기자신 입력필요)
     *
     */

    // Task Detail
    private Long taskDetailId;
    private String content;
    private Long assignerEmployeeId;
    private String assignerEmployeeName;
    private String linkUrl;
    private String remark;
    private Integer durationMinutes;
    private Boolean isLate;

    // Task
    private Long taskId;
    private String taskTitle;
    private TaskStatus taskStatus;
    private LocalDate startDate;
    private LocalDate dueDate;

    // Task Type
    private Long taskTypeId;
    private String taskTypeName;

    // Task Category
    private Long taskCategoryId;
    private String taskCategoryName;

    // Department
    private Long departmentId;
    private String departmentName;

    private Long employeeId;
    private String employeeName;
    private LocalDate workDate;


    public TaskDetailDto(TaskDetailJoinEntity taskDetailJoinEntity){
        this.taskDetailId = taskDetailJoinEntity.getTaskDetailId();
        this.content = taskDetailJoinEntity.getContent();
        this.assignerEmployeeId = taskDetailJoinEntity.getAssigner().getEmployeeId();
        this.assignerEmployeeName = taskDetailJoinEntity.getAssigner().getEmployeeName();
        this.linkUrl = taskDetailJoinEntity.getLinkUrl();
        this.remark = taskDetailJoinEntity.getRemark();
        this.durationMinutes = taskDetailJoinEntity.getDurationMinutes();
        this.isLate = taskDetailJoinEntity.getIsLate();

        this.taskId = taskDetailJoinEntity.getTask().getTaskId();
        this.taskTitle = taskDetailJoinEntity.getTask().getTitle();
        this.taskStatus = taskDetailJoinEntity.getTask().getStatus();
        this.startDate = taskDetailJoinEntity.getTask().getStartDate();
        this.dueDate = taskDetailJoinEntity.getTask().getDueDate();

        this.taskTypeId = taskDetailJoinEntity.getTask().getTaskType().getTaskTypeId();
        this.taskTypeName = taskDetailJoinEntity.getTask().getTaskType().getTaskTypeName();

        this.taskCategoryId = taskDetailJoinEntity.getTask().getTaskType().getTaskCategoryId();
        if (taskDetailJoinEntity.getTask().getTaskType().getTaskCategory() != null) {
            this.taskCategoryName = taskDetailJoinEntity.getTask().getTaskType().getTaskCategory().getCategoryName();
        }

        this.departmentId = taskDetailJoinEntity.getTask().getTaskType().getDepartmentId();
        if (this.departmentId != null) {
            this.departmentName = taskDetailJoinEntity.getTask().getTaskType().getDepartment().getDepartmentName();
        }

        this.employeeId = taskDetailJoinEntity.getEmployee().getEmployeeId();
        this.employeeName = taskDetailJoinEntity.getEmployee().getEmployeeName();
        this.workDate = taskDetailJoinEntity.getWorkDate();

    }
}