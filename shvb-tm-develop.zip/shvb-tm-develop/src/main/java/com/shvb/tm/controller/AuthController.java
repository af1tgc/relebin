package com.shvb.tm.controller;

import com.shvb.common.domain.ApiResult;
import com.shvb.tm.domain.dto.LoginRequestDto;
import com.shvb.tm.domain.dto.LoginResponseDto;
import com.shvb.tm.service.AuthService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthService authService;
    private final PasswordEncoder passwordEncoder;

    @PostMapping("/login")
    public ResponseEntity<ApiResult<LoginResponseDto>> login(@RequestBody LoginRequestDto request) {
        LoginResponseDto response = authService.login(request);
        return ResponseEntity.ok(ApiResult.success(response));
    }

    // 임시: 비밀번호 해시 생성용
    @GetMapping("/hash")
    public ResponseEntity<String> generateHash(@RequestParam String password) {
        return ResponseEntity.ok(passwordEncoder.encode(password));
    }
}
