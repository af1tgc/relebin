package com.shvb.tm.service;

import com.shvb.exception.InvalidArgumentException;
import com.shvb.tm.domain.dto.TaskDetailRequestDto;
import com.shvb.tm.domain.entity.TaskDetailEntity;
import com.shvb.tm.domain.entity.TaskEntity;
import com.shvb.tm.repository.EmployeeRepository;
import com.shvb.tm.repository.TaskDetailRepository;
import com.shvb.tm.repository.TaskRepository;
import com.shvb.tm.repository.TaskTypeRepository;
import org.springframework.transaction.annotation.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Slf4j
@Service
public class TaskManagerService {

    @Autowired
    private TaskRepository taskRepository;

    @Autowired
    private TaskTypeRepository taskTypeRepository;

    @Autowired
    private TaskDetailRepository taskDetailRepository;

    @Autowired
    private EmployeeRepository employeeRepository;

    private static record StatusDecision(TaskEntity.TaskStatus nextStatus, boolean late) {}

    public List<?> getTaskList(String query) {
        if (query.length() < 2){
            throw new InvalidArgumentException("검색어를 입력해주세요.");
        }
        return taskRepository.findTaskByName(query);
    }

    public List<?> getTaskTypeList(String query) {

        if (query.length() < 2){
            throw new InvalidArgumentException("검색어를 입력해주세요.");
        }
        return taskTypeRepository.findTaskTypeByName(query);
    }

    public List<?> getTaskDetailList(String fromDate, String toDate, Long employeeId, Boolean isDeleted) {
        LocalDate fromLocalDate = LocalDate.parse(fromDate, DateTimeFormatter.ISO_DATE);
        LocalDate toLocalDate = LocalDate.parse(toDate, DateTimeFormatter.ISO_DATE);
        return taskDetailRepository.findTaskDetailWithJoin(fromLocalDate, toLocalDate, employeeId, isDeleted);
    }

    public List<?> getEmployeeList(String query) {
        if (query.length() < 2){
            throw new InvalidArgumentException("검색어를 입력해주세요.");
        }
        return employeeRepository.findEmployeeByName(query);
    }

    /**
     * 상태/지연 여부 공통 판정 로직
     * - DONE이면 무조건 유지
     * - workDate > dueDate 이면 DELAYED(+ isLate = true)
     * - 그 외에 현상태가 PLANNED/ON_HOLD이면 ACTIVE
     * - 그 밖에는 변경 없음
     */
    private StatusDecision decideStatus(TaskEntity.TaskStatus current, LocalDate dueDate, LocalDate workDate) {
        boolean late = (dueDate != null && workDate != null && workDate.isAfter(dueDate));

        if (current == TaskEntity.TaskStatus.DONE) {
            return new StatusDecision(null, late);             // 상태 유지
        }
        if (late) {
            return new StatusDecision(TaskEntity.TaskStatus.DELAYED, true); // 지연 최우선
        }
        if (current == TaskEntity.TaskStatus.PLANNED || current == TaskEntity.TaskStatus.ON_HOLD) {
            return new StatusDecision(TaskEntity.TaskStatus.ACTIVE, false);
        }
        return new StatusDecision(null, false);                  // 변경 없음
    }

    @Transactional
    public Long createTaskDetail(TaskDetailRequestDto dto) {
        // 1) 기본 검증
        if (dto == null) throw new InvalidArgumentException("payload is null");
        if (dto.getTaskId() == null) throw new InvalidArgumentException("taskId is required");
        if (dto.getEmployeeId() == null) throw new InvalidArgumentException("employeeId is required");
        if (dto.getWorkDate() == null) throw new InvalidArgumentException("workDate is required");
        if (dto.getDurationMinutes() == null || dto.getDurationMinutes() <= 0)
            throw new InvalidArgumentException("durationMinutes must be positive");
        if (dto.getContent() == null || dto.getContent().isBlank())
            throw new InvalidArgumentException("content is required");

        // 2) Task 조회 (due_date, status 필요)
        TaskEntity task = taskRepository.findById(dto.getTaskId())
                .orElseThrow(() -> new InvalidArgumentException("task not found: " + dto.getTaskId()));

        // 3) 상태/지연 여부 판정
        StatusDecision decision = decideStatus(task.getStatus(), task.getDueDate(), dto.getWorkDate());

        // 4) TaskDetail 저장 (FK를 Long으로 두었으므로 ID만 세팅)
        TaskDetailEntity e = new TaskDetailEntity();
        e.setTaskId(dto.getTaskId());
        e.setEmployeeId(dto.getEmployeeId());
        e.setWorkDate(dto.getWorkDate());
        e.setContent(dto.getContent());
        e.setDurationMinutes(dto.getDurationMinutes());
        e.setAssigner(dto.getAssignerEmployeeId());
        e.setLinkUrl(dto.getLinkUrl());
        e.setRemark(dto.getRemark());
        e.setIsLate(decision.late());
        e.setIsDeleted(Boolean.FALSE);

        try {
            taskDetailRepository.save(e);
        } catch (DataIntegrityViolationException ex) {
            // 길이 초과/NOT NULL 위반 등 DB 무결성 이슈를 의미 있는 메시지로 변환
            throw new InvalidArgumentException("데이터 무결성 위반: " + ex.getMostSpecificCause().getMessage());
        }

        log.debug("Determined next status for task {}: {}", dto.getTaskId(), decision.nextStatus());

        // 5) Task 상태 변경 필요 시 반영 (DONE이면 유지 / 그 외는 결정에 따름)
        if (decision.nextStatus() != null && decision.nextStatus() != task.getStatus()) {

            log.debug("Updating task status from {} to {} for taskId {} due to status decision.", task.getStatus(), decision.nextStatus(), task.getTaskId());
            task.setStatus(decision.nextStatus());
            taskRepository.save(task);
        }

        return e.getTaskDetailId();
    }

    @Transactional
    public void updateTaskDetail(Long taskDetailId, TaskDetailRequestDto dto) {
        // 1) 기존 엔티티 로드
        TaskDetailEntity e = taskDetailRepository.findById(taskDetailId)
                .orElseThrow(() -> new InvalidArgumentException("taskDetail not found: " + taskDetailId));

        // 2) 변경할 workDate 준비 및 변경 여부 계산
        LocalDate effectiveWorkDate = dto.getWorkDate() != null ? dto.getWorkDate() : e.getWorkDate();
        boolean dateChanged = dto.getWorkDate() != null && !dto.getWorkDate().isEqual(e.getWorkDate());

        // 3) 단순 필드 업데이트 (null 이면 건드리지 않음)
        if (dto.getContent() != null) e.setContent(dto.getContent());
        if (dto.getDurationMinutes() != null) e.setDurationMinutes(dto.getDurationMinutes());
        if (dto.getAssignerEmployeeId() != null) e.setAssigner(dto.getAssignerEmployeeId());
        if (dto.getLinkUrl() != null) e.setLinkUrl(dto.getLinkUrl());
        if (dto.getRemark() != null) e.setRemark(dto.getRemark());
        if (dto.getWorkDate() != null) e.setWorkDate(effectiveWorkDate); // 동일일자여도 idempotent하게 반영 가능

        // 4) 날짜가 바뀐 경우에만 상태/지연 재판정
        if (dateChanged) {
            TaskEntity task = taskRepository.findById(e.getTaskId())
                    .orElseThrow(() -> new InvalidArgumentException("task not found: " + e.getTaskId()));

            log.debug("Current task status before status decision: {}", task.getStatus());

            StatusDecision decision = decideStatus(task.getStatus(), task.getDueDate(), effectiveWorkDate);

            log.debug("Next status decided: {}", decision.nextStatus());

            e.setIsLate(decision.late()); // 레코드면 late(), Lombok class면 isLate()
            // task 상태 변경이 필요할 때만 업데이트
            if (decision.nextStatus() != null && decision.nextStatus() != task.getStatus()) {
                task.setStatus(decision.nextStatus());
                taskRepository.save(task);
            }
        }
        // 날짜가 안 바뀌면 e.isLate는 그대로 둠 (원하면 항상 재계산하도록 바꿀 수 있음)

        // 5) 저장
        taskDetailRepository.save(e);
    }
}
