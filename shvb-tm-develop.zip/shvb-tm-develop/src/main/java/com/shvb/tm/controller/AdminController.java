package com.shvb.tm.controller;

import com.shvb.common.domain.ApiResult;
import com.shvb.exception.InvalidArgumentException;
import com.shvb.tm.domain.dto.TaskRequestDto;
import com.shvb.tm.domain.dto.TaskSearchDto;
import com.shvb.tm.domain.dto.TaskSearchRequestDto;
import com.shvb.tm.domain.dto.TaskTypeRequestDto;
import com.shvb.tm.domain.dto.TaskTypeSearchDto;
import com.shvb.tm.security.JwtTokenProvider;
import com.shvb.tm.service.AdminService;
import com.shvb.tm.util.TaskSearchValidator;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;

@Slf4j
@RestController
@RequestMapping("/admin")
public class AdminController {
    @Autowired
    AdminService adminService;
    
    @Autowired
    JwtTokenProvider jwtTokenProvider;

    @GetMapping("/task/list")
    public ResponseEntity<ApiResult<?>> getTaskListAdmin(
            @ModelAttribute TaskSearchDto searchDto,
            @PageableDefault(size = 10, sort = "taskId") Pageable pageable) {
        log.debug("Task list search - taskCategoryId: {}, searchDto: {}", searchDto.getTaskCategoryId(), searchDto);
        return ResponseEntity.ok(ApiResult.success(
                adminService.getTaskListAdmin(searchDto, pageable)
        ));
    }

    @PostMapping("/task")
    public ResponseEntity<ApiResult<?>> createTask(@RequestBody TaskRequestDto taskRequestDto) {
        try {
            if (taskRequestDto == null) {
                throw new InvalidArgumentException("Request body is required");
            }
            Long taskId = adminService.createTask(taskRequestDto);
            return ResponseEntity.status(org.springframework.http.HttpStatus.CREATED)
                    .body(ApiResult.success("Task created successfully. ID: " + taskId));
        } catch (InvalidArgumentException e) {
            log.warn("Invalid task creation request: {}", e.getMessage());
            throw e; // ExceptionController에서 처리
        } catch (Exception e) {
            log.error("Error creating task: {}", taskRequestDto, e);
            throw e; // ExceptionController에서 처리
        }
    }

    @PostMapping("/task/{taskId}")
    public ResponseEntity<ApiResult<?>> updateTask(@PathVariable Long taskId, @RequestBody TaskRequestDto taskRequestDto) {
        try {
            if (taskId == null || taskId <= 0) {
                throw new InvalidArgumentException("Invalid taskId: " + taskId);
            }
            if (taskRequestDto == null) {
                throw new InvalidArgumentException("Request body is required");
            }
            adminService.updateTask(taskId, taskRequestDto);
            return ResponseEntity.ok(ApiResult.success("Task updated successfully"));
        } catch (InvalidArgumentException e) {
            log.warn("Invalid task update request for taskId {}: {}", taskId, e.getMessage());
            throw e; // ExceptionController에서 처리
        } catch (Exception e) {
            log.error("Error updating task {}: {}", taskId, taskRequestDto, e);
            throw e; // ExceptionController에서 처리
        }
    }

    @GetMapping("/task/type/list")
    public ResponseEntity<ApiResult<?>> getTaskTypeListAdmin(
            @ModelAttribute TaskTypeSearchDto searchDto,
            @PageableDefault(size = 10, sort = "taskTypeId") Pageable pageable) {
        return ResponseEntity.ok(ApiResult.success(
                adminService.getTaskTypeListAdmin(searchDto, pageable)
        ));
    }

    @PostMapping("/task/type")
    public ResponseEntity<ApiResult<?>> createTaskType(@RequestBody TaskTypeRequestDto taskTypeRequestDto) {
        try {
            if (taskTypeRequestDto == null) {
                throw new InvalidArgumentException("Request body is required");
            }
            Long taskTypeId = adminService.createTaskType(taskTypeRequestDto);
            return ResponseEntity.status(org.springframework.http.HttpStatus.CREATED)
                    .body(ApiResult.success("TaskType created successfully. ID: " + taskTypeId));
        } catch (InvalidArgumentException e) {
            log.warn("Invalid taskType creation request: {}", e.getMessage());
            throw e; // ExceptionController에서 처리
        } catch (Exception e) {
            log.error("Error creating taskType: {}", taskTypeRequestDto, e);
            throw e; // ExceptionController에서 처리
        }
    }

    @PostMapping("/task/type/{taskTypeId}")
    public ResponseEntity<ApiResult<?>> updateTaskType(@PathVariable Long taskTypeId, @RequestBody TaskTypeRequestDto taskTypeRequestDto) {
        try {
            if (taskTypeId == null || taskTypeId <= 0) {
                throw new InvalidArgumentException("Invalid taskTypeId: " + taskTypeId);
            }
            if (taskTypeRequestDto == null) {
                throw new InvalidArgumentException("Request body is required");
            }
            adminService.updateTaskType(taskTypeId, taskTypeRequestDto);
            return ResponseEntity.ok(ApiResult.success("TaskType updated successfully"));
        } catch (InvalidArgumentException e) {
            log.warn("Invalid taskType update request for taskTypeId {}: {}", taskTypeId, e.getMessage());
            throw e; // ExceptionController에서 처리
        } catch (Exception e) {
            log.error("Error updating taskType {}: {}", taskTypeId, taskTypeRequestDto, e);
            throw e; // ExceptionController에서 처리
        }
    }

    @GetMapping("/category")
    public ResponseEntity<ApiResult<?>> getTaskCategories() {
        return ResponseEntity.ok(ApiResult.success(
                adminService.getTaskCategories()
        ));
    }

    @GetMapping("/task/type/grouped")
    public ResponseEntity<ApiResult<?>> getTasksByTaskType(
            @ModelAttribute TaskSearchRequestDto searchDto,
            @RequestHeader("Authorization") String authorizationHeader) {
        // JWT에서 부서 ID 추출
        String token = authorizationHeader.substring(7); // "Bearer " 제거
        Long departmentId = jwtTokenProvider.getDepartmentIdFromToken(token);
        
        // startMonth, endMonth 기본값 설정
        if (searchDto.getStartMonth() == null || searchDto.getStartMonth().isEmpty()) {
            searchDto.setStartMonth(LocalDate.now().getYear() + "-01"); // 올해 1월
        }
        if (searchDto.getEndMonth() == null || searchDto.getEndMonth().isEmpty()) {
            searchDto.setEndMonth(LocalDate.now().format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM"))); // 현재월
        }
        
        return ResponseEntity.ok(ApiResult.success(
                adminService.getTasksByTaskType(departmentId, searchDto)
        ));
    }

    @GetMapping("/task/unwritten-users/{selectedDate}")
    public ResponseEntity<ApiResult<?>> getUnwrittenUsers(
            @PathVariable String selectedDate,
            @ModelAttribute TaskSearchRequestDto searchDto,
            @RequestHeader("Authorization") String authorizationHeader) {
        try {
            // JWT에서 부서 ID 추출
            String token = authorizationHeader.substring(7); // "Bearer " 제거
            Long departmentId = jwtTokenProvider.getDepartmentIdFromToken(token);
            
            // String을 LocalDate로 변환 (yyyy-MM-dd 형식)
            LocalDate date = LocalDate.parse(selectedDate);
            return ResponseEntity.ok(ApiResult.success(
                    adminService.getUnwrittenUsers(date, departmentId, searchDto)
            ));
        } catch (DateTimeParseException e) {
            log.error("Invalid date format: {}", selectedDate, e);
            throw new InvalidArgumentException("Invalid date format. Expected: yyyy-MM-dd, but got: " + selectedDate);
        } catch (Exception e) {
            log.error("Error getting unwritten users for date: {}", selectedDate, e);
            throw e; // ExceptionController에서 처리
        }
    }

    // 업무 완료 통계 조회
    @GetMapping("/task/completion-stats/{year}")
    public ResponseEntity<ApiResult<?>> getTaskCompletionStats(
            @PathVariable Integer year,
            @ModelAttribute TaskSearchRequestDto searchDto,
            @RequestHeader("Authorization") String authorizationHeader) {
        try {
            // JWT에서 부서 ID 추출
            String token = authorizationHeader.substring(7); // "Bearer " 제거
            Long departmentId = jwtTokenProvider.getDepartmentIdFromToken(token);
            
            // startMonth, endMonth 기본값 설정
            if (searchDto.getStartMonth() == null || searchDto.getStartMonth().isEmpty()) {
                searchDto.setStartMonth(LocalDate.now().getYear() + "-01"); // 올해 1월
            }
            if (searchDto.getEndMonth() == null || searchDto.getEndMonth().isEmpty()) {
                searchDto.setEndMonth(LocalDate.now().format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM"))); // 현재월
            }
            
            if (year == null || year <= 0) {
                throw new InvalidArgumentException("Invalid year: " + year);
            }
            return ResponseEntity.ok(ApiResult.success(
                    adminService.getTaskCompletionStats(year, departmentId, searchDto)
            ));
        } catch (InvalidArgumentException e) {
            log.warn("Invalid year {}: {}", year, e.getMessage());
            throw e; // ExceptionController에서 처리
        } catch (Exception e) {
            log.error("Error getting task completion stats for year: {}", year, e);
            throw e; // ExceptionController에서 처리
        }
    }

    // 모든 테이블 조인 검색
    @GetMapping("/task/search")
    public ResponseEntity<ApiResult<?>> searchTasksWithAllDetails(
            @ModelAttribute TaskSearchRequestDto searchDto,
            @PageableDefault(size = 10, sort = "taskId") Pageable pageable,
            @RequestHeader("Authorization") String authorizationHeader) {
        try {
            // JWT에서 부서 ID 추출
            String token = authorizationHeader.substring(7); // "Bearer " 제거
            Long departmentId = jwtTokenProvider.getDepartmentIdFromToken(token);
            
            // 날짜 필수 검증 및 최소 검색 조건 검증
            TaskSearchValidator.validateSearchConditions(searchDto);
            
            return ResponseEntity.ok(ApiResult.success(
                    adminService.searchTasksWithAllDetails(searchDto, departmentId, pageable)
            ));
        } catch (Exception e) {
            log.error("Error searching tasks with all details: {}", searchDto, e);
            throw e; // ExceptionController에서 처리
        }
    }
}
