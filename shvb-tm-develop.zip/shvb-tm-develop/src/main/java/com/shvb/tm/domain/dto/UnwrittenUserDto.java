package com.shvb.tm.domain.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UnwrittenUserDto {
    private Long employeeId;
    private String employeeName;
    private String departmentName;
}
