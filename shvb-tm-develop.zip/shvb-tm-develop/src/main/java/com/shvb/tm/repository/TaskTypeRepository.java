package com.shvb.tm.repository;

import com.shvb.tm.domain.dto.TaskTypeSearchDto;
import com.shvb.tm.domain.entity.TaskTypeEntity;
import com.shvb.tm.domain.projection.TaskTypeProjection;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface TaskTypeRepository extends JpaRepository<TaskTypeEntity, String> {

    @Query("""
           SELECT new com.shvb.tm.domain.dto.TaskTypeDto(
               tt
           )
           FROM TaskTypeJoinEntity tt
           WHERE 1=1
              AND LOWER(tt.taskTypeName) like CONCAT( '%', LOWER(:query), '%')
           """)
    List<?> findTaskTypeByName(String query);

    @Query(value = """
          SELECT
              tt.task_type_id as taskTypeId,
              tt.task_type_name as taskTypeName,
              tt.task_category_id as taskCategoryId,
              tc.category_name as taskCategoryName,
              tt.department_id as departmentId,
              d.department_name as departmentName
          FROM task_type tt
          LEFT JOIN task_category tc ON tt.task_category_id = tc.task_category_id
          LEFT JOIN department d ON tt.department_id = d.department_id
          WHERE 1=1
              AND (COALESCE(:#{#searchDto.taskTypeName}, '') = ''
                  OR LOWER(tt.task_type_name) LIKE CONCAT('%', LOWER(:#{#searchDto.taskTypeName}), '%'))
              AND (:#{#searchDto.taskCategoryId} IS NULL 
                  OR tt.task_category_id = :#{#searchDto.taskCategoryId})
              AND (:#{#searchDto.departmentId} IS NULL 
                  OR tt.department_id = :#{#searchDto.departmentId})
    """,
    countQuery = """
          SELECT
              COUNT(1)
          FROM task_type tt
          LEFT JOIN task_category tc ON tt.task_category_id = tc.task_category_id
          LEFT JOIN department d ON tt.department_id = d.department_id
          WHERE 1=1
              AND (COALESCE(:#{#searchDto.taskTypeName}, '') = ''
                  OR LOWER(tt.task_type_name) LIKE CONCAT('%', LOWER(:#{#searchDto.taskTypeName}), '%'))
              AND (:#{#searchDto.taskCategoryId} IS NULL 
                  OR tt.task_category_id = :#{#searchDto.taskCategoryId})
              AND (:#{#searchDto.departmentId} IS NULL 
                  OR tt.department_id = :#{#searchDto.departmentId})
    
    """,
    nativeQuery = true)
    Page<TaskTypeProjection> findTaskTypeForAdmin(@Param("searchDto") TaskTypeSearchDto searchDto, Pageable pageable);

    // 모든 TaskType 조회
    @Query("SELECT tt FROM TaskTypeEntity tt ORDER BY tt.taskTypeName")
    List<TaskTypeEntity> findAllTaskTypes();

    // 특정 TaskTypeId 목록에 해당하는 TaskType들만 조회
    @Query("SELECT tt FROM TaskTypeEntity tt WHERE tt.taskTypeId IN :taskTypeIds ORDER BY tt.taskTypeName")
    List<TaskTypeEntity> findByTaskTypeIdIn(@Param("taskTypeIds") List<Long> taskTypeIds);
}
