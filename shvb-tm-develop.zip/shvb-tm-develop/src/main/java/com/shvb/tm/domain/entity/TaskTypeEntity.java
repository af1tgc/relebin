package com.shvb.tm.domain.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Entity
@Table(
        name = "task_type",
        indexes = {
                @Index(name = "idx_task_type_category", columnList = "task_category_id"),
                @Index(name = "idx_task_type_department", columnList = "department_id")
        }
)
public class TaskTypeEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @EqualsAndHashCode.Include
    @Column(name = "task_type_id")
    private Long taskTypeId;

    @Column(name = "task_type_name", length = 100, nullable = false)
    private String taskTypeName;

    @Column(name = "task_category_id")
    private Long taskCategoryId;

    @Column(name = "department_id")
    private Long departmentId;

    @Column(name = "ctime", insertable = false, updatable = false)
    private LocalDateTime ctime;

    @Column(name = "utime", insertable = false, updatable = false)
    private LocalDateTime utime;
}