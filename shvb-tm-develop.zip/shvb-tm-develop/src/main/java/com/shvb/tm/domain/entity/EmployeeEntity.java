package com.shvb.tm.domain.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Entity
@Table(
        name = "employee",
        indexes = {
                @Index(name = "idx_employee_dept", columnList = "department_id")
        }
)
public class EmployeeEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @EqualsAndHashCode.Include
    @Column(name = "employee_id")
    private Long employeeId;

    @Column(name = "employee_name", length = 100, nullable = false)
    private String employeeName;

    @Column(name = "department_id")
    private Long departmentId;

    @Column(name = "is_team_leader", nullable = false)
    private Boolean isTeamLeader;

    // 임직원 직속 상급자
    @Column(name = "manager_employee_id")
    private Long managerEmployeeId;

    @Column(name = "ctime", insertable = false, updatable = false)
    private LocalDateTime ctime;

    @Column(name = "utime", insertable = false, updatable = false)
    private LocalDateTime utime;
}