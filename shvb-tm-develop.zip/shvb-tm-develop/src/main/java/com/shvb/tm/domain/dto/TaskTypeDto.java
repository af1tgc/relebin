package com.shvb.tm.domain.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.shvb.tm.domain.entity.TaskEntity;
import com.shvb.tm.domain.entity.TaskTypeJoinEntity;
import lombok.*;

import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaskTypeDto {
    private Long taskTypeId;
    private String taskTypeName;
    private Long taskCategoryId;
    private String taskCategoryName;
    private Long departmentId;
    private String departmentName;

    public TaskTypeDto(TaskTypeJoinEntity taskTypeJoinEntity) {
        this.taskTypeId = taskTypeJoinEntity.getTaskTypeId();
        this.taskTypeName = taskTypeJoinEntity.getTaskTypeName();
        if (taskTypeJoinEntity.getTaskCategory() != null) {
            this.taskCategoryId = taskTypeJoinEntity.getTaskCategory().getTaskCategoryId();
            this.taskCategoryName = taskTypeJoinEntity.getTaskCategory().getCategoryName();
        } else {
            this.taskCategoryId = null;
            this.taskCategoryName = null;
        }
        if (taskTypeJoinEntity.getDepartment() != null) {
            this.departmentId = taskTypeJoinEntity.getDepartment().getDepartmentId();
            this.departmentName = taskTypeJoinEntity.getDepartment().getDepartmentName();
        } else {
            this.departmentId = null;
            this.departmentName = null;
        }
    }
}