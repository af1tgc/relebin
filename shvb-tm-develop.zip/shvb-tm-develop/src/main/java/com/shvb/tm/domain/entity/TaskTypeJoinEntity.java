package com.shvb.tm.domain.entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "task_type")
public class TaskTypeJoinEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "task_type_id")
    private Long taskTypeId;

    @Column(name = "task_type_name", length = 100, nullable = false)
    private String taskTypeName;

    @Column(name = "task_category_id")
    private Long taskCategoryId;

    @Column(name = "department_id")
    private Long departmentId;

    // 조인: 카테고리
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "task_category_id", referencedColumnName = "task_category_id", insertable = false, updatable = false)
    private TaskCategoryEntity taskCategory;

    // 조인: 부서
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "department_id", referencedColumnName = "department_id", insertable = false, updatable = false)
    private DepartmentEntity department;
}
