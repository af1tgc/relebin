package com.shvb.tm.domain.dto;

import lombok.Data;

@Data
public class TaskSearchDto {
    private String taskName;
    private String taskType;
    private Long taskCategoryId;
    private String taskStatus;
    private String departmentName;
}
