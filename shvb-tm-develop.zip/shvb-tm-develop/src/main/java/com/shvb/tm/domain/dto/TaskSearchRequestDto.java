package com.shvb.tm.domain.dto;

import lombok.Data;
import java.util.List;

@Data
public class TaskSearchRequestDto {
    private String taskTypeName;
    private String taskCategory;
    private String taskName;
    private String taskStatus;
    private String departmentName;
    private String employeeName;
    private String workDate; // yyyy-MM-dd 형식
    private String startMonth; // yyyy-MM 형식 (예: 2025-01)
    private String endMonth;   // yyyy-MM 형식 (예: 2025-12)
    
    // 권한 필터링용 (서비스 레이어에서 설정)
    private List<Long> departmentIds;
}
