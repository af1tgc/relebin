package com.shvb.tm.domain.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaskSummaryDto {
    private Long taskId;
    private String title;
    private LocalDate startDate;
    private LocalDate dueDate;
}
