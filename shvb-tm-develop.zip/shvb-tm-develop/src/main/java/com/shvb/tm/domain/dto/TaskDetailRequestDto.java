package com.shvb.tm.domain.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaskDetailRequestDto {
    private Long taskId;
    private Long employeeId;
    private LocalDate workDate;
    private String content;
    private Integer durationMinutes;
    private Long assignerEmployeeId;
    private String linkUrl;
    private String remark;

}
