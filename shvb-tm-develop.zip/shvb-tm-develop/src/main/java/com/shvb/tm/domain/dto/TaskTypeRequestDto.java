package com.shvb.tm.domain.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaskTypeRequestDto {
    private String taskTypeName;
    private Long taskCategoryId;
    private Long departmentId;
}
