package com.shvb.tm.util;

import com.shvb.tm.domain.entity.DepartmentEntity;
import com.shvb.tm.repository.DepartmentRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.stream.Collectors;

/**
 * 부서 계층 구조 관련 유틸리티
 * 
 * 특정 부서 선택 시 해당 부서 및 모든 하위 부서 ID를 조회하여
 * WHERE department_id IN (...) 조건에 사용할 수 있도록 지원
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class DepartmentUtil {

    private final DepartmentRepository departmentRepository;

    /**
     * 선택한 부서와 그 하위 모든 부서의 ID 목록을 반환 (자기 자신 포함)
     * 
     * 예시:
     * - 8161(루트) 선택 → [8161, 1, 2, 7, 9]
     * - 1 선택 → [1, 7, 9]
     * - 2 선택 → [2]
     * - 7 선택 → [7]
     * 
     * @param departmentId 선택한 부서 ID
     * @return 부서 ID와 모든 하위 부서 ID 목록
     */
    public List<Long> getDepartmentIdsWithChildren(Long departmentId) {
        if (departmentId == null) {
            return List.of();
        }

        // 전체 부서 목록을 한 번에 가져와서 메모리에서 처리 (N+1 방지)
        List<DepartmentEntity> allDepartments = departmentRepository.findAll();
        
        // parentId -> children 맵 생성
        Map<Long, List<DepartmentEntity>> childrenMap = allDepartments.stream()
            .filter(d -> d.getParentDepartmentId() != null)
            .collect(Collectors.groupingBy(DepartmentEntity::getParentDepartmentId));

        Set<Long> resultSet = new HashSet<>();
        collectDepartmentIdsFromMap(departmentId, childrenMap, resultSet);
        return new ArrayList<>(resultSet);
    }

    /**
     * 메모리 상의 맵을 사용하여 재귀적으로 부서 ID 수집 (DB 호출 없음)
     */
    private void collectDepartmentIdsFromMap(Long departmentId, Map<Long, List<DepartmentEntity>> childrenMap, Set<Long> resultSet) {
        if (departmentId == null || resultSet.contains(departmentId)) {
            return; // 순환 참조 방지
        }

        // 자기 자신 추가
        resultSet.add(departmentId);

        // 하위 부서들 재귀 호출 (DB 호출 없이 맵에서 조회)
        List<DepartmentEntity> children = childrenMap.getOrDefault(departmentId, Collections.emptyList());
        for (DepartmentEntity child : children) {
            collectDepartmentIdsFromMap(child.getDepartmentId(), childrenMap, resultSet);
        }
    }

    /**
     * 여러 부서 ID에 대해 각각의 하위 부서를 모두 포함한 ID 목록 반환
     * 
     * @param departmentIds 선택한 부서 ID 목록
     * @return 모든 부서 ID와 그 하위 부서 ID 목록 (중복 제거)
     */
    public List<Long> getDepartmentIdsWithChildren(List<Long> departmentIds) {
        if (departmentIds == null || departmentIds.isEmpty()) {
            return List.of();
        }

        // 전체 부서 목록을 한 번에 가져와서 메모리에서 처리
        List<DepartmentEntity> allDepartments = departmentRepository.findAll();
        
        // parentId -> children 맵 생성
        Map<Long, List<DepartmentEntity>> childrenMap = allDepartments.stream()
            .filter(d -> d.getParentDepartmentId() != null)
            .collect(Collectors.groupingBy(DepartmentEntity::getParentDepartmentId));

        Set<Long> allIds = new HashSet<>();
        for (Long departmentId : departmentIds) {
            collectDepartmentIdsFromMap(departmentId, childrenMap, allIds);
        }
        return new ArrayList<>(allIds);
    }
}
