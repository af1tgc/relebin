package com.shvb.tm.service;

import com.shvb.exception.InvalidArgumentException;
import com.shvb.tm.domain.dto.LoginRequestDto;
import com.shvb.tm.domain.dto.LoginResponseDto;
import com.shvb.tm.domain.entity.EmployeeAccountEntity;
import com.shvb.tm.domain.entity.EmployeeEntity;
import com.shvb.tm.repository.EmployeeAccountRepository;
import com.shvb.tm.repository.EmployeeRepository;
import com.shvb.tm.security.JwtTokenProvider;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Slf4j
@Service
@RequiredArgsConstructor
public class AuthService {

    private final EmployeeAccountRepository accountRepository;
    private final EmployeeRepository employeeRepository;
    private final JwtTokenProvider jwtTokenProvider;
    private final PasswordEncoder passwordEncoder;

    private static final int MAX_FAILED_ATTEMPTS = 5;
    private static final int LOCK_DURATION_MINUTES = 30;

    @Transactional
    public LoginResponseDto login(LoginRequestDto request) {
        // 1. 계정 조회
        EmployeeAccountEntity account = accountRepository.findByUsername(request.getUsername())
                .orElseThrow(() -> new InvalidArgumentException("아이디 또는 비밀번호가 일치하지 않습니다."));

        // 2. 계정 잠금 확인
        if (account.getLockedUntil() != null && account.getLockedUntil().isAfter(LocalDateTime.now())) {
            throw new InvalidArgumentException("계정이 잠겼습니다. " + account.getLockedUntil() + "까지 로그인할 수 없습니다.");
        }

        // 3. 활성화 상태 확인
        if (!account.getIsActive()) {
            throw new InvalidArgumentException("비활성화된 계정입니다.");
        }

        // 4. 비밀번호 검증
        if (!passwordEncoder.matches(request.getPassword(), account.getPasswordHash())) {
            handleFailedLogin(account);
            throw new InvalidArgumentException("아이디 또는 비밀번호가 일치하지 않습니다.");
        }

        // 5. 로그인 성공 처리
        handleSuccessfulLogin(account);

        // 6. 직원 정보 조회
        EmployeeEntity employee = employeeRepository.findById(account.getEmployeeId())
                .orElseThrow(() -> new InvalidArgumentException("직원 정보를 찾을 수 없습니다."));

        // 7. role 결정 (null이면 USER로 기본값)
        String role = account.getRole() != null ? account.getRole() : "USER";

        // 8. JWT 토큰 생성 (부서 정보 포함)
        String token = jwtTokenProvider.generateToken(
                employee.getEmployeeId(), 
                account.getUsername(), 
                role, 
                employee.getDepartmentId()
        );

        return LoginResponseDto.builder()
                .token(token)
                .type("Bearer")
                .employeeId(employee.getEmployeeId())
                .username(account.getUsername())
                .employeeName(employee.getEmployeeName())
                .role(role)
                .build();
    }

    private void handleFailedLogin(EmployeeAccountEntity account) {
        int attempts = account.getFailedAttempts() + 1;
        account.setFailedAttempts(attempts);

        if (attempts >= MAX_FAILED_ATTEMPTS) {
            account.setLockedUntil(LocalDateTime.now().plusMinutes(LOCK_DURATION_MINUTES));
            log.warn("계정 잠금: username={}, lockedUntil={}", account.getUsername(), account.getLockedUntil());
        }

        accountRepository.save(account);
    }

    private void handleSuccessfulLogin(EmployeeAccountEntity account) {
        account.setFailedAttempts(0);
        account.setLockedUntil(null);
        account.setLastLoginAt(LocalDateTime.now());
        accountRepository.save(account);
    }

    /**
     * 회원가입 (관리자용)
     */
    @Transactional
    public void register(Long employeeId, String username, String password, String role) {
        // 직원 존재 확인
        employeeRepository.findById(employeeId)
                .orElseThrow(() -> new InvalidArgumentException("존재하지 않는 직원입니다."));

        // 중복 확인
        if (accountRepository.existsByUsername(username)) {
            throw new InvalidArgumentException("이미 사용 중인 아이디입니다.");
        }

        if (accountRepository.findByEmployeeId(employeeId).isPresent()) {
            throw new InvalidArgumentException("이미 계정이 등록된 직원입니다.");
        }

        // 계정 생성
        EmployeeAccountEntity account = EmployeeAccountEntity.builder()
                .employeeId(employeeId)
                .username(username)
                .passwordHash(passwordEncoder.encode(password))
                .role(role != null ? role : "USER")
                .isActive(true)
                .failedAttempts(0)
                .build();

        accountRepository.save(account);
    }
}
