package com.shvb.tm.domain.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TaskDetailResponseDto {
    // Task 정보
    private Long taskId;
    private String title;
    private String status;
    private String startDate; // TaskProjection과 동일하게 String
    private String dueDate;   // TaskProjection과 동일하게 String
    
    // TaskType 정보
    private Long taskTypeId;
    private String taskTypeName;
    
    // TaskCategory 정보
    private Long taskCategoryId;
    private String taskCategoryName;
    
    // Department 정보
    private Long departmentId;
    private String departmentName;
}
