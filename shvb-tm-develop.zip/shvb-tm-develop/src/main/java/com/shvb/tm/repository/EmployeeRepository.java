package com.shvb.tm.repository;

import com.shvb.tm.domain.dto.UnwrittenUserDto;
import com.shvb.tm.domain.entity.EmployeeEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;

public interface EmployeeRepository extends JpaRepository<EmployeeEntity, Long> {

    @Query("""
           SELECT new com.shvb.tm.domain.dto.EmployeeDto(
               e, d
           )
           FROM EmployeeEntity e
           LEFT JOIN DepartmentEntity d
              ON e.departmentId = d.departmentId
           WHERE 1=1
              AND (
                   LOWER(e.employeeName) like CONCAT( '%', LOWER(:query), '%')
                OR CAST(e.employeeId AS string) like CONCAT( '%', :query, '%')
              )
           """)
    List<?> findEmployeeByName(String query);

    // 특정 날짜에 TaskDetail을 작성하지 않은 사용자 조회 (직접 DTO 생성)
    @Query("""
        SELECT new com.shvb.tm.domain.dto.UnwrittenUserDto(
            e.employeeId,
            e.employeeName,
            d.departmentName
        )
        FROM EmployeeEntity e
        LEFT JOIN DepartmentEntity d ON e.departmentId = d.departmentId
        WHERE e.employeeId NOT IN (
            SELECT DISTINCT td.employeeId 
            FROM TaskDetailEntity td 
            WHERE td.workDate = :selectedDate 
            AND td.isDeleted = false
        )
        ORDER BY d.departmentName, e.employeeName
        """)
    List<UnwrittenUserDto> findUnwrittenUsersByDate(@Param("selectedDate") LocalDate selectedDate);

    // 특정 날짜에 TaskDetail을 작성하지 않은 사용자 조회 (부서 필터링 + 검색 필터)
    @Query("""
        SELECT new com.shvb.tm.domain.dto.UnwrittenUserDto(
            e.employeeId,
            e.employeeName,
            d.departmentName
        )
        FROM EmployeeEntity e
        LEFT JOIN DepartmentEntity d ON e.departmentId = d.departmentId
        WHERE e.departmentId IN (:departmentIds)
        AND (COALESCE(:employeeName, '') = '' OR LOWER(e.employeeName) LIKE CONCAT('%', LOWER(:employeeName), '%'))
        AND (COALESCE(:departmentName, '') = '' OR LOWER(d.departmentName) LIKE CONCAT('%', LOWER(:departmentName), '%'))
        AND e.employeeId NOT IN (
            SELECT DISTINCT td.employeeId 
            FROM TaskDetailEntity td 
            WHERE td.workDate = :selectedDate 
            AND td.isDeleted = false
        )
        ORDER BY d.departmentName, e.employeeName
        """)
    List<UnwrittenUserDto> findUnwrittenUsersByDateAndDepartments(
            @Param("selectedDate") LocalDate selectedDate,
            @Param("departmentIds") List<Long> departmentIds,
            @Param("employeeName") String employeeName,
            @Param("departmentName") String departmentName);

    // 특정 부서의 팀리더 조회
    @Query(value = """
        SELECT * FROM employee
        WHERE department_id = :departmentId
        AND is_team_leader = true
        """, nativeQuery = true)
    List<EmployeeEntity> findTeamLeadersByDepartmentId(@Param("departmentId") Long departmentId);

    // 특정 부서의 모든 직원 조회
    List<EmployeeEntity> findByDepartmentId(Long departmentId);

    // 직원과 관리자 정보를 한 번에 조회하는 네이티브 쿼리
    @Query(value = """
        SELECT 
            e.employee_id,
            e.employee_name,
            e.department_id,
            e.is_team_leader,
            CASE 
                WHEN e.is_team_leader = 0 THEN (
                    SELECT tl.employee_id 
                    FROM employee tl 
                    WHERE tl.department_id = e.department_id 
                    AND tl.is_team_leader = 1
                    AND tl.employee_id != e.employee_id
                    LIMIT 1
                )
                WHEN e.is_team_leader = 1 THEN (
                    SELECT tl2.employee_id
                    FROM department d
                    JOIN employee tl2 ON tl2.department_id = d.parent_department_id
                    WHERE d.department_id = e.department_id
                    AND tl2.is_team_leader = 1
                    LIMIT 1
                )
            END as manager_employee_id,
            CASE 
                WHEN e.is_team_leader = 0 THEN (
                    SELECT tl.employee_name
                    FROM employee tl 
                    WHERE tl.department_id = e.department_id 
                    AND tl.is_team_leader = 1
                    AND tl.employee_id != e.employee_id
                    LIMIT 1
                )
                WHEN e.is_team_leader = 1 THEN (
                    SELECT tl2.employee_name
                    FROM department d
                    JOIN employee tl2 ON tl2.department_id = d.parent_department_id
                    WHERE d.department_id = e.department_id
                    AND tl2.is_team_leader = 1
                    LIMIT 1
                )
            END as manager_employee_name,
            CASE 
                WHEN e.is_team_leader = 0 THEN (
                    SELECT tl.department_id
                    FROM employee tl 
                    WHERE tl.department_id = e.department_id 
                    AND tl.is_team_leader = 1
                    AND tl.employee_id != e.employee_id
                    LIMIT 1
                )
                WHEN e.is_team_leader = 1 THEN (
                    SELECT tl2.department_id
                    FROM department d
                    JOIN employee tl2 ON tl2.department_id = d.parent_department_id
                    WHERE d.department_id = e.department_id
                    AND tl2.is_team_leader = 1
                    LIMIT 1
                )
            END as manager_department_id
        FROM employee e
        WHERE e.employee_id = :employeeId
        """, nativeQuery = true)
    List<Object[]> findEmployeeWithManager(@Param("employeeId") Long employeeId);

}