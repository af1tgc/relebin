package com.shvb.tm.service;

import com.shvb.common.domain.PageResult;
import com.shvb.exception.InvalidArgumentException;
import com.shvb.tm.domain.dto.CategoryDto;
import com.shvb.tm.domain.dto.DepartmentDto;
import com.shvb.tm.domain.dto.TaskCompletionStatsDto;
import com.shvb.tm.domain.dto.TaskDetailResponseDto;
import com.shvb.tm.domain.dto.TaskRequestDto;
import com.shvb.tm.domain.dto.TaskSearchDto;
import com.shvb.tm.domain.dto.TaskSearchRequestDto;
import com.shvb.tm.domain.dto.TaskSearchResponseDto;
import com.shvb.tm.domain.dto.TaskSummaryDto;
import com.shvb.tm.domain.dto.TaskTypeRequestDto;
import com.shvb.tm.domain.dto.TaskTypeSearchDto;
import com.shvb.tm.domain.dto.TaskTypeWithTasksDto;
import com.shvb.tm.domain.dto.UnwrittenUserDto;
import com.shvb.tm.domain.entity.TaskCategoryEntity;
import com.shvb.tm.domain.entity.TaskEntity;
import com.shvb.tm.domain.entity.TaskTypeEntity;
import com.shvb.tm.domain.projection.TaskProjection;
import com.shvb.tm.domain.projection.TaskSearchProjection;
import com.shvb.tm.domain.projection.TaskTypeProjection;
import com.shvb.tm.repository.DepartmentRepository;
import com.shvb.tm.repository.EmployeeRepository;
import com.shvb.tm.repository.TaskCategoryRepository;
import com.shvb.tm.repository.TaskRepository;
import com.shvb.tm.repository.TaskTypeRepository;
import com.shvb.tm.util.DepartmentUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AdminService {

    private final TaskRepository taskRepository;
    private final TaskTypeRepository taskTypeRepository;
    private final TaskCategoryRepository taskCategoryRepository;
    private final EmployeeRepository employeeRepository;
    private final DepartmentRepository departmentRepository;
    private final DepartmentUtil departmentUtil;

    public PageResult<TaskDetailResponseDto> getTaskListAdmin(TaskSearchDto searchDto, Pageable pageable) {
        Page<TaskProjection> page = taskRepository.findTaskForAdmin(searchDto, pageable);
        
        // Projection을 DTO로 변환
        Page<TaskDetailResponseDto> dtoPage = page.map(projection -> 
            TaskDetailResponseDto.builder()
                .taskId(projection.getTaskId())
                .title(projection.getTitle())
                .status(projection.getStatus())
                .startDate(projection.getStartDate())
                .dueDate(projection.getDueDate())
                .taskTypeId(projection.getTaskTypeId())
                .taskTypeName(projection.getTaskTypeName())
                .taskCategoryId(projection.getTaskCategoryId())
                .taskCategoryName(projection.getTaskCategoryName())
                .departmentId(projection.getDepartmentId())
                .departmentName(projection.getDepartmentName())
                .build()
        );
        
        return PageResult.of(dtoPage);
    }

    @Transactional
    public Long createTask(TaskRequestDto dto) {
        // 1) 기본 검증
        if (dto == null) throw new InvalidArgumentException("payload is null");
        if (dto.getTitle() == null || dto.getTitle().isBlank())
            throw new InvalidArgumentException("title is required");
        if (dto.getTaskTypeId() == null) throw new InvalidArgumentException("taskTypeId is required");

        // 2) TaskEntity 생성
        TaskEntity.TaskEntityBuilder builder = TaskEntity.builder()
                .title(dto.getTitle())
                .taskTypeId(dto.getTaskTypeId())
                .startDate(dto.getStartDate())
                .dueDate(dto.getDueDate())
                .rrule(dto.getRrule())
                .isActive(dto.getIsActive() != null ? dto.getIsActive() : true)
                .isDeleted(false);

        // 3) Enum 변환
        if (dto.getStatus() != null) {
            builder.status(TaskEntity.TaskStatus.valueOf(dto.getStatus()));
        } else {
            builder.status(TaskEntity.TaskStatus.PLANNED); // 기본값
        }

        if (dto.getFrequency() != null) {
            builder.frequency(TaskEntity.TaskFrequency.valueOf(dto.getFrequency()));
        } else {
            builder.frequency(TaskEntity.TaskFrequency.NONE); // 기본값
        }

        TaskEntity entity = builder.build();
        TaskEntity saved = taskRepository.save(entity);
        return saved.getTaskId();
    }

    @Transactional
    public void updateTask(Long taskId, TaskRequestDto dto) {
        // 1) 기존 엔티티 로드
        TaskEntity entity = taskRepository.findById(taskId)
                .orElseThrow(() -> new InvalidArgumentException("task not found: " + taskId));

        // 2) 단순 필드 업데이트 (null이면 건드리지 않음)
        if (dto.getTitle() != null) entity.setTitle(dto.getTitle());
        if (dto.getTaskTypeId() != null) entity.setTaskTypeId(dto.getTaskTypeId());
        if (dto.getStartDate() != null) entity.setStartDate(dto.getStartDate());
        if (dto.getDueDate() != null) entity.setDueDate(dto.getDueDate());
        if (dto.getRrule() != null) entity.setRrule(dto.getRrule());
        if (dto.getIsActive() != null) entity.setIsActive(dto.getIsActive());

        // 3) Enum 필드 업데이트
        if (dto.getStatus() != null) {
            entity.setStatus(TaskEntity.TaskStatus.valueOf(dto.getStatus()));
        }
        if (dto.getFrequency() != null) {
            entity.setFrequency(TaskEntity.TaskFrequency.valueOf(dto.getFrequency()));
        }

        taskRepository.save(entity);
    }

    public PageResult<TaskTypeProjection> getTaskTypeListAdmin(TaskTypeSearchDto searchDto, Pageable pageable) {
        Page<TaskTypeProjection> page = taskTypeRepository.findTaskTypeForAdmin(searchDto, pageable);

        return PageResult.of(page);
    }

    // 카테고리 조회
    public List<CategoryDto> getTaskCategories() {
        List<TaskCategoryEntity> entities = taskCategoryRepository.findLevel1Categories();
        return entities.stream()
                .map(entity -> CategoryDto.builder()
                        .categoryId(entity.getTaskCategoryId())
                        .categoryName(entity.getCategoryName())
                        .categoryDepth(entity.getCategoryDepth())
                        .parentCategoryId(entity.getParentCategoryId())
                        .build())
                .collect(Collectors.toList());
    }

    // 부서 조회
    public List<DepartmentDto> getDepartments() {
        return departmentRepository.findAll().stream()
                .map(entity -> DepartmentDto.builder()
                        .departmentId(entity.getDepartmentId())
                        .departmentName(entity.getDepartmentName())
                        .build())
                .collect(Collectors.toList());
    }

    // 부서 계층 조회 (선택한 부서 + 하위 부서 ID 목록)
    public List<Long> getDepartmentIdsWithChildren(Long departmentId) {
        return departmentUtil.getDepartmentIdsWithChildren(departmentId);
    }

    // 직원과 관리자 정보 조회
    public Map<String, Object> getEmployeeWithManager(Long employeeId) {
        List<Object[]> results = employeeRepository.findEmployeeWithManager(employeeId);
        
        if (results.isEmpty()) {
            throw new InvalidArgumentException("Employee not found: " + employeeId);
        }
        
        Object[] row = results.get(0);
        Map<String, Object> result = new java.util.HashMap<>();
        
        result.put("employeeId", ((Number) row[0]).longValue());
        result.put("employeeName", row[1]);
        result.put("departmentId", row[2] != null ? ((Number) row[2]).longValue() : null);
        result.put("isTeamLeader", row[3]);
        result.put("managerEmployeeId", row[4] != null ? ((Number) row[4]).longValue() : null);
        result.put("managerEmployeeName", row[5]);
        result.put("managerDepartmentId", row[6] != null ? ((Number) row[6]).longValue() : null);
        
        return result;
    }

    // 부서별 직원 목록 조회
    public List<Map<String, Object>> getEmployeesByDepartment(Long departmentId) {
        return employeeRepository.findByDepartmentId(departmentId).stream()
            .map(e -> {
                Map<String, Object> map = new java.util.HashMap<>();
                map.put("employeeId", e.getEmployeeId());
                map.put("employeeName", e.getEmployeeName());
                map.put("departmentId", e.getDepartmentId());
                map.put("isTeamLeader", e.getIsTeamLeader());
                return map;
            })
            .collect(Collectors.toList());
    }

    @Transactional
    public Long createTaskType(TaskTypeRequestDto dto) {
        // 1) 기본 검증
        if (dto == null) throw new InvalidArgumentException("payload is null");
        if (dto.getTaskTypeName() == null || dto.getTaskTypeName().isBlank())
            throw new InvalidArgumentException("taskTypeName is required");
        if (dto.getTaskCategoryId() == null) throw new InvalidArgumentException("taskCategoryId is required");

        // 2) TaskTypeEntity 생성
        TaskTypeEntity entity = TaskTypeEntity.builder()
                .taskTypeName(dto.getTaskTypeName())
                .taskCategoryId(dto.getTaskCategoryId())
                .departmentId(dto.getDepartmentId())
                .build();

        TaskTypeEntity saved = taskTypeRepository.save(entity);
        return saved.getTaskTypeId();
    }

    @Transactional
    public void updateTaskType(Long taskTypeId, TaskTypeRequestDto dto) {
        // 1) 기존 엔티티 로드
        TaskTypeEntity entity = taskTypeRepository.findById(String.valueOf(taskTypeId))
                .orElseThrow(() -> new InvalidArgumentException("taskType not found: " + taskTypeId));

        // 2) 단순 필드 업데이트 (null이면 건드리지 않음)
        if (dto.getTaskTypeName() != null) entity.setTaskTypeName(dto.getTaskTypeName());
        if (dto.getTaskCategoryId() != null) entity.setTaskCategoryId(dto.getTaskCategoryId());
        if (dto.getDepartmentId() != null) entity.setDepartmentId(dto.getDepartmentId());

        taskTypeRepository.save(entity);
    }

    // TaskType별 Task 그룹핑 조회 (올해 기준, Task가 있는 TaskType만)
    public List<TaskTypeWithTasksDto> getTasksByTaskType(Long departmentId, TaskSearchRequestDto searchDto) {
        // 1) 부서 필터링용 부서 ID 목록 생성
        List<Long> allowedDepartmentIds = (departmentId != null) 
            ? departmentUtil.getDepartmentIdsWithChildren(departmentId) 
            : List.of();
        
        // 2) 올해 Task들을 먼저 조회 (부서 필터링 + 검색 필터 적용)
        List<TaskEntity> allTasks;
        if (!allowedDepartmentIds.isEmpty()) {
            allTasks = taskRepository.findAllActiveTasksOrderByTypeWithDepartments(
                allowedDepartmentIds,
                searchDto.getTaskTypeName(),
                searchDto.getTaskCategory(),
                searchDto.getTaskName(),
                searchDto.getTaskStatus(),
                searchDto.getDepartmentName(),
                searchDto.getEmployeeName(),
                searchDto.getStartMonth(),
                searchDto.getEndMonth()
            );
        } else {
            // 부서 필터링 없이 전체 조회
            allTasks = taskRepository.findAllActiveTasksOrderByType();
        }
        
        // 3) Task가 없으면 빈 목록 반환
        if (allTasks.isEmpty()) {
            return List.of();
        }
        
        // 4) Task들에서 사용된 TaskTypeId 목록 추출 (이미 필터링된 allTasks에서)
        List<Long> usedTaskTypeIds = allTasks.stream()
            .map(TaskEntity::getTaskTypeId)
            .distinct()
            .collect(Collectors.toList());
        
        // 5) 사용된 TaskType들만 조회
        List<TaskTypeEntity> taskTypes = taskTypeRepository.findByTaskTypeIdIn(usedTaskTypeIds);
        
        // 6) TaskTypeId로 그룹핑
        Map<Long, List<TaskEntity>> tasksByTypeId = allTasks.stream()
                .collect(Collectors.groupingBy(TaskEntity::getTaskTypeId));
        
        // 7) 결과 구성 (Task가 있는 TaskType만)
        List<TaskTypeWithTasksDto> result = taskTypes.stream()
                .map(taskType -> {
                    List<TaskEntity> tasks = tasksByTypeId.get(taskType.getTaskTypeId());
                    
                    List<TaskSummaryDto> taskSummaries = tasks.stream()
                            .map(task -> TaskSummaryDto.builder()
                                    .taskId(task.getTaskId())
                                    .title(task.getTitle())
                                    .startDate(task.getStartDate())
                                    .dueDate(task.getDueDate())
                                    .build())
                            .collect(Collectors.toList());
                    
                    return TaskTypeWithTasksDto.builder()
                            .taskTypeId(taskType.getTaskTypeId())
                            .taskTypeName(taskType.getTaskTypeName())
                            .tasks(taskSummaries)
                            .build();
                })
                .collect(Collectors.toList());
        
        return result;
    }

    // 특정 날짜에 TaskDetail을 작성하지 않은 사용자 조회
    public List<UnwrittenUserDto> getUnwrittenUsers(LocalDate selectedDate, Long departmentId, TaskSearchRequestDto searchDto) {
        // 부서 필터링용 부서 ID 목록 생성
        List<Long> allowedDepartmentIds = (departmentId != null) 
            ? departmentUtil.getDepartmentIdsWithChildren(departmentId) 
            : List.of();
        
        // 부서 ID가 없으면 빈 목록 반환
        if (allowedDepartmentIds.isEmpty()) {
            return List.of();
        }
        
        // 부서 필터링 + 검색 필터 적용
        return employeeRepository.findUnwrittenUsersByDateAndDepartments(
            selectedDate, 
            allowedDepartmentIds,
            searchDto.getEmployeeName(),
            searchDto.getDepartmentName()
        );
    }

    // 업무 완료 통계 조회
    public List<TaskCompletionStatsDto> getTaskCompletionStats(Integer year, Long departmentId, TaskSearchRequestDto searchDto) {
        // 부서 필터링용 부서 ID 목록 생성
        List<Long> allowedDepartmentIds = (departmentId != null) 
            ? departmentUtil.getDepartmentIdsWithChildren(departmentId) 
            : List.of();
        
        // 부서 ID가 없으면 빈 목록 반환
        if (allowedDepartmentIds.isEmpty()) {
            return List.of();
        }
        
        // 부서 필터링 + 검색 필터 적용
        return taskRepository.findTaskCompletionStatsByYearAndDepartments(
            allowedDepartmentIds,
            searchDto.getTaskTypeName(),
            searchDto.getTaskCategory(),
            searchDto.getTaskName(),
            searchDto.getTaskStatus(),
            searchDto.getDepartmentName(),
            searchDto.getEmployeeName(),
            searchDto.getStartMonth(),
            searchDto.getEndMonth()
        );
    }

    // 모든 테이블 조인 검색
    public PageResult<TaskSearchResponseDto> searchTasksWithAllDetails(TaskSearchRequestDto searchDto, Long departmentId, Pageable pageable) {
        // 부서 및 하위 부서 목록 조회 (DepartmentUtil 사용)
        Page<TaskSearchProjection> projections;
        
        List<Long> allowedDepartmentIds = (departmentId != null) 
            ? departmentUtil.getDepartmentIdsWithChildren(departmentId) 
            : List.of();
        
        if (!allowedDepartmentIds.isEmpty()) {
            // 부서 필터링 적용
            projections = taskRepository.findTasksWithAllDetailsByDepartments(searchDto, allowedDepartmentIds, pageable);
        } else {
            // 부서 정보 없거나 하위 부서 없으면 필터링 안함
            projections = taskRepository.findTasksWithAllDetails(searchDto, pageable);
        }
        
        // Projection을 DTO로 변환
        Page<TaskSearchResponseDto> dtoPage = projections.map(projection -> 
            new TaskSearchResponseDto(
                projection.getTaskId(),
                projection.getTaskTitle(),
                projection.getTaskStatus(),
                projection.getTaskStartDate(),
                projection.getTaskDueDate(),
                projection.getTaskTypeId(),
                projection.getTaskTypeName(),
                projection.getTaskCategoryId(),
                projection.getTaskCategoryName(),
                projection.getDepartmentId(),
                projection.getDepartmentName(),
                projection.getTaskDetailId(),
                projection.getWorkDate(),
                projection.getWorkContent(),
                projection.getWorkHours(),
                projection.getWorkerEmployeeId(),
                projection.getWorkerEmployeeName(),
                projection.getWorkerDepartmentId(),
                projection.getWorkerDepartmentName()
            )
        );
        
        return PageResult.of(dtoPage);
    }
}
