package com.shvb.tm.domain.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TaskSearchResponseDto {
    // Task 정보
    private Long taskId;
    private String taskTitle;
    private String taskStatus;
    private LocalDate taskStartDate;
    private LocalDate taskDueDate;
    
    // TaskType 정보
    private Long taskTypeId;
    private String taskTypeName;
    
    // TaskCategory 정보
    private Long taskCategoryId;
    private String taskCategoryName;
    
    // TaskType Department 정보
    private Long departmentId;
    private String departmentName;
    
    // TaskDetail 정보
    private Long taskDetailId;
    private LocalDate workDate;
    private String workContent;
    private Integer workHours;
    
    // TaskDetail 작업자 정보
    private Long workerEmployeeId;
    private String workerEmployeeName;
    private Long workerDepartmentId;
    private String workerDepartmentName;
}
