package com.shvb.tm.repository;

import com.shvb.tm.domain.dto.TaskCompletionStatsDto;
import com.shvb.tm.domain.dto.TaskSearchDto;
import com.shvb.tm.domain.dto.TaskSearchRequestDto;
import com.shvb.tm.domain.entity.TaskEntity;
import com.shvb.tm.domain.projection.TaskProjection;
import com.shvb.tm.domain.projection.TaskSearchProjection;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface TaskRepository extends JpaRepository<TaskEntity, Long> {

    @Query("""
           SELECT new com.shvb.tm.domain.dto.TaskDto(
               t, tt
           )
           FROM TaskEntity t
           LEFT JOIN TaskTypeJoinEntity tt
              ON t.taskTypeId = tt.taskTypeId
           WHERE 1=1
              AND LOWER(t.title) like CONCAT( '%', LOWER(:query), '%')
           """)
    List<?> findTaskByName(String query);

    @Query(value = """
        SELECT 
            t.task_id as taskId,
            t.title as title,
            t.status as status,
            t.task_type_id as taskTypeId,
            t.start_date as startDate,
            t.due_date as dueDate,
            ttj.task_type_name as taskTypeName,
            ttj.task_category_id as taskCategoryId,
            tc.category_name as taskCategoryName,
            ttj.department_id as departmentId,
            d.department_name as departmentName
        FROM task t
        LEFT JOIN task_type ttj ON t.task_type_id = ttj.task_type_id
        LEFT JOIN task_category tc ON ttj.task_category_id = tc.task_category_id
        LEFT JOIN department d ON ttj.department_id = d.department_id
        WHERE 1=1
           AND (:#{#searchDto.taskName} IS NULL
                  OR :#{#searchDto.taskName} = '' 
                  OR LOWER(t.title) LIKE CONCAT('%', LOWER(:#{#searchDto.taskName}), '%'))
           AND (:#{#searchDto.taskType} IS NULL
                  OR :#{#searchDto.taskType} = ''
                  OR LOWER(ttj.task_type_name) LIKE CONCAT('%', LOWER(:#{#searchDto.taskType}), '%'))
           AND (:#{#searchDto.taskCategoryId} IS NULL 
                  OR ttj.task_category_id = :#{#searchDto.taskCategoryId})
           AND (:#{#searchDto.taskStatus} IS NULL 
                  OR :#{#searchDto.taskStatus} = '' 
                  OR t.status = :#{#searchDto.taskStatus})
           AND (:#{#searchDto.departmentName} IS NULL
                  OR :#{#searchDto.departmentName} = ''
                  OR LOWER(d.department_name) LIKE CONCAT('%', LOWER(:#{#searchDto.departmentName}), '%'))
        """,
        countQuery = """
        SELECT COUNT(1)
        FROM task t
        LEFT JOIN task_type ttj ON t.task_type_id = ttj.task_type_id
        LEFT JOIN task_category tc ON ttj.task_category_id = tc.task_category_id
        LEFT JOIN department d ON ttj.department_id = d.department_id
        WHERE 1=1
           AND (:#{#searchDto.taskName} IS NULL
                  OR :#{#searchDto.taskName} = '' 
                  OR LOWER(t.title) LIKE CONCAT('%', LOWER(:#{#searchDto.taskName}), '%'))
           AND (:#{#searchDto.taskType} IS NULL
                  OR :#{#searchDto.taskType} = ''
                  OR LOWER(ttj.task_type_name) LIKE CONCAT('%', LOWER(:#{#searchDto.taskType}), '%'))
           AND (:#{#searchDto.taskCategoryId} IS NULL 
                  OR ttj.task_category_id = :#{#searchDto.taskCategoryId})
           AND (:#{#searchDto.taskStatus} IS NULL 
                  OR :#{#searchDto.taskStatus} = '' 
                  OR t.status = :#{#searchDto.taskStatus})
           AND (:#{#searchDto.departmentName} IS NULL
                  OR :#{#searchDto.departmentName} = ''
                  OR LOWER(d.department_name) LIKE CONCAT('%', LOWER(:#{#searchDto.departmentName}), '%'))
        """,
        nativeQuery = true)
    Page<TaskProjection> findTaskForAdmin(@Param("searchDto") TaskSearchDto searchDto, Pageable pageable);

    // TaskType별 Task 조회 (올해 기준)
    @Query("""
        SELECT t FROM TaskEntity t 
        WHERE t.taskTypeId = :taskTypeId 
        AND t.isDeleted = false 
        AND (YEAR(t.startDate) = YEAR(CURRENT_DATE) OR YEAR(t.dueDate) = YEAR(CURRENT_DATE))
        ORDER BY t.startDate, t.taskId
        """)
    List<TaskEntity> findByTaskTypeId(@Param("taskTypeId") Long taskTypeId);

    // 모든 TaskType의 Task 조회 (올해 기준)
    @Query("""
        SELECT t FROM TaskEntity t 
        WHERE t.isDeleted = false 
        AND (YEAR(t.startDate) = YEAR(CURRENT_DATE) OR YEAR(t.dueDate) = YEAR(CURRENT_DATE))
        ORDER BY t.taskTypeId, t.startDate, t.taskId
        """)
    List<TaskEntity> findAllActiveTasksOrderByType();

    // 올해 Task들의 TaskTypeId만 조회 (중복 제거)
    @Query("""
        SELECT DISTINCT t.taskTypeId FROM TaskEntity t 
        WHERE t.isDeleted = false 
        AND (YEAR(t.startDate) = YEAR(CURRENT_DATE) OR YEAR(t.dueDate) = YEAR(CURRENT_DATE))
        ORDER BY t.taskTypeId
        """)
    List<Long> findDistinctTaskTypeIdsForCurrentYear();

    // 모든 TaskType의 Task 조회 (올해 기준, 부서 필터링 + 검색 필터)
    @Query(value = """
        SELECT DISTINCT t.* FROM task t
        INNER JOIN task_type tt ON t.task_type_id = tt.task_type_id
        LEFT JOIN task_category tc ON tt.task_category_id = tc.task_category_id
        LEFT JOIN department d ON tt.department_id = d.department_id
        LEFT JOIN task_detail td ON t.task_id = td.task_id AND td.is_deleted = false
        LEFT JOIN employee e ON td.employee_id = e.employee_id
        WHERE t.is_deleted = false 
        AND (
            COALESCE(:startMonth, '') = '' OR COALESCE(:endMonth, '') = '' OR
            (
                (t.start_date >= CONCAT(:startMonth, '-01') AND t.start_date <= LAST_DAY(CONCAT(:endMonth, '-01')))
                OR (t.due_date >= CONCAT(:startMonth, '-01') AND t.due_date <= LAST_DAY(CONCAT(:endMonth, '-01')))
            )
        )
        AND tt.department_id IN (:departmentIds)
        AND (COALESCE(:taskTypeName, '') = '' OR LOWER(tt.task_type_name) LIKE CONCAT('%', LOWER(:taskTypeName), '%'))
        AND (COALESCE(:taskCategory, '') = '' OR LOWER(tc.category_name) LIKE CONCAT('%', LOWER(:taskCategory), '%'))
        AND (COALESCE(:taskName, '') = '' OR LOWER(t.title) LIKE CONCAT('%', LOWER(:taskName), '%'))
        AND (COALESCE(:taskStatus, '') = '' OR t.status = :taskStatus)
        AND (COALESCE(:departmentName, '') = '' OR LOWER(d.department_name) LIKE CONCAT('%', LOWER(:departmentName), '%'))
        AND (COALESCE(:employeeName, '') = '' OR LOWER(e.employee_name) LIKE CONCAT('%', LOWER(:employeeName), '%'))
        ORDER BY t.task_type_id, t.start_date, t.task_id
        """, nativeQuery = true)
    List<TaskEntity> findAllActiveTasksOrderByTypeWithDepartments(
        @Param("departmentIds") List<Long> departmentIds,
        @Param("taskTypeName") String taskTypeName,
        @Param("taskCategory") String taskCategory,
        @Param("taskName") String taskName,
        @Param("taskStatus") String taskStatus,
        @Param("departmentName") String departmentName,
        @Param("employeeName") String employeeName,
        @Param("startMonth") String startMonth,
        @Param("endMonth") String endMonth);

    // 올해 Task들의 TaskTypeId만 조회 (부서 필터링 + 검색 필터, 중복 제거)
    @Query(value = """
        SELECT DISTINCT t.task_type_id FROM task t
        INNER JOIN task_type tt ON t.task_type_id = tt.task_type_id
        LEFT JOIN task_category tc ON tt.task_category_id = tc.task_category_id
        LEFT JOIN department d ON tt.department_id = d.department_id
        LEFT JOIN task_detail td ON t.task_id = td.task_id AND td.is_deleted = false
        LEFT JOIN employee e ON td.employee_id = e.employee_id
        WHERE t.is_deleted = false 
        AND (YEAR(t.start_date) = YEAR(CURRENT_DATE) OR YEAR(t.due_date) = YEAR(CURRENT_DATE))
        AND tt.department_id IN (:departmentIds)
        AND (COALESCE(:taskTypeName, '') = '' OR LOWER(tt.task_type_name) LIKE CONCAT('%', LOWER(:taskTypeName), '%'))
        AND (COALESCE(:taskCategory, '') = '' OR LOWER(tc.category_name) LIKE CONCAT('%', LOWER(:taskCategory), '%'))
        AND (COALESCE(:taskName, '') = '' OR LOWER(t.title) LIKE CONCAT('%', LOWER(:taskName), '%'))
        AND (COALESCE(:taskStatus, '') = '' OR t.status = :taskStatus)
        AND (COALESCE(:departmentName, '') = '' OR LOWER(d.department_name) LIKE CONCAT('%', LOWER(:departmentName), '%'))
        AND (COALESCE(:employeeName, '') = '' OR LOWER(e.employee_name) LIKE CONCAT('%', LOWER(:employeeName), '%'))
        ORDER BY t.task_type_id
        """, nativeQuery = true)
    List<Long> findDistinctTaskTypeIdsForCurrentYearWithDepartments(
        @Param("departmentIds") List<Long> departmentIds,
        @Param("taskTypeName") String taskTypeName,
        @Param("taskCategory") String taskCategory,
        @Param("taskName") String taskName,
        @Param("taskStatus") String taskStatus,
        @Param("departmentName") String departmentName,
        @Param("employeeName") String employeeName);

    // 특정 연도의 Task 상태별 통계 조회
    @Query("""
        SELECT new com.shvb.tm.domain.dto.TaskCompletionStatsDto(
            CASE t.status
                WHEN 'DONE' THEN '완료'
                WHEN 'ACTIVE' THEN '진행중'
                WHEN 'DELAYED' THEN '지연'
                WHEN 'PLANNED' THEN '계획됨'
                WHEN 'ON_HOLD' THEN '보류'
                ELSE '기타'
            END,
            COUNT(t)
        )
        FROM TaskEntity t 
        WHERE t.isDeleted = false 
        AND (YEAR(t.startDate) = :year OR YEAR(t.dueDate) = :year)
        GROUP BY t.status
        ORDER BY 
            CASE t.status
                WHEN 'DONE' THEN 1
                WHEN 'ACTIVE' THEN 2
                WHEN 'DELAYED' THEN 3
                WHEN 'PLANNED' THEN 4
                WHEN 'ON_HOLD' THEN 5
                ELSE 6
            END
        """)
    List<TaskCompletionStatsDto> findTaskCompletionStatsByYear(@Param("year") Integer year);

    // 특정 연도의 Task 상태별 통계 조회 (부서 필터링 + 검색 필터)
    @Query(value = """
        SELECT 
            CASE t.status
                WHEN 'DONE' THEN '완료'
                WHEN 'ACTIVE' THEN '진행중'
                WHEN 'DELAYED' THEN '지연'
                WHEN 'PLANNED' THEN '계획됨'
                WHEN 'ON_HOLD' THEN '보류'
                ELSE '기타'
            END as statusName,
            COUNT(DISTINCT t.task_id) as count
        FROM task t 
        INNER JOIN task_type tt ON t.task_type_id = tt.task_type_id
        LEFT JOIN task_category tc ON tt.task_category_id = tc.task_category_id
        LEFT JOIN department d ON tt.department_id = d.department_id
        LEFT JOIN task_detail td ON t.task_id = td.task_id AND td.is_deleted = false
        LEFT JOIN employee e ON td.employee_id = e.employee_id
        WHERE t.is_deleted = false 
        AND (
            COALESCE(:startMonth, '') = '' OR COALESCE(:endMonth, '') = '' OR
            (
                (t.start_date >= CONCAT(:startMonth, '-01') AND t.start_date <= LAST_DAY(CONCAT(:endMonth, '-01')))
                OR (t.due_date >= CONCAT(:startMonth, '-01') AND t.due_date <= LAST_DAY(CONCAT(:endMonth, '-01')))
            )
        )
        AND tt.department_id IN (:departmentIds)
        AND (COALESCE(:taskTypeName, '') = '' OR LOWER(tt.task_type_name) LIKE CONCAT('%', LOWER(:taskTypeName), '%'))
        AND (COALESCE(:taskCategory, '') = '' OR LOWER(tc.category_name) LIKE CONCAT('%', LOWER(:taskCategory), '%'))
        AND (COALESCE(:taskName, '') = '' OR LOWER(t.title) LIKE CONCAT('%', LOWER(:taskName), '%'))
        AND (COALESCE(:taskStatus, '') = '' OR t.status = :taskStatus)
        AND (COALESCE(:departmentName, '') = '' OR LOWER(d.department_name) LIKE CONCAT('%', LOWER(:departmentName), '%'))
        AND (COALESCE(:employeeName, '') = '' OR LOWER(e.employee_name) LIKE CONCAT('%', LOWER(:employeeName), '%'))
        GROUP BY t.status 
        ORDER BY 
            CASE t.status
                WHEN 'DONE' THEN 1
                WHEN 'ACTIVE' THEN 2
                WHEN 'DELAYED' THEN 3
                WHEN 'PLANNED' THEN 4
                WHEN 'ON_HOLD' THEN 5
                ELSE 6
            END
        """, nativeQuery = true)
    List<Object[]> findTaskCompletionStatsByYearAndDepartmentsNative(
            @Param("departmentIds") List<Long> departmentIds,
            @Param("taskTypeName") String taskTypeName,
            @Param("taskCategory") String taskCategory,
            @Param("taskName") String taskName,
            @Param("taskStatus") String taskStatus,
            @Param("departmentName") String departmentName,
            @Param("employeeName") String employeeName,
            @Param("startMonth") String startMonth,
            @Param("endMonth") String endMonth);

    // Native 쿼리 결과를 DTO로 변환하는 기본 메서드 (검색 필터 지원)
    default List<TaskCompletionStatsDto> findTaskCompletionStatsByYearAndDepartments(
            List<Long> departmentIds, String taskTypeName, 
            String taskCategory, String taskName, String taskStatus,
            String departmentName, String employeeName, String startMonth, String endMonth) {
        return findTaskCompletionStatsByYearAndDepartmentsNative(
                departmentIds, taskTypeName, taskCategory, taskName, taskStatus, 
                departmentName, employeeName, startMonth, endMonth).stream()
            .map(row -> new TaskCompletionStatsDto((String) row[0], ((Number) row[1]).longValue()))
            .collect(java.util.stream.Collectors.toList());
    }

    // 모든 테이블 조인 검색
    @Query(value = """
        SELECT 
            t.task_id as taskId,
            t.title as taskTitle,
            t.status as taskStatus,
            t.start_date as taskStartDate,
            t.due_date as taskDueDate,
            tt.task_type_id as taskTypeId,
            tt.task_type_name as taskTypeName,
            tc.task_category_id as taskCategoryId,
            tc.category_name as taskCategoryName,
            ttd.department_id as departmentId,
            ttd.department_name as departmentName,
            td.task_detail_id as taskDetailId,
            td.work_date as workDate,
            td.content as workContent,
            td.duration_minutes as workHours,
            we.employee_id as workerEmployeeId,
            we.employee_name as workerEmployeeName,
            wd.department_id as workerDepartmentId,
            wd.department_name as workerDepartmentName
        FROM task t
        LEFT JOIN task_type tt ON t.task_type_id = tt.task_type_id
        LEFT JOIN task_category tc ON tt.task_category_id = tc.task_category_id
        LEFT JOIN department ttd ON tt.department_id = ttd.department_id
        LEFT JOIN task_detail td ON t.task_id = td.task_id
        LEFT JOIN employee we ON td.employee_id = we.employee_id
        LEFT JOIN department wd ON we.department_id = wd.department_id
        LEFT JOIN department d ON tt.department_id = d.department_id
        WHERE 1=1
           AND (:#{#searchDto.taskTypeName} IS NULL
                  OR :#{#searchDto.taskTypeName} = '' 
                  OR LOWER(tt.task_type_name) LIKE CONCAT('%', LOWER(:#{#searchDto.taskTypeName}), '%'))
           AND (:#{#searchDto.taskCategory} IS NULL 
                  OR :#{#searchDto.taskCategory} = ''
                  OR LOWER(tc.category_name) LIKE CONCAT('%', LOWER(:#{#searchDto.taskCategory}), '%'))
           AND (:#{#searchDto.taskName} IS NULL
                  OR :#{#searchDto.taskName} = '' 
                  OR LOWER(t.title) LIKE CONCAT('%', LOWER(:#{#searchDto.taskName}), '%'))
           AND (:#{#searchDto.taskStatus} IS NULL 
                  OR :#{#searchDto.taskStatus} = '' 
                  OR t.status = :#{#searchDto.taskStatus})
           AND (:#{#searchDto.departmentName} IS NULL
                  OR :#{#searchDto.departmentName} = ''
                  OR LOWER(d.department_name) LIKE CONCAT('%', LOWER(:#{#searchDto.departmentName}), '%'))
           AND (:#{#searchDto.employeeName} IS NULL
                  OR :#{#searchDto.employeeName} = ''
                  OR LOWER(we.employee_name) LIKE CONCAT('%', LOWER(:#{#searchDto.employeeName}), '%'))
           AND (:#{#searchDto.workDate} IS NULL
                  OR :#{#searchDto.workDate} = ''
                  OR td.work_date = :#{#searchDto.workDate})
           AND td.task_detail_id IS NOT NULL
        ORDER BY t.task_id
        """,
        countQuery = """
        SELECT COUNT(DISTINCT t.task_id)
        FROM task t
        LEFT JOIN task_type tt ON t.task_type_id = tt.task_type_id
        LEFT JOIN task_category tc ON tt.task_category_id = tc.task_category_id
        LEFT JOIN department ttd ON tt.department_id = ttd.department_id
        LEFT JOIN task_detail td ON t.task_id = td.task_id
        LEFT JOIN employee we ON td.employee_id = we.employee_id
        LEFT JOIN department wd ON we.department_id = wd.department_id
        LEFT JOIN department d ON tt.department_id = d.department_id
        WHERE 1=1
           AND (:#{#searchDto.taskTypeName} IS NULL
                  OR :#{#searchDto.taskTypeName} = '' 
                  OR LOWER(tt.task_type_name) LIKE CONCAT('%', LOWER(:#{#searchDto.taskTypeName}), '%'))
           AND (:#{#searchDto.taskCategory} IS NULL 
                  OR :#{#searchDto.taskCategory} = ''
                  OR LOWER(tc.category_name) LIKE CONCAT('%', LOWER(:#{#searchDto.taskCategory}), '%'))
           AND (:#{#searchDto.taskName} IS NULL
                  OR :#{#searchDto.taskName} = '' 
                  OR LOWER(t.title) LIKE CONCAT('%', LOWER(:#{#searchDto.taskName}), '%'))
           AND (:#{#searchDto.taskStatus} IS NULL 
                  OR :#{#searchDto.taskStatus} = '' 
                  OR t.status = :#{#searchDto.taskStatus})
           AND (:#{#searchDto.departmentName} IS NULL
                  OR :#{#searchDto.departmentName} = ''
                  OR LOWER(d.department_name) LIKE CONCAT('%', LOWER(:#{#searchDto.departmentName}), '%'))
           AND (:#{#searchDto.employeeName} IS NULL
                  OR :#{#searchDto.employeeName} = ''
                  OR LOWER(we.employee_name) LIKE CONCAT('%', LOWER(:#{#searchDto.employeeName}), '%'))
           AND (:#{#searchDto.workDate} IS NULL
                  OR :#{#searchDto.workDate} = ''
                  OR td.work_date = :#{#searchDto.workDate})
           AND td.task_detail_id IS NOT NULL
        """,
        nativeQuery = true)
    Page<TaskSearchProjection> findTasksWithAllDetails(@Param("searchDto") TaskSearchRequestDto searchDto, Pageable pageable);

    // 부서 필터링 포함 검색
    @Query(value = """
        SELECT 
            t.task_id as taskId,
            t.title as taskTitle,
            t.status as taskStatus,
            t.start_date as taskStartDate,
            t.due_date as taskDueDate,
            tt.task_type_id as taskTypeId,
            tt.task_type_name as taskTypeName,
            tc.task_category_id as taskCategoryId,
            tc.category_name as taskCategoryName,
            ttd.department_id as departmentId,
            ttd.department_name as departmentName,
            td.task_detail_id as taskDetailId,
            td.work_date as workDate,
            td.content as workContent,
            td.duration_minutes as workHours,
            we.employee_id as workerEmployeeId,
            we.employee_name as workerEmployeeName,
            wd.department_id as workerDepartmentId,
            wd.department_name as workerDepartmentName
        FROM task t
        LEFT JOIN task_type tt ON t.task_type_id = tt.task_type_id
        LEFT JOIN task_category tc ON tt.task_category_id = tc.task_category_id
        LEFT JOIN department ttd ON tt.department_id = ttd.department_id
        LEFT JOIN task_detail td ON t.task_id = td.task_id
        LEFT JOIN employee we ON td.employee_id = we.employee_id
        LEFT JOIN department wd ON we.department_id = wd.department_id
        LEFT JOIN department d ON tt.department_id = d.department_id
        WHERE 1=1
           AND wd.department_id IN (:departmentIds)
           AND (:#{#searchDto.taskTypeName} IS NULL
                  OR :#{#searchDto.taskTypeName} = '' 
                  OR LOWER(tt.task_type_name) LIKE CONCAT('%', LOWER(:#{#searchDto.taskTypeName}), '%'))
           AND (:#{#searchDto.taskCategory} IS NULL 
                  OR :#{#searchDto.taskCategory} = ''
                  OR LOWER(tc.category_name) LIKE CONCAT('%', LOWER(:#{#searchDto.taskCategory}), '%'))
           AND (:#{#searchDto.taskName} IS NULL
                  OR :#{#searchDto.taskName} = '' 
                  OR LOWER(t.title) LIKE CONCAT('%', LOWER(:#{#searchDto.taskName}), '%'))
           AND (:#{#searchDto.taskStatus} IS NULL 
                  OR :#{#searchDto.taskStatus} = '' 
                  OR t.status = :#{#searchDto.taskStatus})
           AND (:#{#searchDto.departmentName} IS NULL
                  OR :#{#searchDto.departmentName} = ''
                  OR LOWER(d.department_name) LIKE CONCAT('%', LOWER(:#{#searchDto.departmentName}), '%'))
           AND (:#{#searchDto.employeeName} IS NULL
                  OR :#{#searchDto.employeeName} = ''
                  OR LOWER(we.employee_name) LIKE CONCAT('%', LOWER(:#{#searchDto.employeeName}), '%'))
           AND (:#{#searchDto.workDate} IS NULL
                  OR :#{#searchDto.workDate} = ''
                  OR td.work_date = :#{#searchDto.workDate})
           AND td.task_detail_id IS NOT NULL
        ORDER BY t.task_id
        """,
        countQuery = """
        SELECT COUNT(DISTINCT t.task_id)
        FROM task t
        LEFT JOIN task_type tt ON t.task_type_id = tt.task_type_id
        LEFT JOIN task_category tc ON tt.task_category_id = tc.task_category_id
        LEFT JOIN department ttd ON tt.department_id = ttd.department_id
        LEFT JOIN task_detail td ON t.task_id = td.task_id
        LEFT JOIN employee we ON td.employee_id = we.employee_id
        LEFT JOIN department wd ON we.department_id = wd.department_id
        LEFT JOIN department d ON tt.department_id = d.department_id
        WHERE 1=1
           AND wd.department_id IN (:departmentIds)
           AND (:#{#searchDto.taskTypeName} IS NULL
                  OR :#{#searchDto.taskTypeName} = '' 
                  OR LOWER(tt.task_type_name) LIKE CONCAT('%', LOWER(:#{#searchDto.taskTypeName}), '%'))
           AND (:#{#searchDto.taskCategory} IS NULL 
                  OR :#{#searchDto.taskCategory} = ''
                  OR LOWER(tc.category_name) LIKE CONCAT('%', LOWER(:#{#searchDto.taskCategory}), '%'))
           AND (:#{#searchDto.taskName} IS NULL
                  OR :#{#searchDto.taskName} = '' 
                  OR LOWER(t.title) LIKE CONCAT('%', LOWER(:#{#searchDto.taskName}), '%'))
           AND (:#{#searchDto.taskStatus} IS NULL 
                  OR :#{#searchDto.taskStatus} = '' 
                  OR t.status = :#{#searchDto.taskStatus})
           AND (:#{#searchDto.departmentName} IS NULL
                  OR :#{#searchDto.departmentName} = ''
                  OR LOWER(d.department_name) LIKE CONCAT('%', LOWER(:#{#searchDto.departmentName}), '%'))
           AND (:#{#searchDto.employeeName} IS NULL
                  OR :#{#searchDto.employeeName} = ''
                  OR LOWER(we.employee_name) LIKE CONCAT('%', LOWER(:#{#searchDto.employeeName}), '%'))
           AND (:#{#searchDto.workDate} IS NULL
                  OR :#{#searchDto.workDate} = ''
                  OR td.work_date = :#{#searchDto.workDate})
           AND td.task_detail_id IS NOT NULL
        """,
        nativeQuery = true)
    Page<TaskSearchProjection> findTasksWithAllDetailsByDepartments(
            @Param("searchDto") TaskSearchRequestDto searchDto, 
            @Param("departmentIds") List<Long> departmentIds,
            Pageable pageable);
}
