package com.shvb.tm.domain.projection;

public interface TaskProjection {
    Long getTaskId();
    String getTitle();
    String getStatus();
    Long getTaskTypeId();
    String getTaskTypeName();
    String getStartDate();
    String getDueDate();
    Long getTaskCategoryId();
    String getTaskCategoryName();
    Long getDepartmentId();
    String getDepartmentName();
}
