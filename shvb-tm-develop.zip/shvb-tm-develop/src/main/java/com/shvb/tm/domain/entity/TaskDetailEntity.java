package com.shvb.tm.domain.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Entity
@Table(
        name = "task_detail",
        indexes = {
                @Index(name = "idx_task_detail_employee_date", columnList = "employee_id,work_date"),
                @Index(name = "idx_task_detail_task_date", columnList = "task_id,work_date"),
                @Index(name = "idx_task_detail_task", columnList = "task_id"),
                @Index(name = "idx_task_detail_task_employee", columnList = "task_id,employee_id")
        }
)
public class TaskDetailEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @EqualsAndHashCode.Include
    @Column(name = "task_detail_id")
    private Long taskDetailId;

    @Column(name = "task_id")
    private Long taskId;

    @Column(name = "employee_id")
    private Long employeeId;

    @Column(name = "work_date", nullable = false)
    private LocalDate workDate;

    @Lob
    @Column(name = "content", nullable = false, columnDefinition = "TEXT")
    private String content;

    @Column(name = "assigner_employee_id")
    private Long assigner;

    @Column(name = "link_url", length = 500)
    private String linkUrl;

    @Column(name = "remark", length = 500)
    private String remark;

    @Column(name = "duration_minutes", nullable = false)
    private Integer durationMinutes;

    @Column(name = "is_late", nullable = false)
    private Boolean isLate;

    @Column(name = "is_deleted", nullable = false)
    private Boolean isDeleted;

    @Column(name = "ctime", insertable = false, updatable = false)
    private LocalDateTime ctime;

    @Column(name = "utime", insertable = false, updatable = false)
    private LocalDateTime utime;
}