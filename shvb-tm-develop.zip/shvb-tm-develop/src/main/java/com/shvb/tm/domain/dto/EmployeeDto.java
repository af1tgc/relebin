package com.shvb.tm.domain.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.shvb.tm.domain.entity.DepartmentEntity;
import com.shvb.tm.domain.entity.EmployeeEntity;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class EmployeeDto {
    private Long employeeId;
    private String employeeName;
    private String departmentName;

    public EmployeeDto(EmployeeEntity employeeEntity, DepartmentEntity departmentEntity) {
        this.employeeId = employeeEntity.getEmployeeId();
        this.employeeName = employeeEntity.getEmployeeName();
        this.departmentName = departmentEntity.getDepartmentName();
    }
}
