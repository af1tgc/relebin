package com.shvb.tm.repository.projection;

import java.time.LocalDate;

public interface TaskDetailJoinProjection {
    // TaskDetail
    Long getTaskDetailId();
    LocalDate getWorkDate();
    Long getEmployeeId();
    Boolean getIsDeleted();
    String getContent();
    String getLinkUrl();
    String getRemark();
    Integer getDurationMinutes();
    Boolean getIsLate();

    // Task
    Long getTaskId();
    String getTitle();
    String getStatus();

    // TaskType
    Long getTaskTypeId();
    Long getTaskCategoryId();

    // TaskCategory
    String getCategoryName();
    String getTaskCategoryName();

    // Employee
    String getEmployeeName();
    Long getManagerEmployeeId();
}
