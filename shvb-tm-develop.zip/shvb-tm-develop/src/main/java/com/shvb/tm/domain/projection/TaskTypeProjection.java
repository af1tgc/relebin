package com.shvb.tm.domain.projection;

public interface TaskTypeProjection {
    Long getTaskTypeId();
    String getTaskTypeName();
    Long getTaskCategoryId();
    String getTaskCategoryName();
    Long getDepartmentId();
    String getDepartmentName();
}
