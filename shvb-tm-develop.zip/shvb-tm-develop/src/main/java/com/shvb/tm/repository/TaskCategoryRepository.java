package com.shvb.tm.repository;

import com.shvb.tm.domain.entity.TaskCategoryEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface TaskCategoryRepository extends JpaRepository<TaskCategoryEntity, Long> {
    
    // 대분류 조회 (depth = 1, parent_category_id IS NULL)
    @Query("SELECT tc FROM TaskCategoryEntity tc WHERE tc.categoryDepth = 1 ORDER BY tc.categoryName")
    List<TaskCategoryEntity> findLevel1Categories();
    
    // 소분류 조회 (depth = 2, parent_category_id = ?)
    @Query("SELECT tc FROM TaskCategoryEntity tc WHERE tc.categoryDepth = 2 AND tc.parentCategoryId = :parentCategoryId ORDER BY tc.categoryName")
    List<TaskCategoryEntity> findLevel2Categories(@Param("parentCategoryId") Long parentCategoryId);
}