package com.shvb.tm.domain.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Entity
@Table(
        name = "task_category",
        indexes = {
                @Index(name = "idx_task_category_parent", columnList = "parent_category_id")
        }
)
public class TaskCategoryEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @EqualsAndHashCode.Include
    @Column(name = "task_category_id")
    private Long taskCategoryId;

    @Column(name = "category_depth", nullable = false)
    private Integer categoryDepth;

    @Column(name = "category_name", length = 100, nullable = false)
    private String categoryName;

    @Column(name = "parent_category_id")
    private Long parentCategoryId;

    @Column(name = "ctime", insertable = false, updatable = false)
    private LocalDateTime ctime;

    @Column(name = "utime", insertable = false, updatable = false)
    private LocalDateTime utime;
}