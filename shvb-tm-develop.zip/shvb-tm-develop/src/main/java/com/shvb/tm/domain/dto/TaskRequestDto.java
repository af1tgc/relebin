package com.shvb.tm.domain.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaskRequestDto {
    private String title;
    private Long taskTypeId;
    private String status; // TaskStatus enum의 String 값
    private LocalDate startDate;
    private LocalDate dueDate;
    private String frequency; // TaskFrequency enum의 String 값
    private String rrule;
    private Boolean isActive;
}
