package com.shvb.tm.domain.dto;

import lombok.Data;

@Data
public class TaskTypeSearchDto {
    private String taskTypeName;
    private Long taskCategoryId;
    private Long departmentId;
}
