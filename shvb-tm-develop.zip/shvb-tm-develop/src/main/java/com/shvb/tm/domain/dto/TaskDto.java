package com.shvb.tm.domain.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.shvb.tm.domain.entity.*;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaskDto {
    private Long taskId;
    private String title;

    private Long taskTypeId;
    private String taskTypeName;
    private Long taskCategoryId;
    private String taskCategoryName;
    private Long departmentId;
    private String departmentName;
    private TaskEntity.TaskStatus status;

    // 기존 생성자 (TaskTypeJoinEntity 사용)
    public TaskDto(TaskEntity taskEntity, TaskTypeJoinEntity taskTypeJoinEntity) {
        this.taskId = taskEntity.getTaskId();
        this.title = taskEntity.getTitle();
        this.taskTypeId = taskEntity.getTaskTypeId();
        this.taskTypeName = taskTypeJoinEntity.getTaskTypeName();
        if (taskTypeJoinEntity.getTaskCategory() != null) {
            this.taskCategoryId = taskTypeJoinEntity.getTaskCategory().getTaskCategoryId();
            this.taskCategoryName = taskTypeJoinEntity.getTaskCategory().getCategoryName();
        } else {
            this.taskCategoryId = null;
            this.taskCategoryName = null;
        }
        if (taskTypeJoinEntity.getDepartment() != null) {
            this.departmentId = taskTypeJoinEntity.getDepartment().getDepartmentId();
            this.departmentName = taskTypeJoinEntity.getDepartment().getDepartmentName();
        } else {
            this.departmentId = null;
            this.departmentName = null;
        }
        this.status = taskEntity.getStatus();
    }
}
