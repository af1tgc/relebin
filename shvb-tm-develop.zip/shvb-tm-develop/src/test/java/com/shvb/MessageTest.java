package com.shvb;

import java.util.Locale;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.MessageSource;

@SpringBootTest
@Slf4j
public class MessageTest {

    @Autowired
    MessageSource messageSource;

    @Test
    public void getMessages() {
        var k1 = messageSource.getMessage("title", null, Locale.KOREA);
        var e1 = messageSource.getMessage("title", null, Locale.US);

        log.info("k1 is {}", k1);
        log.info("e1 is {}", e1);
    }

}
