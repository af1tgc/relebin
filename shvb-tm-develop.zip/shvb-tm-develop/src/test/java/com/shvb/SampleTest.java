package com.shvb;

import com.shvb.common.domain.ApiRequest;
import com.shvb.sampledomain.domain.NoticeDTO;
import com.shvb.sampledomain.domain.NoticeEntity;
import com.shvb.sampledomain.repository.NoticeRepository;
import com.shvb.sampledomain.service.NoticeService;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.web.client.RestTemplate;

@SpringBootTest
@Slf4j
public class SampleTest {

    @Autowired
    NoticeRepository repo;

    @Autowired
    NoticeService serv;

    @Test
    public void findByDtoFilter() {
        var s = Sort.by("id");
        var p = PageRequest.of(0, 3, s);
        var filters = List.of("id eq 1");

        NoticeDTO param = new NoticeDTO();
        param.setId(null);
        param.setTitle("test");

        var t = repo.findAllByDtoFilter(param, p);
        System.out.printf("getTotalElements : %s \n", t.getTotalElements());
        System.out.printf("getTotalPages : %s \n", t.getTotalPages());
        System.out.printf("toString : %s \n", t.toString());
    }

    @Test
    public void selectCount() {
        var t1 = repo.count();
        log.error("test result {}", t1);
    }

    @Test
    public void insertTest() {
        NoticeEntity entity = new NoticeEntity();
//        entity.setId(1l);
        entity.setTitle("test title 1");
        entity.setWriter("whlee84");
        entity.setContent("this is content. 내용 추가");
        entity.setNoticeYn("N");
        entity.setWriteDate(LocalDateTime.now());

        ApiRequest req = new ApiRequest();
        req.setPageSize(5);
        req.setPageNumber(0);
        req.setOrderBy("id");
        req.setDirection("asc");

        var b1 = serv.getNoticeList(req);
        log.error("test before result {}", b1);

        var t1 = serv.createNotice(entity);
        log.error("test result {}", t1);

        var a1 = serv.getNoticeList(req);
        log.error("test after result {}", a1);
    }

    @Test
    public void updateTest() {
        NoticeEntity entity = new NoticeEntity();
        entity.setId(1l);     // ID가 지정된 경우 update 동작
        entity.setTitle("test title 1");
        entity.setWriter("whlee84");
        entity.setContent("this is content. 내용 추가");
        entity.setNoticeYn("Y");
        entity.setUpdateDate(LocalDateTime.now());

        ApiRequest req = new ApiRequest();
        req.setPageSize(5);
        req.setPageNumber(0);
        req.setOrderBy("id");
        req.setDirection("asc");

        var b1 = serv.getNoticeList(req);
        log.error("test before result {}", b1);

        var t1 = serv.updateNotice(entity);
        log.error("test result {}", t1);

        var a1 = serv.getNoticeList(req);
        log.error("test after result {}", a1);
    }

    @Test
    public void getNoticeList() {
        ApiRequest req = new ApiRequest();
        req.setPageSize(5);
        req.setPageNumber(0);
        req.setOrderBy("id");
        req.setDirection("asc");

        var t1 = serv.getNoticeList(req);
        log.error("test result {}", t1);
    }

    @Autowired
    RestTemplate restTemplate;

    private final String TEST_URL = "http://localhost:8080/notice";
    @Test
    public void RestTemplate_테스트_GETforObject() {

        NoticeEntity entity = new NoticeEntity();
        entity.setId(1L);     // ID가 지정된 경우 update 동작
        entity.setTitle("test title 1");
        entity.setWriter("whlee84");
        entity.setContent("this is content. 내용 추가");
        entity.setNoticeYn("Y");
        entity.setWriteDate(LocalDateTime.now());

        var resEntity = restTemplate.getForEntity(TEST_URL + "/2", Map.class);

        log.info("StatusCode : {}", resEntity.getStatusCode());
        log.info("Headers : {}", resEntity.getHeaders());
        log.info("Body : {}", resEntity.getBody().toString());
    }

    @Test
    public void RestTemplate_테스트_forMap() {

        Map<String, Object> param = Map.of("id", "1", "pageSize", "5", "pageNumber", "0");

//        var resEntity = restTemplate.getForEntity(TEST_URL + "/list?pageSize=5&pageNumber=0", Map.class, param);
        var resEntity = restTemplate.getForEntity(TEST_URL + "/list?pageSize={pageSize}&pageNumber={pageNumber}", Map.class, param);

        log.info("StatusCode : {}", resEntity.getStatusCode());
        log.info("Headers : {}", resEntity.getHeaders());
        log.info("Body : {}", resEntity.getBody().toString());

    }

    @Test
    public void mvcMock_테스트() {

    }
}
