-- 업무 검색 성능 최적화를 위한 인덱스 추가

-- task_detail 테이블: 날짜 및 작업자 검색용
ALTER TABLE task_detail ADD INDEX idx_work_date (work_date);
ALTER TABLE task_detail ADD INDEX idx_employee_id (employee_id);
ALTER TABLE task_detail ADD INDEX idx_task_work_date (task_id, work_date);

-- employee 테이블: 이름 검색용 (한글 검색 최적화)
ALTER TABLE employee ADD INDEX idx_employee_name (employee_name);

-- task 테이블: 상태 및 제목 검색용
ALTER TABLE task ADD INDEX idx_status (status);
ALTER TABLE task ADD INDEX idx_task_type (task_type_id);

-- task_type 테이블: 업무 유형명 검색용
ALTER TABLE task_type ADD INDEX idx_task_type_name (task_type_name);

-- 복합 인덱스: 자주 함께 조회되는 컬럼
ALTER TABLE task_detail ADD INDEX idx_employee_work_date (employee_id, work_date);
