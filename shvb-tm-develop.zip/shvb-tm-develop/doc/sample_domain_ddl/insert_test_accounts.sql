-- 테스트용 계정 생성 (비밀번호: password123)
-- BCrypt로 인코딩된 'password123'
-- role: USER(일반직원), MANAGER(부서장/팀장), BOD(임원), ADMIN(시스템관리자)

-- 기존 데이터 삭제 (필요시)
-- DELETE FROM employee_account WHERE employee_id IN (1, 6, 8);

INSERT INTO employee_account (employee_id, role, username, password_hash, is_active, failed_attempts)
VALUES 
    (1, 'USER', 'kimhaneul', '$2a$10$gFdi1m.PnYvCRqlUd4J3GOwq1V4VwMbpbsU52vvkeCCukZcqEvmZW', 1, 0),
    (6, 'MANAGER', 'parkseojun', '$2a$10$gFdi1m.PnYvCRqlUd4J3GOwq1V4VwMbpbsU52vvkeCCukZcqEvmZW', 1, 0),
    (8, 'ADMIN', 'janggaeun', '$2a$10$gFdi1m.PnYvCRqlUd4J3GOwq1V4VwMbpbsU52vvkeCCukZcqEvmZW', 1, 0);
