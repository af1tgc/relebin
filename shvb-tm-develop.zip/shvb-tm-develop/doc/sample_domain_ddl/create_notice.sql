CREATE TABLE `notice` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `title` varchar(100) DEFAULT NULL,
  `content` text,
  `writer` varchar(100) DEFAULT NULL,
  `view_cnt` int DEFAULT NULL,
  `notice_yn` varchar(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `write_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `notice_file` (
  `notice_id` bigint NOT NULL,
  `file_path` varchar(100) NOT NULL,
  `write_date` timestamp DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
-- drop table notice_file;
insert into notice_file (notice_id, file_path) values
(1, 'file1.pdf')
,(1, 'file2.pdf')
,(1, 'file3.pdf')
;

CREATE TABLE `com_user` (
  `user_id` varchar(100) NOT NULL,
  `user_name` varchar(100) NULL,
  `user_email` varchar(100) NULL,
  primary key (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT into com_user (user_id, user_name, user_email) values
('whlee84', 'WanheeLee', 'whlee84@nhn.com')
,('LWH', '이완', 'lwh@nhn.com')
;
