# 인증 API 명세서

## 개요
- JWT 기반 인증 시스템
- 토큰 유효기간: 24시간
- 로그인 실패 5회 시 계정 30분 잠금

---

## 1. 로그인 API

### Endpoint
```
POST /auth/login
```

### Request Headers
```
Content-Type: application/json
```

### Request Body
```json
{
  "username": "kimhaneul",
  "password": "password123"
}
```

| 필드 | 타입 | 필수 | 설명 |
|------|------|------|------|
| username | string | O | 로그인 아이디 |
| password | string | O | 비밀번호 |

### Response (성공 - 200 OK)
```json
{
  "code": 0,
  "message": "success",
  "result": {
    "token": "eyJhbGciOiJIUzUxMiJ9.eyJlbXBsb3llZUlkIjoxLCJ1c2VybmFtZSI6ImtpbWhhbmV1bCIsInN1YiI6ImtpbWhhbmV1bCIsImlhdCI6MTczMzMxOTY4MCwiZXhwIjoxNzMzNDA2MDgwfQ.abcd1234...",
    "type": "Bearer",
    "employeeId": 1,
    "username": "kimhaneul",
    "employeeName": "김하늘",
    "role": "USER"
  }
}
```

| 필드 | 타입 | 설명 |
|------|------|------|
| token | string | JWT 액세스 토큰 (이후 모든 API 요청에 사용) |
| type | string | 토큰 타입 (항상 "Bearer") |
| employeeId | number | 직원 ID |
| username | string | 로그인 아이디 |
| employeeName | string | 직원 이름 |
| role | string | 사용자 권한 (USER, MANAGER, BOD, ADMIN) |

### Response (실패)

**아이디/비밀번호 불일치 (400)**
```json
{
  "code": -1,
  "message": "아이디 또는 비밀번호가 일치하지 않습니다."
}
```

**계정 잠김 (400)**
```json
{
  "code": -1,
  "message": "계정이 잠겼습니다. 2024-12-04T22:30:00까지 로그인할 수 없습니다."
}
```

**비활성화된 계정 (400)**
```json
{
  "code": -1,
  "message": "비활성화된 계정입니다."
}
```

---

## 2. 인증이 필요한 API 호출 방법

로그인 후 받은 토큰을 모든 API 요청의 Authorization 헤더에 포함해야 합니다.

### Request Headers
```
Authorization: Bearer eyJhbGciOiJIUzUxMiJ9.eyJlbXBsb3llZUlkIjoxLCJ1c2VybmFtZSI6ImtpbWhhbmV1bCIsInN1YiI6ImtpbWhhbmV1bCIsImlhdCI6MTczMzMxOTY4MCwiZXhwIjoxNzMzNDA2MDgwfQ.abcd1234...
```

### 예시 (직원의 관리자 조회)
```bash
curl -X GET http://localhost:8080/admin/employee/1/manager \
  -H "Authorization: Bearer <토큰>"
```

### Response (인증 실패 - 401)
토큰이 없거나 유효하지 않은 경우:
```json
{
  "code": -1,
  "message": "Unauthorized"
}
```

---

## 3. 프론트엔드 구현 가이드

### 3.1 로그인 플로우

```typescript
// 1. 로그인 요청
async function login(username: string, password: string) {
  const response = await fetch('http://localhost:8080/auth/login', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ username, password }),
  });

  const data = await response.json();

  if (data.code === 0) {
    // 성공: 토큰 저장
    const { token, employeeId, username, employeeName } = data.result;
    localStorage.setItem('token', token);
    localStorage.setItem('employeeId', employeeId.toString());
    localStorage.setItem('username', username);
    localStorage.setItem('employeeName', employeeName);
    
    return { success: true, data: data.result };
  } else {
    // 실패
    return { success: false, error: data.message };
  }
}
```

### 3.2 API 요청 시 토큰 포함

```typescript
// axios 사용 예시
import axios from 'axios';

const api = axios.create({
  baseURL: 'http://localhost:8080',
});

// 요청 인터셉터: 모든 요청에 토큰 자동 추가
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// 응답 인터셉터: 401 에러 시 로그인 페이지로 리다이렉트
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.clear();
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

export default api;
```

### 3.3 fetch 사용 예시

```typescript
async function fetchWithAuth(url: string, options: RequestInit = {}) {
  const token = localStorage.getItem('token');
  
  const headers = {
    ...options.headers,
    'Content-Type': 'application/json',
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const response = await fetch(url, {
    ...options,
    headers,
  });

  if (response.status === 401) {
    // 토큰 만료 or 인증 실패
    localStorage.clear();
    window.location.href = '/login';
    throw new Error('Unauthorized');
  }

  return response.json();
}

// 사용 예시
const managerInfo = await fetchWithAuth('http://localhost:8080/admin/employee/1/manager');
```

### 3.4 로그아웃

```typescript
function logout() {
  localStorage.removeItem('token');
  localStorage.removeItem('employeeId');
  localStorage.removeItem('username');
  localStorage.removeItem('employeeName');
  window.location.href = '/login';
}
```

### 3.5 인증 상태 확인

```typescript
function isAuthenticated(): boolean {
  const token = localStorage.getItem('token');
  return !!token;
}

function getCurrentUser() {
  return {
    employeeId: localStorage.getItem('employeeId'),
    username: localStorage.getItem('username'),
    employeeName: localStorage.getItem('employeeName'),
  };
}
```

---

## 4. TypeScript 타입 정의

```typescript
// 로그인 요청
interface LoginRequest {
  username: string;
  password: string;
}

// 로그인 응답
interface LoginResponse {
  token: string;
  type: string;
  employeeId: number;
  username: string;
  employeeName: string;
  role: 'USER' | 'MANAGER' | 'BOD' | 'ADMIN';
}

// API 공통 응답 형식
interface ApiResult<T> {
  code: number;
  message: string;
  result?: T;
}

// 사용자 Role 타입
type UserRole = 'GUEST' | 'USER' | 'MANAGER' | 'BOD' | 'ADMIN';

// Role 계층 구조 (FE에서 권한 체크 시 사용)
const roleHierarchy: Record<UserRole, number> = {
  'GUEST': 0,
  'USER': 1,
  'MANAGER': 2,
  'BOD': 3,
  'ADMIN': 9
};
```

---

## 5. 권한 시스템 (Role-based Access Control)

### 권한 레벨

| Role | 레벨 | 설명 |
|------|------|------|
| GUEST | 0 | 비로그인 사용자 (실제로는 사용 안 함) |
| USER | 1 | 일반 직원 |
| MANAGER | 2 | 부서장, 팀장 |
| BOD | 3 | 임원진 |
| ADMIN | 9 | 시스템 관리자 |

### JWT 토큰에 포함된 정보

```typescript
// JWT 토큰 디코딩 시 얻을 수 있는 정보
interface JWTPayload {
  employeeId: number;
  username: string;
  role: UserRole;
  sub: string;  // username
  iat: number;  // 발급 시간
  exp: number;  // 만료 시간
}
```

---

## 6. 테스트 계정

| 아이디 | 비밀번호 | 직원명 | 직원ID | Role | 권한 |
|--------|---------|--------|--------|------|------|
| kimhaneul | password123 | 김하늘 | 1 | USER | 일반 직원 |
| parkseojun | password123 | 박서준 | 6 | MANAGER | 팀장 |
| janggaeun | password123 | 장가은 | 8 | ADMIN | 시스템 관리자 |

---

## 7. 주의사항

1. **토큰 저장**
   - localStorage에 저장 (간단한 구현)
   - 보안이 중요하면 httpOnly 쿠키 사용 권장 (추가 구현 필요)

2. **토큰 만료**
   - 토큰 유효기간: 24시간
   - 만료 시 401 응답 → 자동 로그아웃 처리

3. **보안**
   - 민감한 정보(비밀번호)는 절대 저장하지 말 것
   - HTTPS 사용 권장 (프로덕션 환경)

4. **CORS**
   - 현재 허용된 Origin: `http://localhost:5173`, `http://167.172.205.76:3000`
   - 다른 Origin 필요시 백엔드에 추가 요청

---

## 8. 에러 코드 정리

| HTTP Status | code | message | 설명 |
|------------|------|---------|------|
| 200 | 0 | success | 성공 |
| 400 | -1 | 아이디 또는 비밀번호가 일치하지 않습니다. | 로그인 실패 |
| 400 | -1 | 계정이 잠겼습니다. ... | 로그인 5회 실패로 잠김 |
| 400 | -1 | 비활성화된 계정입니다. | 계정 비활성화 상태 |
| 401 | -1 | Unauthorized | 토큰 없음/만료/유효하지 않음 |
| 500 | -1 | Internal Server Error | 서버 에러 |

---

## 9. 참고: 기존 API도 인증 필요

이제 모든 `/admin/*`, `/task-manager/*` API는 인증이 필요합니다.
로그인 없이 호출하면 401 에러가 발생합니다.

**인증 불필요 엔드포인트:**
- `POST /auth/login`
- `OPTIONS` 요청 (CORS preflight)

**인증 필요 엔드포인트:**
- `GET /admin/employee/{id}/manager`
- `GET /admin/department/{id}/tree`
- `GET /task-manager/task-detail-list`
- 기타 모든 API
